# Citizen: BayShine

Status: active citizen, dogfood account.
External path: `/home/user/BayShine/` (sibling project, not
vendored).
Live site: bayshine.co (when deployed).

## What BayShine is

BayShine is a mobile auto and marine detailing operation serving
Pasco and North Hillsborough counties in Florida, operated by
Constantine. Its website is the first website Atrium ever shipped
to production quality, and it is the case study every Atrium
business will reference when proving that the playbook works.

The codebase lives at `/home/user/BayShine/` and is its own git
repository. It is intentionally not vendored into Atrium because:

1. BayShine is a citizen, not a feature. The autonomy of the
   business (its own repo, its own deploy pipeline, its own
   branch history) is part of what makes the topology honest.
2. Atrium can reference BayShine without owning it. References
   are stable in this file and in the Library's artifacts. They
   point to BayShine's repository structure as needed.

## What Atrium uses BayShine for

- **Dogfood case study.** The Vault Astro starters are forked from
  BayShine's `src/` and tokenized for other verticals. Every
  customer testimonial Citation eventually displays will reference
  BayShine's Lighthouse score, citation appearance, and
  Discoverability work as the proof.
- **Origin of voice.** `spine/origins/CLAUDE.md` and
  `spine/origins/BUILD_BRIEF.md` are the documents BayShine's
  construction was governed by. The Constitution absorbs them.
- **First Citation customer.** When Citation launches, BayShine is
  its first paying-but-internal customer: free for Constantine,
  but a real customer in every other operational sense (data flows
  through the same pipelines, reports are generated, the cron
  monitors fire).
- **Source of the discoverability specialists.** The five
  specialists (schema, site-architecture, geo-ai-search, internal-
  linking, citation-readiness) were authored during BayShine
  construction. Atrium adopted them as descendants on 2026-05-11.
  BayShine retains its own copies in its own `.claude/agents/`;
  Atrium has copies in its own `.claude/agents/`. Drift between
  the two is a future concern, not a present one.

## What BayShine does not do for Atrium

- BayShine does not host Atrium's spine, library, or any other
  Atrium asset.
- BayShine does not pay Atrium. Atrium operates BayShine; revenue
  from BayShine's detailing business is Constantine's, not
  Atrium's. Atrium revenue comes from the businesses Atrium spawns,
  not from operating BayShine.
- BayShine does not block Atrium. If BayShine ever needs to fork
  away or shut down, Atrium continues with the other citizens
  unaffected.

## Sync notes

- 2026-05-11: BayShine `.claude/agents/` and Atrium `.claude/agents/`
  contain identical copies of the five discoverability specialists.
  No drift.
- 2026-05-11: BayShine `CLAUDE.md` and `BUILD_BRIEF.md` are
  archived at `spine/origins/` in Atrium. Future edits to
  BayShine's versions will not flow back unless explicitly
  imported via a Journal entry.
