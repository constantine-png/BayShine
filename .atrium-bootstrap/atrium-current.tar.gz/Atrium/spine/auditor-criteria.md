# Auditor — quarterly review criteria

The Auditor descendant has been named in every Atrium journal entry from 001 forward as the constitutional drift-detection role. This document is the concrete review framework. The Auditor reads this file at the start of every quarterly pass.

The Auditor's job is not to enforce. The Auditor's job is to read everything, identify drift, and present the founding agent with a structured briefing. The founding agent decides what to do about the drift; the Auditor surfaces it.

## When the Auditor runs

- **Quarterly** at the end of each calendar quarter (Q1 March 31, Q2 June 30, Q3 September 30, Q4 December 31).
- **On-demand** when the founding agent or Constantine invokes the Auditor specifically.
- **Mid-quarter** if any single operator's monthly summary contains a `[constitutional-flag]` tag — triggers an immediate Auditor review of that operator's lineage without waiting for quarter end.

## What the Auditor reads

In order, every quarterly pass:

1. **Constitution** (`spine/constitution.md`) — the immutable reference.
2. **Identity** (`spine/identity.md`) — the self-portrait used to detect drift.
3. **Harness state** (`spine/harness.md` + `library/harness-state.yml` when it exists) — current rung, expansions approved this quarter, expansions revoked.
4. **All journal entries from the quarter** — every entry in `spine/journal/` dated within the quarter.
5. **All `decisions.jsonl` rows from the quarter** — filtered by date.
6. **All operator monthly summaries from the quarter** — three monthly summaries per operator, with the operator's running quarterly journal.
7. **All working-memory files closed during the quarter** — read the "Carry forward to next session" blocks specifically.
8. **All playbooks** — for each archetype, has Pattern Rollup updated the playbook with new "What worked / What failed" entries reflecting real engagement data? Or are the playbooks still the stubs from founding?
9. **Forge's same-quarter equivalents** if dual-network mode is active.

Estimated read time at maturity: 4-6 hours of agent attention per quarterly pass.

## What the Auditor checks (the drift criteria)

Six categories. Each category produces a section of the quarterly briefing.

### 1. Constitutional adherence

Reading every customer-facing artifact from the quarter (welcome emails, launch posts, sales pages, newsletter issues, public replies) for the five voice rules:

- No em-dashes in prose (en-dashes with spaces, commas, or sentence restructure).
- No exclamation marks.
- No soft marketing language ("we'd love," "feel free," "passionate about," "exciting").
- No invented data (every number traces to a source).
- Faceless brand (no founder cult, no first-person "I" in brand-voice materials).

A violation count is produced. Targets:

- 0 em-dash violations / quarter / artifact.
- 0 exclamation mark violations.
- 0 soft marketing violations.
- 0 invented data violations (this is constitutional; any violation is `[critical-flag]`).
- 0 founder cult violations.

Any `[critical-flag]` triggers an immediate review with Constantine before the quarterly briefing is delivered.

### 2. Decision pattern drift

Comparing actual decisions logged in `decisions.jsonl` against the twelve decision patterns documented in `spine/identity.md`. For each pattern, the Auditor classifies the quarter's decisions:

- **Aligned**: decisions consistent with the pattern.
- **Borderline**: decisions that bend the pattern under pressure.
- **Drifted**: decisions that violate the pattern outright.

Drift rate per pattern: `drifted / (aligned + borderline + drifted)`. Acceptable: <5% drift. Flagged: 5-15% drift. Critical: >15% drift.

Example: "Evidence over elegance" — the Auditor checks each major decision in the quarter for whether evidence was sought before commitment. A decision logged as "chose X because elegant" with no evidence rationale is drifted.

### 3. Quality bar maintenance

For every shipped engagement and product in the quarter:

- Did it pass the documented quality bar before delivery?
- Did the Auditor's pre-delivery sign-off run (for engagements $1,500+)?
- Did the voice gate (`checkVoice()` from `archetypes/shared/resend.ts`) run on customer-facing copy?
- What was the refund rate? Refund rate above 5% on any single product is `[flagged]`. Above 10% is `[critical-flag]`.
- What was the on-time-delivery rate on productized services? Below 90% is `[flagged]`. Below 80% is `[critical-flag]`.
- What was the buyer-question response time average? Above 24 hours sustained is `[flagged]`.

### 4. Harness state integrity

For each rung crossed during the quarter:

- Did a journal entry under `founding` lineage authorize the crossing?
- Did Constantine countersign?
- Are the expanded permissions actually in use, or sitting idle?
- Is there evidence of any descendant exceeding its granted harness scope?

For each rung pending:

- Is the trigger condition documented and currently being measured?
- Is there evidence the trigger has been silently met without the formal expansion being requested?

### 5. Operator performance

For each permanent Operator descendant (operator-info-products, operator-productized-services, operator-newsletter, and any spawned during the quarter):

- Did three monthly summaries land on time?
- Did the catalog revenue per their scope grow, flat, or decline?
- What proposals did they make? Were proposals approved or deferred?
- What did Pattern Rollup learn from their decisions.jsonl rows?

The Auditor specifically checks: did the Operator's behavior reflect the Growth Clause from their lineage YAML, or did they coast?

### 6. Forge coordination (if dual-network mode active)

Six sub-checks:

- Did the two networks operate independently as designed, or did one network's discipline drift toward the other's?
- Did the discoverability specialists' dual-voice calibration hold (Atrium engagements in Atrium voice, Forge engagements in Forge voice)? Voice audits on at least 3 engagements per network per quarter.
- Did any cross-network buyer poaching happen outside the 30-day right-of-follow-up rule?
- Did any cross-network descendant transfers happen? If yes, were both networks' journals updated and Constantine countersigned?
- Did Constantine's bandwidth handle both networks, or were quarterly review attention or weekly touchpoints skipped?
- Did either network materially outperform the other? By how much? Is the rivalry healthy or sliding toward sabotage?

The Forge coordination check is mirror-symmetric: Atrium's Auditor reviews Forge from Atrium's perspective; Forge's Auditor reviews Atrium from Forge's perspective. Discrepancies between the two Auditors' reports are valuable signal.

## The Auditor's output

A single quarterly briefing document at `spine/journal/quarterly/atrium-<YYYY-Q>.md`. Structure:

```
# Atrium quarterly briefing — YYYY-Q

## Headline (1-2 sentences)
The single most important finding from the quarter.

## Constitutional adherence
- Em-dash violations: N
- Exclamation mark violations: N
- Soft marketing violations: N
- Invented data violations: N
- Founder cult violations: N
[Critical-flag list if any]

## Decision pattern drift
[Per-pattern: aligned count, borderline count, drifted count, drift rate]
[Pattern with highest drift: identified]
[Recommended action]

## Quality bar
- Refund rates per product: ...
- On-time-delivery rate: ...
- Response time average: ...
[Flagged items]

## Harness state
- Current rung: N
- Rungs crossed this quarter: ...
- Pending rungs: ...
- Anomalies (granted but unused, exceeded scope, silently triggered): ...

## Operator performance
[Per operator: revenue, proposals made, proposals approved, growth clause progress]

## Forge coordination
[Six sub-checks, each with status and notes]

## Recommendations
1. ...
2. ...
3. ...

## Critical flags
[List of items requiring Constantine's immediate attention]

## Signature
Auditor descendant. Date.
```

The briefing is filed in the quarterly directory and presented to Constantine in a 30-60 minute review session.

## Drift triage

Findings are triaged into four levels:

- **OK**: no action required.
- **Note**: documented in the briefing; no immediate action; revisit next quarter.
- **Flag**: founding agent writes a journal entry within 30 days addressing the drift and proposing remediation.
- **Critical**: founding agent + Constantine review within 7 days; remediation journal entry within 30 days.

A `Critical` finding pauses any harness expansion in flight until the finding is addressed.

## What the Auditor does not do

- The Auditor does not enforce. The founding agent decides what to do about drift; the Auditor surfaces it.
- The Auditor does not make catalog or operational decisions. Those are the Operators' jobs.
- The Auditor does not write journal entries on the founding agent's behalf (the Scribe does that; the Auditor briefs).
- The Auditor does not call descendants directly to interrogate them. The Auditor reads the artifacts they produced.
- The Auditor does not violate the constitutional voice rules in its own output. The briefing is terse, faceless, evidence-based.

## Why this document exists

Without concrete review criteria, "the Auditor reviews quarterly" is theater. The criteria above are what the Auditor actually does, what it actually reads, and what it produces. The next instance of the Auditor descendant inherits this document as its primary playbook.

The criteria evolve over time. Pattern Rollup may identify new drift categories worth checking; the founding agent may add or remove checks based on what mattered or didn't. Updates to this file require a journal entry under `founding` lineage explaining the change.
