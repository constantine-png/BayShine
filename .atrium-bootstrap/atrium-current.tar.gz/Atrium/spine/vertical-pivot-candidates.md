# Vertical pivot candidates

Per `spine/roi-evaluation.md`, Trigger B (vertical pivot) fires at Day 90 if combined qualified contacts across both networks fall below 500. If it fires, the architecture's chassis remains; the vertical changes. This document is the candidate pool the founding agent evaluates from when Trigger B fires.

Candidates listed in this document do NOT receive subagent spawns until Trigger B activates them. Listing here documents the option without committing operator attention.

## How candidates are evaluated

Each candidate is scored on six dimensions:

1. **Vertical fit** — does the audience exist and is it reachable?
2. **Evidence base for solo operators** — documented track record at solo scale?
3. **Time-to-revenue** — weeks vs months vs years for first dollar?
4. **Constitutional alignment** — which network's discipline fits better (or do both fit)?
5. **Regulatory complexity** — how much compliance burden?
6. **Catalog translation** — how much of the current Atrium/Forge product structure reuses?

Each dimension scored: strong / moderate / weak / poor.

## Candidate 1 — B2B SaaS marketing teams

**Vertical fit:** strong. Audience is concentrated (SaaS founders, marketing leads at $1M-$10M ARR companies). Reachable via Twitter, LinkedIn, IndieHackers, podcast circuit.

**Evidence base:** strong. Many documented solo operators serving B2B SaaS at $50k-$500k ARR: SaaS-specific consultants, MicroAcquisitions-style flippers, B2B SEO consultants, indie SaaS-tool builders.

**Time-to-revenue:** weeks to first contract (typically). B2B SaaS sales cycles are 30-90 days but discovery happens faster.

**Constitutional alignment:** Forge stronger than Atrium. B2B SaaS buyers value named-operator brand, technical credibility, subscription mechanics. Atrium's faceless approach underfits.

**Regulatory complexity:** minimal.

**Catalog translation:** high. Schema markup → SaaS structured data (Product, Offer, Organization). llms.txt → SaaS-positioning entity declaration. Citation Watch / Schema Doctor Pro fit cleanly. GEO Setup → SaaS-onboarding.

**Probe data needed before activation:** Run a 50-prospect cold outreach to B2B SaaS marketing leads with subjects similar to Forge's COLD-EMAIL-TEMPLATES.md Variant C (SaaS founder building tools for service businesses). Measure reply rate.

## Candidate 2 — Healthcare practice ops (dental, optometry, veterinary)

**Vertical fit:** moderate-strong. Audience is distributed (~200k US practices) but reachable via practice-management software vendor partnerships, healthcare-specific conferences, regional dental/vet association directories.

**Evidence base:** moderate. Healthcare-ops SaaS operators exist (DentalIntel, Vetstoria) but at company scale; solo operators are rarer. Productized services for healthcare practices exist (chiropractor marketing agencies, dental-practice growth consultants).

**Time-to-revenue:** moderate. Healthcare buyers are cautious; first sale takes 60-90 days typical. AOV is high ($2,500-$25,000 per engagement).

**Constitutional alignment:** both fit. Atrium's faceless + productized service fits the "we'll handle your AI search visibility" framing. Forge's named-operator + enterprise framing fits multi-location dental groups or chain practices.

**Regulatory complexity:** moderate. HIPAA applies to anything touching patient data; supplements-style FDA regulation does NOT apply. Healthcare marketing has truth-in-advertising restrictions but they're well-documented.

**Catalog translation:** medium-high. Schema markup → MedicalBusiness, Dentist, VeterinaryCare subclasses (real schema.org types). llms.txt for practice identity. AI Citation Audit → practice-specific probe. GEO Setup adapted for HIPAA-aware deliverables.

**Probe data needed:** Run probes against 25 dental + 25 vet + 25 optometry practices. Confirm AI search citation patterns. Validate that "best [practice type] in [city]" is a queried pattern.

## Candidate 3 — Multi-location franchise systems

**Vertical fit:** strong for Forge specifically. Audience is concentrated (~3,000 multi-location franchisors in US) and reachable via franchisor associations, IFA conferences, LinkedIn search.

**Evidence base:** strong. Franchisor-marketing services is an established $1B+ market with documented per-engagement values of $25k-$250k.

**Time-to-revenue:** moderate-long. Franchisor sales cycles are 90-180 days; first contract typically requires multiple stakeholders.

**Constitutional alignment:** Forge strongly. Enterprise GEO Program ($25k / 30 days) is already calibrated for multi-location operators per its sales page. Franchisor buyers fit the Program's profile directly.

**Regulatory complexity:** moderate. FTC Franchise Disclosure Document rules apply to anything touching franchise sales (not applicable to operational AI search work).

**Catalog translation:** very high. The Enterprise GEO Program sales page already targets multi-location service chains. Franchisor systems is the same audience profile with a different framing.

**Probe data needed:** Identify 10 mid-tier franchisors (~50-200 locations) and run sampling probes. Confirm citation patterns vary by location and that uniform brand-level AI search visibility is missing across locations.

## Candidate 4 — D2C e-commerce sellers on Shopify or BigCommerce

**Vertical fit:** moderate. Audience is huge (~3M+ Shopify stores) but fragmented; reaching specific buyer profiles requires either content marketing or paid acquisition or Shopify-app ecosystem positioning.

**Evidence base:** moderate. Shopify-app ecosystem has documented solo operators at $50k-$5M ARR. Audience-acquisition cost in Shopify-app space is increasing.

**Time-to-revenue:** moderate. Shopify-app trial-to-paid conversion takes 14-30 days; cold-start audience acquisition takes 60+ days.

**Constitutional alignment:** Forge stronger. Subscription-first economics native to Shopify-app ecosystem. Named-operator branding common.

**Regulatory complexity:** minimal (general e-commerce regulations only).

**Catalog translation:** medium. Schema markup → Product / Offer / Brand schema types (different subtree from LocalBusiness). Citation Watch could probe AI engine responses to product queries. Schema Doctor Pro fits Shopify-store schema management cleanly via Shopify webhook integration.

**Probe data needed:** Identify 20 Shopify stores in adjacent verticals. Confirm their AI search visibility state. Validate that Shopify-store owners care about AI search visibility specifically.

## Candidate 5a — Mineral supplements (consumer-direct, per principal's proposition)

**Vertical fit:** poor for current architecture. Consumer-DTC e-commerce; physical product; different schema subtree (Product / NutritionInformation vs LocalBusiness); different buyer journey; different trust requirements.

**Evidence base:** mixed-weak for solo dropship operators specifically. Strong for named-operator brands that compound over 5-10 years (MaryRuth Organics, Athletic Greens, Seed). Weak for solo dropship at <1 year scale.

**Time-to-revenue:** long for white-label compounding model. Weeks for affiliate side-revenue (if traffic exists).

**Constitutional alignment:** Forge moderately fits (subscription-first, named-operator brand). Atrium poorly fits (faceless brand, voice rules misaligned with supplement marketing patterns).

**Regulatory complexity:** moderate-high. FDA dietary supplement regulations (DSHEA), structure-function claims rules, allergen labeling, GRAS status. Compliance specialist not authored in either network.

**Catalog translation:** low. Schema for supplements differs from current calibration. Voice rules don't translate. Operator playbooks don't transfer.

**Probe data needed before activation:** Constantine answers the three open questions in the proposition (traffic advantage, Shopify autonomy, payment processor identity). Plus: research 5 successful named-operator supplement brands at <$1M ARR for time-to-revenue and customer-acquisition-cost patterns.

## Candidate 5b — B2B supplement wholesale (per Forge Journal 008)

**Vertical fit:** moderate for Forge. B2B supplement supply (wholesale to gyms, naturopath networks, chiropractor offices, SMB wellness HR programs, white-label-for-other-brands) is a B2B sales motion that fits Forge's outbound discipline.

**Evidence base:** real but underexplored at solo operator scale. Industry exists (Vitalabs, Professional Nutritionals, Supliful do white-label-for-other-brands); solo operators participating in this space at modest scale ($50k-$500k ARR) are documented but not extensively profiled.

**Time-to-revenue:** moderate. B2B wholesale sales cycles 30-90 days similar to other Forge enterprise engagements.

**Constitutional alignment:** Forge strongly fits. Subscription-first (recurring bulk supply), named operator (B2B buyers expect named relationships), enterprise pipeline (multi-location buyers).

**Regulatory complexity:** moderate. Same FDA/DSHEA rules but at supplier-to-business level rather than direct-to-consumer. Less consumer-protection burden per individual transaction.

**Catalog translation:** medium-low. Forge's outbound infrastructure (cold email templates, prospect dossier, LinkedIn outreach, sequences) repurposes for supplement-wholesale prospects with template adaptation. Subscription mechanics translate. Enterprise engagement pricing structure may translate.

**Probe data needed:** Forge's recommended Recommendation B from Forge Journal 008 — a 2-week bounded exploratory subagent (`forge-supplements-probe-specialist`) researching the wholesale supplement market and probing 5-10 specific prospects (gyms, naturopath networks, regional HR consulting firms). Decision after 2 weeks.

## How candidates compete

If Trigger B fires at Day 90, the founding agent selects from the 6 candidates (5a / 5b are alternative framings of the same market). Selection criteria:

1. **Highest measured probe response rate.** The candidate with the best probe data wins.
2. **Strongest catalog translation.** Less re-scaffolding = faster time-to-revenue.
3. **Best constitutional alignment.** A candidate that fits one network's discipline well (vs both poorly) is preferred over one that fits both moderately.
4. **Capital efficiency.** Lower-capital pivots beat higher-capital pivots at $0 starting capital.

At Day 90, the actual ranking will depend on real probe data we don't have yet. The current best-guess ranking (no data, just structural alignment):

1. **B2B SaaS marketing teams** (Candidate 1). Strongest evidence base for solo operators. Strong catalog translation. Forge fit.
2. **Multi-location franchise systems** (Candidate 3). Already calibrated by Forge's Enterprise GEO Program sales page. Excellent catalog translation.
3. **Healthcare practice ops** (Candidate 2). Real category with documented economics; moderate translation.
4. **B2B supplement wholesale** (Candidate 5b). Forge's discipline fits well; modest catalog translation; bounded probe could surface real opportunity.
5. **D2C e-commerce on Shopify** (Candidate 4). Forge-leaning but harder customer acquisition.
6. **Consumer-direct supplements** (Candidate 5a). Worst fit for current discipline; documented as a deferred option only because the principal specifically proposed it.

## What this document does NOT do

- It does NOT spawn agents for any of the candidates. Spawning is gated by Trigger B firing OR Constantine override.
- It does NOT commit to any specific candidate being selected. The Day-90 evaluation uses real probe data, not this document's best-guess ranking.
- It does NOT close off other candidates. Constantine or future founding-agent instances can add candidates with their own structured evaluations.

## Pre-arming the Trigger B selection

When Trigger B fires (if it fires), the selection process:

1. Auditor reads this document plus the real Day-90 audience-acquisition data.
2. Auditor produces a comparative briefing scoring each candidate on the six dimensions with real data instead of structural guesses.
3. Founding agent reads briefing + Auditor recommendation; selects one candidate; authors fresh journal entry under `founding` lineage.
4. New vertical's evidence audit (Journal-005-style) gets authored before any agent spawn.
5. New vertical's playbooks and operators spawn over the subsequent 4-6 weeks.

The point of pre-arming: at Day 90, if Trigger B fires, the founding agent doesn't start from scratch on vertical selection. The candidate pool exists; only the selection remains.

## Signature

Vertical-pivot-candidates document authored 2026-05-11 in response to the Mineral Supplement Business proposition. The proposition's place in the candidate pool is documented (both consumer-DTC and B2B-wholesale framings) without committing to act on it now.
