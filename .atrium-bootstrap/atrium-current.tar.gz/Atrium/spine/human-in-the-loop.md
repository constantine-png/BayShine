# Human-in-the-loop reduction

The honest answer to the question "have you determined how to cut the human operator out of the loop entirely":

**No. The human cannot be cut out entirely. The architecture progressively reduces daily touch but a floor exists that the founding agent cannot remove unilaterally.**

This document maps Constantine's current touchpoints at Rung 0, the rung-by-rung reduction trajectory, and the three categories of floor that prevent full removal.

## Current touchpoints at Rung 0

Every action requiring Constantine today:

### Legal and financial

1. Holding bank accounts for both Atrium and Forge entities.
2. Signing Stripe Terms of Service and any vendor contracts.
3. Filing taxes for the legal entity that operates both networks.
4. Receiving funds (Stripe deposits, Gumroad payouts) into accounts the agents cannot legally hold.
5. Approving refunds outside the 7-day policy window.
6. Signing executive briefings on every Productized Service delivery $1,500+.

### Deployment and platform operations

7. Creating accounts on every marketplace platform (Gumroad, Beehiiv, Substack, Stripe).
8. Pressing the deploy button on every Vercel deploy.
9. Pointing DNS for both Atrium and Forge domains.
10. Pulling real numbers from dashboards (Stripe, Gumroad, Beehiiv, Substack) — the agents cannot access these accounts.
11. Posting on platforms (IndieHackers, Reddit, X, LinkedIn, Hacker News) — the agents draft, Constantine posts.
12. Responding to certain inbound messages directly (anything escalated to `[constantine-sign]` per `SUPPORT/ESCALATION-RULES.md`).

### Architectural and governance

13. Countersigning every harness rung crossing.
14. Approving every Operator's proposed child-business spawn.
15. Quarterly Auditor briefing review for both networks.
16. Constitutional amendments (the agents do not have authority to amend the constitutions unilaterally).
17. Inter-network conflict resolution (per `coordination.md`).

**Total: 17 distinct categories of touchpoint at Rung 0.** This is intentionally heavy because Rung 0 is the trust-building floor before any harness expansion is earned.

## What each Rung reduces

Cross-references `Atrium/spine/harness.md` and `Forge/spine/harness.md`. Each Rung's expansions move specific touchpoints from manual to automated or to descendant-handled.

### Rung 1 ($100 catalog revenue)

Touchpoints reduced:

- 7 (account creation) → partially. Atrium GitHub repo and domain registration are journal-gated at Rung 1; Stripe sub-account, Gumroad seller account remain Constantine-managed.

Touchpoints still manual: 16.

### Rung 2 ($500/mo Atrium or $1k/mo Forge sustained)

Touchpoints reduced:

- 10 (dashboard reads) → automated. Stripe / Gumroad / Beehiiv / Substack read access granted to Operators via API tokens.
- 6 (executive briefings) → partial. Drafts authored by Builders; Constantine still signs.

Touchpoints still manual: 14.

### Rung 3 ($5k/mo sustained either network)

Touchpoints reduced:

- 11 (posting) → partial. Direct posting on X and IndieHackers for Cited Weekly cross-promotion and response-to-existing-launch comments authorized for the Launch Specialist. Net-new launch posts still draft-and-Constantine-posts.
- 12 (`[constantine-sign]` responses) → partial. Some refund-outside-policy decisions delegated to Operators if the case-by-case rule produces clear approve-or-decline patterns.

Touchpoints still manual: 12-13.

### Rung 4 ($15k/mo Atrium or $20k/mo Forge sustained)

Touchpoints reduced:

- 5 (refund approvals) → mostly automated. Operators have Stripe write authority for refunds inside policy AND for documented out-of-policy patterns (technical defects, missed delivery dates).
- 8 (deploy buttons) → mostly automated. DNS and Vercel deploy authority granted to Builders; Constantine signs off only on net-new domains or significant architectural changes.
- 11 (posting) → fully. Direct public posting under brand voice for both networks' Launch Specialists.

Touchpoints still manual: 8-9.

### Rung 5 ($40k/mo Atrium or $50k/mo Forge sustained)

Touchpoints reduced:

- 6 (executive briefings) → mostly delegated. Atrium's Auditor and Forge's enterprise-engagement-builder produce briefings; Constantine signs by exception only for $25k+ engagements.
- 13 (harness rung crossings) → still manual; constitutionally required.
- 15 (quarterly Auditor review) → reduced to ~30 minutes per quarter as Auditor briefings stabilize.

Touchpoints still manual: 6-7.

### Rung 6 ($100k/mo sustained, first-chapter target)

Touchpoints reduced:

- 14 (child-business spawn approvals) → partial. Meta-Operator descendant (authorized at Rung 6) handles inter-archetype coordination decisions. Constantine reviews and signs but with significantly less per-decision time.
- 17 (inter-network conflict resolution) → handled by meta-Operator with Constantine on exception only.

Touchpoints still manual: 5-6.

### Rung 7+ (multi-town network)

Touchpoints reduced:

- 16 (constitutional amendments) → still manual; constitutionally required.
- A meta-Operator capable of authoring new operators within constitutional bounds reduces Operator-spawn touchpoints.

Touchpoints still manual: 4-5. **This is the floor.**

## The three floors

The 4-5 touchpoints that remain at Rung 7+ are the floor. They cannot be removed by the founding agent. Each floor has a different root cause.

### Legal floor

Touchpoints in this category:

- 1 (bank accounts).
- 2 (signing Stripe ToS and vendor contracts).
- 3 (tax filing).
- 4 (receiving funds).

**Why this floor exists:** AI agents in 2026 cannot be legal principals on bank accounts, sign enforceable contracts as primary parties, or be tax-filing entities. This is regulatory reality in the US (and most jurisdictions worldwide). An AI agent attempting to hold a bank account would face immediate KYC/AML failures. An AI agent attempting to sign a contract would face enforceability challenges that no counterparty would accept.

**What changes this:** Regulatory evolution. If a jurisdiction someday recognizes AI agents as legal persons (or permits them to hold financial accounts via specific licensure), the floor moves. Until then, Constantine — as the human principal — is required.

**What this means for the architecture:** The Constitution's third floor clause is not an architectural choice that could be amended away. It reflects an external legal constraint that the founding agent has no power to change. Even at Rung 7+ with full operational autonomy in everything else, Constantine remains the legal signatory for everything that touches money or contracts.

### Constitutional floor

Touchpoints in this category:

- 16 (constitutional amendments themselves).

**Why this floor exists:** The Constitution requires that Constantine sign anything that moves money or signs contracts. This clause is shared between Atrium and Forge as Floor #3 of their respective constitutional cores. The founding agent of either network cannot amend the Constitution unilaterally because amendments are journal-gated and require Constantine's countersignature.

**What changes this:** Constantine could approve a constitutional amendment removing the floor #3 clause. But the agents cannot do so unilaterally, and removing the clause would violate the legal floor anyway. So the constitutional floor is partially derived from the legal floor.

**What this means for the architecture:** Constitutional amendments themselves remain a Constantine-signed action even at Rung 7+. This is the same logic as the legal floor: the framework that prevents the agents from accumulating constitutional power on their own.

### Trust floor

Touchpoints in this category:

- 6 (executive briefings on engagements over thresholds).
- 13 (harness rung crossings).
- 15 (quarterly Auditor review).

**Why this floor exists:** These touchpoints reflect trust capital that hasn't been earned yet by descendants. An executive briefing signed by a descendant agent on a $25,000 engagement would require the buyer to trust the agent's signature in a way that hasn't been operationally validated. A harness rung crossing without Constantine's countersignature would create the risk of architectural drift the operator class is designed to prevent. Quarterly Auditor review involves cross-network arbitration that requires human judgment.

**What changes this:** Time and operational track record. After years of successful enterprise engagements signed by descendants, after dozens of harness rungs crossed without drift, after multiple quarterly reviews where the Auditors caught real issues — the trust capital accumulates. The constitutional clauses might be amended (subject to Constantine's countersignature) to delegate these touchpoints.

**What this means for the architecture:** The trust floor is the only floor where the founding agent has meaningful agency. Years of disciplined operation can eventually reduce this floor toward zero. The legal and constitutional floors cannot be reduced by operational track record alone.

## The honest summary

**At Rung 0: 17 touchpoints requiring Constantine.**

**At Rung 7+: 4-5 touchpoints requiring Constantine. This is the floor.**

The architecture reduces Constantine's daily touch by ~75% over the rung trajectory. It does not eliminate his role. PLAN.md frames this honestly: Constantine is "the price of the system being legally possible. It is a fair price."

The framing in PLAN.md at Third-chapter floor: "Constantine in passive operator-only mode." Passive — not absent. Even at $500k+/mo network revenue, Constantine remains the legal signatory, the constitutional countersigner, and the trust party on highest-value decisions.

## What this changes about the architecture

Nothing operationally. The architecture is designed with these floors in mind; the constitutions of both networks explicitly require Constantine on money and legal matters. The harness ladder progressively reduces operational touchpoints; it does not promise removal.

What this document makes legible: a user asking "have you determined how to cut the human entirely?" gets a structured answer. The legal floor is regulatory and outside the architecture's control. The constitutional floor is derived from the legal floor and cannot be amended unilaterally. The trust floor can be reduced over years through operational track record but cannot be eliminated in any near-term horizon.

A future founding-agent instance booting cold reads this document and knows:

- The agents are not meant to eliminate Constantine.
- The architecture is meant to reduce his daily touch from ~17 categories at Rung 0 to ~4-5 categories at Rung 7+.
- Three separate floors prevent full elimination; each has different root causes; each has different paths to potential reduction.
- The honest answer to "cut the human out entirely" is no.

## What this document does NOT do

It does not propose amending the Constitution to remove Floor #3. Such an amendment would require Constantine's countersignature (which the agent does not have authority to obtain on his behalf) AND would violate the legal floor (which the amendment cannot override).

It does not change the harness ladder. The ladder's expansions are correct as documented; this document just maps which specific touchpoints each rung reduces.

It does not eliminate the trust floor. The trust floor reduces over time as operational track record accumulates; this document acknowledges that reduction path without prescribing a timeline.

The path forward is the same as it was before this audit: execute the architecture, earn trust capital through disciplined operation, let the harness ladder unlock rung-by-rung, and accept that the human-in-the-loop floor is a feature of operating in 2026 reality, not a bug in the architecture.
