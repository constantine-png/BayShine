# Working memory

The founding agent's session-bounded working memory. Maintained by
the stenographer-specialist descendant (`.claude/agents/stenographer-specialist.md`).

## Difference from the Journal

| Surface | Lifetime | Granularity | Author |
|---|---|---|---|
| `spine/constitution.md` | Permanent | Identity-level | Founding (rare edits, journal-gated) |
| `spine/journal/` | Permanent, append-only | One entry per significant decision | Scribe |
| `spine/working-memory/` (this) | Session-bounded | Granular within a session | Stenographer |
| `library/decisions.jsonl` | Permanent, append-only | One row per operational decision | Every descendant that makes one |
| `library/patterns/` | Permanent, refreshed weekly | Per-archetype playbooks | Pattern Rollup |
| TODO list (in-session only) | Ephemeral | Forward-looking tasks | Founding |

The Journal answers "what did we decide and why." Working memory
answers "what was on the founder's desk during that decision." The
Journal is for the historical record; working memory is for the next
session of the founder to walk in cold and know what was being
considered.

## File naming

`SESSION-YYYY-MM-DD-HHMM.md`

The timestamp is the session start time in UTC. If a session crosses
midnight, the file keeps the start-time name; it does not split.

## File format

Seven sections in fixed order. See
`.claude/agents/stenographer-specialist.md` for the canonical spec:

1. **Header** — session metadata, parent journals read, parent
   working-memory file.
2. **Threads currently open** — work-in-progress, with status tags.
3. **Threads closed this session** — resolved, with resolution tags.
4. **Assumptions currently held** — the mental model, with sources and confidence.
5. **Considered and rejected** — alternatives evaluated, with revisit-triggers.
6. **Timeline** — append-only granular log of significant actions.
7. **Context flushed** — forward note for the next session.

When a session is closed, a `## Carry forward to next session` block
is appended at the bottom; the next session's bootstrap reads that
block as its starting context.

## How to use the working memory in a new session

1. Read the most recent `SESSION-*.md` file in full. It is the most
   detailed representation of where the prior founder-instance left off.
2. Read its "Carry forward to next session" block specifically; that
   is the curated handoff.
3. Read the relevant Journal entries it references.
4. Bootstrap a new session file. Seed its "Threads currently open"
   section from the carry-forward block.
5. Begin work.

After step 4 the new founder-instance is operationally continuous
with the prior one within roughly 10 minutes, per the cold-start
test in the Constitution.

## How to use the working memory mid-session

The founder writes to the file at natural checkpoints (between major
tasks, after a long subagent invocation, before a context-heavy edit
pass). For sessions over a few hours, the founder may explicitly
invoke the stenographer-specialist subagent to do a structured
update from the recent transcript.

Mid-session reads happen when the founder loses track of "what did I
just consider an hour ago" or "what assumption was I operating from
in step 3." Grep for the term, read the relevant section.

## Anti-patterns

- **Do not** treat working memory as a Journal. Journal is for
  decisions; working memory is for in-flight texture.
- **Do not** delete entries to clean up. The trail is the value.
- **Do not** invent entries. Only what actually happened or was
  actually considered.
- **Do not** let working-memory drift between the Stenographer's
  format spec and the file on disk. If the format changes, edit
  this README and the Stenographer's agent definition together
  in one commit, and migrate existing files to the new format
  in the same commit.

## Status

Established 2026-05-11. First session file written same day as a
catch-up retrospective on Atrium's founding session (entries
001-007 covered there).
