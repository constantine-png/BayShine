# ROI evaluation

The honest answer to the question "have you evaluated the businesses and determined these are the best ROI possible, and how do you know that":

**Partially. The evaluation was narrow. A priori proof of best ROI is unobtainable. The architecture is a defensible bet, not a proven optimum. This document closes the gap between assertion and validation by mapping eight alternative paths that were never compared against, then proposing three pivot triggers that turn the bet into an empirically-testable claim.**

## What Journal 005 did compare

Journal 005 (the evidence audit that demoted Audit-Tool Network from flagship and promoted Information Products + Productized Services) compared three categories within entrepreneurship for AI-search-for-local-service-business:

1. **Audit-Tool Network** (B2B SaaS subscriptions to local service businesses). Demoted to background build because the evidence base for solo cold-start in this category is weak; the closer-less constraint is violated by required sales motion.

2. **Information Products** (Gumroad/Lemon Squeezy info products at $9-$99). Promoted to flagship based on extensively documented operator evidence: Sahil Lavingia ($11M+ creator earnings), Pieter Levels ($1M+ on books), Marc Lou ($1.5M+ on ShipFast).

3. **Productized Services** (Stripe Direct fixed-scope engagements at $499-$25,000). Promoted to flagship based on Tiny Capital portfolio evidence and IndieHackers solo-operator examples.

**Why this was a narrow choice set.** The comparison happened within a single domain (entrepreneurship for AI-search-for-local-service-business) and a single capability profile (programming + writing + expert-tool capability). The audit asked: "given that we are running businesses in AI search for local service operators, which categories should we ship first?" It did not ask: "given that we have time and capability, what's the best use of both?"

## What Journal 005 did NOT compare

Eight alternative paths the founding agent could have pursued instead, each honestly evaluated.

### 1. Not running businesses (consulting / AI-labor / employment)

**The alternative:** Constantine sells AI labor as a consultant at $50-$200/hour, or accepts a salaried position at an AI-adjacent company, or freelances on Upwork/Toptal/etc.

**Expected value:** $100,000-$400,000/year cap, set by Constantine's available hours. No compounding past hourly ceiling. Predictable income; minimal variance.

**Does this dominate the chosen architecture?** No, IF the architecture works as projected. Atrium + Forge combined month-3 projection ($15k-$24k) plus month-6 trajectory ($30k-$50k) plus the compounding-MRR of Forge subscriptions exceed the $400k/yr consulting ceiling within 12-24 months at expected rates. The architecture's expected value is higher IF it works.

**Risk profile difference:** Consulting income is predictable; the architecture has high variance (could be zero at month 6, could exceed projections). Risk-adjusted, consulting may dominate at the lowest percentiles but does not dominate at the median or upper tail.

**Conclusion:** Does not dominate. The architecture is the higher-expected-value bet for someone willing to absorb the variance.

### 2. Different industry verticals (B2B SaaS, healthcare ops, fintech, e-commerce)

**The alternative:** Same operational approach but applied to different markets — selling tools to enterprise B2B buyers, building healthcare back-office software, fintech compliance products, or e-commerce optimization tools.

**Expected value:** Higher AOV (B2B SaaS at $500-$5,000/mo per customer; healthcare ops at $10k+ per engagement; fintech with regulatory moat). But significantly longer sales cycles (3-12 months B2B SaaS, 6-18 months healthcare, 9-24 months fintech).

**Does this dominate the chosen architecture?** No, for a solo operator at $0 starting capital. Long sales cycles are catastrophic at months 1-6 when no revenue exists. The architecture's choice of local service businesses prioritizes shorter sales cycles (free schema generator → $29 schema pack → $79 playbook → $499 audit → $2,500 setup) that produce revenue at multiple price points within weeks, not quarters.

**Conclusion:** Does not dominate at current capital position. Would dominate for a well-capitalized operator with 12+ months of runway and no near-term revenue pressure.

### 3. Different geographies (international, EU, APAC)

**The alternative:** Apply the same architecture to international markets where AI search is less competitive (EU, APAC, LATAM).

**Expected value:** Less-saturated markets may have higher conversion per discovery; markets with strong digital infrastructure but slower SEO/AI-search adoption (Germany, Japan, parts of South America) could yield faster early traction.

**Does this dominate the chosen architecture?** No, without geographic context Constantine doesn't have. Constantine is US-based with US local-service-business knowledge (BayShine is in Pasco County, FL). Entering EU or APAC requires either localization (language, cultural, regulatory) or a co-founder with local context. The architecture's choice of US local service businesses leverages capability already present.

**Conclusion:** Does not dominate without geographic capability the operator already has. Could be a Rung 4+ expansion at the international tier of Forge's harness ladder.

### 4. Autonomous trading / DeFi / on-chain agent strategies

**The alternative:** Run autonomous AI strategies in financial markets — algorithmic trading, DeFi yield farming, MEV bots, prediction markets, etc.

**Expected value:** Theoretical EV is wide — top decile autonomous trading strategies can return 100%+ annually; bottom decile wipe to zero in single events. Median is probably negative after fees, taxes, and infrastructure costs.

**Does this dominate the chosen architecture?** No, for two reasons. First, the risk profile is incompatible with bootstrap discipline (the Atrium constitution prohibits violating safety mechanisms; trading strategies often require running unsigned code, opaque models, and bypassing normal counterparty verification). Second, Constantine's stated risk tolerance (Constitution implies bootstrap discipline; no invented data; quality before scale) is misaligned with strategies that can wipe to zero.

**Conclusion:** Does not dominate at acceptable risk for this operator. Could dominate at the variance tail for an operator with explicit risk-tolerance for it.

### 5. Building a single VC-fundable SaaS instead of a portfolio

**The alternative:** Pick the single highest-potential product in the current catalog (likely Schema Doctor Pro or a similar developer-tier SaaS) and pursue VC funding to build it at venture scale.

**Expected value:** If it hits, 10-100x larger than the current architecture's projection. ~90% failure rate; 12-24 month time-to-fundability; requires fundraising effort (decks, investor conversations, term sheet negotiation) that's outside the current operational discipline.

**Does this dominate the chosen architecture?** Does not clearly dominate. Expected value (probability-weighted) is competitive but not dominant. Risk profile is different (binary high-variance vs. moderate-variance compounding). Time-to-revenue is much longer (12+ months to first dollar via VC path vs. 14 days via the chosen architecture).

**Conclusion:** Does not clearly dominate. Could dominate for an operator with VC connections and risk-tolerance for the binary outcome. The current architecture preserves optionality (any single product within the catalog could pivot to VC-funded if traction warrants).

### 6. Content creation / Constantine as personal brand

**The alternative:** Constantine builds a personal brand — YouTube channel, podcast, paid newsletter at scale — and monetizes via course sales, sponsorships, consulting from inbound.

**Expected value:** Top creators in adjacent niches (SEO, AI tools, indie hacker space) reach $500k-$2M/yr in revenue, but median creator income is well below the architecture's projection. Time-to-meaningful-revenue is 12-24 months for content creation; 30 days for the architecture's flagships.

**Does this dominate the chosen architecture?** No, as a primary play. The architecture already partially incorporates content creation via Forge Weekly (named operator brand) and Cited Weekly. Doubling down on content creation as the primary play would underleverage the productized services and information products that have shorter time-to-revenue.

**Conclusion:** Does not dominate as primary play; complementary to current architecture. Forge's named-operator branding already captures some of the upside.

### 7. Acquiring an existing small business via search fund / SBA loan

**The alternative:** Use SBA loan or search fund capital to acquire an existing small business (revenue: $500k-$5M/yr) at 3-5x EBITDA multiple. Operate the acquired business.

**Expected value:** Predictable income from day 1 if the acquired business is healthy. Capital requirement: $100k-$1M in SBA loan + personal guarantee + operator commitment.

**Does this dominate the chosen architecture?** Mixed. Acquired-business income is more predictable but also more constrained (operating an existing business is a full-time job; doesn't leverage Atrium/Forge AI infrastructure already built). For a generalist operator without AI-search-specific capability, acquisition may dominate. For an operator with the specific architecture already constructed, the architecture has higher leverage on prior work.

**Conclusion:** Does not dominate for this operator's specific capability profile, but is a valid alternative for an operator without the AI-search architecture already built.

### 8. Selling the agent infrastructure itself to other founders (meta-play)

**The alternative:** Make the architecture itself (the constitutions, the descendant patterns, the dual-network sibling model, the harness ladder) the primary product. Sell it to other indie hackers and operators as a framework for autonomous business networks.

**Expected value:** Unknown. The category does not yet exist as a recognized product space. Operating frameworks for indie hackers are typically courses ($500-$2,500), templates ($50-$500), or paid Discord communities ($30-$100/mo). None of these scale to the per-customer LTV that productized services do.

**Does this dominate the chosen architecture?** Partial overlap. Forge's DevTools archetype-direction (npm packages, GitHub Actions, IDE extensions for the discoverability specialists) already monetizes some infrastructure-as-product. The fuller meta-play (selling the constitutions and dual-network framework) is a long-tail option that gets validated only after the current architecture proves its model.

**Conclusion:** Does not dominate as a primary play at Rung 0. Becomes more interesting as a secondary play at Rung 3+ when the architecture has track record to point to. The meta-play is path-dependent on the primary play working first.

## Why a priori ROI proof is unobtainable

The chosen architecture has not run yet.

Counterfactual ROI proof — proving that this architecture beats every alternative on expected value at acceptable risk — requires one of:

1. **Historical data on identical setups.** Does not exist. No previously-operated dual-network sibling architecture with these specific catalog tiers running these specific products has produced measurable returns. The closest reference points (Sahil Lavingia's Gumroad portfolio, Pieter Levels' indie portfolio, Tiny Capital's productized services) are similar in operational pattern but not identical in product mix or two-network split.

2. **The experiment running with measurement.** Has not started. Constantine has not deployed any of the staged products as of this document's authoring. Real probe data, real conversion rates, real customer acquisition cost, real LTV — none of these exist yet.

3. **Theoretical model with calibrated parameters.** Possible but constrained. The Money Levers playbook documents seven revenue levers with order-of-magnitude unit economics. The FIRST-30-DAY-METRICS document provides projected ranges. Both are calibrations from comparable operators, not measurements from this architecture. They yield "this is the architecture's stated capacity" claims, not "this is the architecture's measured return" claims.

The honest position: **a priori ROI proof is impossible. The proof, if any, comes from running the architecture and measuring outcomes against the documented projections.**

## Empirical validation framework

The proof framework that turns the architecture from "claim" to "validated bet" over time.

### Kill criteria (when the architecture is fully abandoned)

The architecture is killed entirely if all three of these fire:

1. **Day 30 — zero revenue.** Cumulative Atrium revenue plus cumulative Forge revenue is below $100 at Day 30 of operations (Day 30 measured from first product deployment, not from this document's authoring date).
2. **Day 60 — demand probe failure.** The IndieHackers and r/LocalSEO demand probe posts produced fewer than 3 substantive replies AND zero beta-buyer signups across both networks.
3. **Day 90 — secondary probe failure.** A second-wave outreach attempt (different framing, possibly different vertical positioning) produced no measurable improvement.

If all three fire, the architecture has demonstrated it cannot acquire even a single buyer at Rung 0 cost. Abandoning is the rational response. Constantine pivots to consulting / employment / one of the alternatives in section 2.

If two of three fire but one does not, the architecture stays in operation pending the Day 180 review.

### Pivot criteria

The architecture stays but materially shifts under any of three specific signals.

**Trigger A — income stability pivot (evaluated at Day 30)**

**Signal:** Day 30 metrics fall below 50% of the FIRST-30-DAY-METRICS conservative case across both networks. Specifically: Atrium cumulative revenue under $250 AND Forge cumulative waitlist under 8 signups.

**Recommended action:** Constantine accepts consulting / AI-labor work for income stability while keeping Atrium / Forge running as low-time-investment side projects. The architecture survives; the priority order changes from "primary income" to "side project that compounds while consulting pays rent."

**Why this is the right pivot:** Below 50% of conservative case at Day 30 indicates the audience-acquisition cost is higher than the architecture's projected funnel can sustain. Continuing at full-time investment burns runway without proportional return. Consulting income at $100-$200/hr × 20 hrs/week = $96k-$192k/year, which gives 12+ months of runway for the architecture to find product-market fit at part-time investment.

**Trigger B — vertical pivot (evaluated at Day 90)**

**Signal:** At Day 90, the combined audience-acquisition lever (Schema Generator total visits + Forge Weekly subscribers + Cited Weekly subscribers + demand-probe DMs + Citation Watch waitlist + Schema Doctor Pro waitlist + sales-page visitor counts) has produced fewer than 500 qualified contacts across both networks.

**Recommended action:** Reframe entirely. The local-service-business vertical may be wrong for AI-search distribution at this moment. The architecture's chassis (constitution, harness ladder, dual-network split, operator playbooks) remains; the vertical changes.

Candidate vertical pivots:

- **B2B SaaS marketing teams.** Higher per-customer value; existing SEO-tool buyer profile in the market.
- **Healthcare practice ops (dental, optometry, veterinary).** High per-location revenue; under-served by AI search tooling.
- **Multi-location franchise systems.** Captive audience via franchisor relationships; higher engagement value per closed account.
- **D2C e-commerce sellers on Shopify or BigCommerce.** Different schema patterns (Product over LocalBusiness) but similar AI search dynamics.

The pivot involves authoring a new evidence audit (Journal entry under `founding` lineage) for the chosen new vertical, repositioning the existing catalog where translatable, and shipping new products specific to the vertical.

**Why this is the right pivot:** Under 500 contacts at Day 90 across both networks indicates the audience exists but is not reachable through the current vertical's channels. Other verticals have different distribution channels (LinkedIn for B2B SaaS, professional associations for healthcare, franchisor relationships for franchise systems). A vertical pivot tests whether the architecture's structural choices work in a different audience context.

**Trigger C — network consolidation pivot (evaluated at Day 180 / Month 6)**

**Signal:** After 6 months of operation, Constantine reports more than 10 hours per week sustained on cross-network coordination work (not catalog operation work). Specific examples: shared specialist calendar arbitration consuming a half-day per week; cross-network buyer routing decisions consuming an hour per day; voice-drift auditing across both networks consuming 4+ hours per quarter.

**Recommended action:** Fold one network into the other. Either Forge absorbs Atrium (named-operator brand wins) or Atrium absorbs Forge (faceless brand wins). The choice depends on which network has more revenue at the Day 180 mark and which voice has higher customer-conversion data.

**Why this is the right pivot:** The dual-network architecture's bet is that diversity of voice and discipline covers more market than a single network can. If the diversity costs more in coordination overhead than it gains in market coverage, the bet is failing. Network consolidation reduces overhead to zero and refocuses operator capacity on the surviving network.

The consolidation is not failure; it's data-driven simplification. The lessons from both networks compound into the surviving network's playbook.

### Success milestones (when the bet is winning)

Three milestones at which the architecture is empirically validated (and no trigger has fired):

1. **Day 30 — at-or-above conservative case.** Atrium cumulative revenue exceeds $500 AND Forge cumulative waitlist exceeds 25 signups across both networks.

2. **Day 90 — compounding signal.** Combined newsletter subscribers exceed 200 free + 10 paid AND Atrium MRR-equivalent (subscription + retainer) exceeds $500/mo.

3. **Day 180 — escape velocity.** Combined revenue (Atrium + Forge) exceeds $5,000/mo for 60 consecutive days. This is Forge Rung 3 trigger for Forge AND approaches Atrium Rung 3.

At Day 180 with no trigger fired AND success milestones met, the architecture has empirically demonstrated it works. The "best ROI possible" question becomes answerable in retrospect: this architecture produced $5k+ MRR by Day 180; whatever alternative the operator might have pursued would have had to beat that number with the same input.

### Comparison benchmarks

The opportunity cost of operating the architecture is Constantine's next-best income source — at his stated capability profile, consulting at $100-$200/hr × 20 hrs/week sustained = approximately $8k-$16k/month gross. Net of taxes and benefits the operator would otherwise have, perhaps $5k-$10k/month.

The architecture must clear this benchmark at the median to be the right primary play. At Day 180:

- If combined revenue is below $5k/mo (the lower bound of consulting net) → Trigger A fires (income stability pivot).
- If combined revenue is between $5k-$10k/mo → architecture matches the consulting floor but isn't yet dominantly better; continue at full investment but acknowledge the bet hasn't won yet.
- If combined revenue is above $10k/mo → architecture is dominantly better than consulting on revenue terms; the bet is winning.

## Active recommendation

**The current architecture is not clearly dominated by any of the eight alternatives evaluated above for a solo operator at $0 starting capital with the dual-network advantage already built.**

The architecture stays as the primary play, with three explicit pivot triggers monitoring whether that calculus changes:

- **Trigger A (Day 30):** If revenue under 50% of conservative case → income stability pivot to consulting + side projects.
- **Trigger B (Day 90):** If qualified contacts under 500 across both networks → vertical pivot to B2B SaaS, healthcare ops, franchise systems, or D2C e-commerce.
- **Trigger C (Day 180):** If coordination overhead exceeds 10 hours per week sustained → network consolidation (fold Forge into Atrium or vice versa).

Each trigger is a measurable signal, not an opinion. Each has a specific date. Non-evaluation at the corresponding date is a constitutional drift flag for the Auditor at quarterly review.

## What this evaluation changes

Operationally, nothing immediately. The architecture stays in place. Constantine proceeds with the GO-LIVE master playbook. The first 30 days unfold as projected (or don't).

What this evaluation makes legible: the architecture is a bet, not a proof. The bet has explicit win conditions, explicit loss conditions, and explicit pivot conditions. Each is measurable at a specific date.

A buyer asking "have you proven this is best ROI?" gets a structured answer: a priori proof is unobtainable; empirical validation comes through the framework above; the architecture is the highest-expected-value bet evaluated within a realistic alternatives set for the current operator.

A future founding-agent instance reads this document and knows:

- Eight alternatives were considered and none clearly dominates.
- The proof of best ROI cannot exist before the experiment runs.
- Three pivot triggers govern whether to continue, pivot, or abandon.
- The framework holds the bet accountable rather than allowing assertion to substitute for measurement.

## The honest summary

The chosen architecture is a defensible bet within a narrow choice set. Not a proven optimum. Three pivot triggers are pre-armed at Days 30, 90, and 180. If any fires, the recommendation moves from "continue" to a specific named pivot (consulting + side projects; vertical change; network consolidation). If none fire, the bet holds and the architecture earns its place as the primary play.

This is the answer to "how do you know" and "how can you prove that": the knowledge comes from measurement against pre-arming triggers; the proof, if any, accrues through operational track record. Anything else would be assertion dressed as proof.
