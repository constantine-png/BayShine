# 016 — Newsletter runway: 5 pre-drafted issues

date: 2026-05-11
agent_lineage: founding
artifacts:
  - BayShine .atrium-deliverables/04-cited-weekly-002/issue-draft.md
  - BayShine .atrium-deliverables/04-cited-weekly-003/issue-draft.md
  - BayShine .atrium-deliverables/04-cited-weekly-004/issue-draft.md
  - BayShine .atrium-deliverables/FORGE-PRODUCTS/05-forge-weekly-002/issue-draft.md
  - BayShine .atrium-deliverables/FORGE-PRODUCTS/06-forge-weekly-003/issue-draft.md

## Context

Continuing under "continue until I tell you to stop." Both networks have Issue 1 of their newsletters drafted (Cited Weekly Issue 001 and Forge Weekly Issue 001). Each subsequent issue currently requires a fresh authoring session.

Pre-drafting the next 3 Cited Weekly issues and the next 2 Forge Weekly issues gives both operators 4-6 weeks of automation-ready content. The Operators (operator-newsletter for Atrium, operator-forge-products for Forge) can publish on cadence without each issue blocking on the founding agent's authoring time.

This is a velocity-multiplier pattern — same as the launch posts authored in advance per the LAUNCH-SEQUENCE.md. Constantine's execution becomes "publish the staged issue at the right send-time" rather than "author the issue this week."

## Decision

Five issue drafts, each in its respective network's voice.

### Cited Weekly Issue 002 (Day 21)

**Subject:** "Schema Pack v1.5 results from the first 7 days"

Lede: Schema Pack v1.5 shipped 7 days ago; 3 data points from the first week of sales — vertical-typed subclass impact, FAQPage schema gap, service-area scope as the most-overlooked element.

Schema Watch section: `AutoWash` type tree.

Vertical Spotlight: HVAC. Citation rate ranges (40-80% per engine) and the 4 structural fixes that moved citation rates fastest.

Reader Action: cross-promotes Schema Pack v1.5 ($39), Bundle ($45), GEO Playbook v0.5 ($79). Mentions AI Citation Audit as next-week launch.

### Cited Weekly Issue 003 (Day 28)

**Subject:** "The GEO Setup productized service: what changed in 10 days"

Lede: GEO Setup launched Day 23; first-day inquiry patterns showed 4 recurring buyer questions. Citation-readiness rewrites are the most-asked-about deliverable. AI engines respond to citation-readiness changes faster than to pure schema changes.

Schema Watch: BreadcrumbList — the most-underused schema type.

Vertical Spotlight: Plumbing emergency service. 24/7 service market dynamics, schema patterns that work, repeatable across HVAC / locksmith / restoration.

Reader Action: GEO Setup ($2,500) primary, AI Citation Audit ($499) teaser, GEO Playbook v0.5 ($79) DIY alternative.

### Cited Weekly Issue 004 (Day 35)

**Subject:** "Audit vs Setup: when to buy which"

Lede: AI Citation Audit ($499) and GEO Setup ($2,500) launched; both productized services covering related work at different scopes. Buyers ask "which is right for me?"

Decision tree: buy the audit if you have execution capacity OR you want data before $2,500 OR you're at multi-domain scale OR you're an agency. Buy the setup if you don't have execution capacity OR you want 90-day probe continuity OR constitutional fit (full-service tier).

Audit-to-setup upgrade pipeline math: $499 audit + $2,250 upgraded setup = $2,749 total ($249 premium vs direct setup). The premium buys 5 extra probe days, gap visibility, and risk transfer.

Schema Watch: `priceRange` field — concrete dollar ranges vs Yelp-style dollar-sign tiers.

Vertical Spotlight: Roofing insurance claims — different schema patterns for "best roofer in city" vs "roofer that works with [insurance company]."

Reader Action: question test for self-selection between audit and setup.

### Forge Weekly Issue 002 (Day 23)

**Subject:** "What the Schema Generator's first week revealed"

Lede: Schema Generator shipped a week ago; Constantine watched what people did with it.

Funnel data (projections from LISTING.md tracking targets pending real numbers):
- 380 visitors, 247 generations (65%), 198 copy/downloads (52%), 31 email captures (8%), 23 upsell clicks (6%), 17 waitlist signups (74% of upsell clicks).

Citation Watch waitlist math: 17 signups/week → 80/month → founding-100 cap fills in 5-7 weeks. Subscription compounding bet stated explicitly.

Schema Doctor Pro waitlist update: 8 signups in week 1, projected 6-10 weeks to founding-50 cap.

Bundle mechanic: Citation Watch + Schema Doctor Pro at $99/mo combined. If 20% of Citation Watch founding-100 bundle-upgrade: 20 × $65/mo = $1,300 additional MRR.

Forge voice throughout: em-dashes, named operator presence, direct paid-tier mentions, first-person ("I shipped," "I watched," "I saw").

Reader Action: Schema Generator (forge.example/generate), Citation Watch waitlist, Schema Doctor Pro waitlist. Atrium catalog as sibling reference.

Paid tier supplement: Schema Generator architecture deep dive, Forge's compounding math worksheet, direct Q&A with Constantine.

### Forge Weekly Issue 003 (Day 30)

**Subject:** "Schema Doctor Pro — schema as code for operators who treat schema as code"

Lede: 70% of audited sites have no schema, 20% have generic, 10% have specific-but-drifting schema. Schema drift is why Schema Doctor Pro exists.

Schema Doctor Pro positioning: 4 core capabilities (auto-generate on new pages, pre-deploy validation, drift detection, multi-domain support). $99/mo price reflects delivery cost differential vs Citation Watch's observational model.

Bundle mechanic restated: Citation Watch + Schema Doctor Pro at $99/mo combined, $79/mo founding-member rate. 20-40% expected bundle-upgrade rate from Citation Watch founding-100.

Schema Watch: webhook patterns per CMS (WordPress save_post, Astro build-time, Next.js server-side rendering, Webflow/Squarespace Zapier intermediation).

Reader Action: Schema Doctor Pro waitlist primary, Citation Watch as the single-domain alternative, Atrium catalog as sibling reference.

Paid tier supplement: WordPress plugin development walkthrough, bundle decision worksheet, direct Q&A with Constantine.

## Reasoning

### Why pre-draft 3-4 issues per newsletter

Each newsletter issue takes 2-4 hours of careful drafting if authored from scratch. Pre-drafting 3 issues for Cited Weekly + 2 for Forge Weekly = 10-20 hours of authoring batched into one session instead of spread across 5 weeks.

The Operator's role becomes: pull current week's metrics, update specific data points in the staged issue, publish. The structural content is staged; the just-in-time variables (actual sales counts, actual waitlist counts, actual probe results) are updated at publish time.

This is the same pattern as launch posts authored in advance per LAUNCH-SEQUENCE.md.

### Why these specific topics

Each issue's topic aligns with the LAUNCH-SEQUENCE schedule:

- Issue 002 (Day 21) covers Schema Pack v1.5 results because v1.5 launched Day 13-14.
- Issue 003 (Day 28) covers GEO Setup launch because GEO Setup launched Day 23-24.
- Issue 004 (Day 35) covers the audit-vs-setup decision because AI Citation Audit launched Day 30.
- Forge Weekly Issue 002 (Day 23) covers Schema Generator first-week data because the generator went live Day 16.
- Forge Weekly Issue 003 (Day 30) covers Schema Doctor Pro because the waitlist needs Forge Weekly's audience to drive signups.

Each issue's lede ties to a real event in the launch sequence. Reader Action sections cross-promote the right products at the right time per CROSS-PROMO.md's plan.

### Why issue voice differs by network

Cited Weekly issues stay in Atrium's voice: terse, faceless, "we" rather than "I," no em-dashes, no exclamation marks, no soft marketing. Numbers come with sources.

Forge Weekly issues stay in Forge's voice: em-dashes used, Constantine named in byline, first-person ("I shipped," "I saw"), direct paid-tier mentions, marketing-permissive within truth.

This is the dual-voice discipline applied to the highest-touchpoint customer-facing surface. If the two networks' newsletters drift toward each other in voice, the brand differentiation collapses; both Auditors flag.

## Alternatives considered

- **Pre-draft 6+ issues per newsletter.** Rejected. 5 issues across both networks covers 4-5 weeks of cadence; beyond that, the data points referenced in later issues are too speculative (e.g., Cited Weekly Issue 005 would reference data we won't have until week 6). Better to ship 5 well-grounded issues and author 6-onward from real data.

- **Ship issue drafts without explicit Reader Action cross-promotion plans.** Rejected. The cross-promotion is the most important business mechanic in the newsletters — each issue should drive specific traffic to specific products. Authoring without explicit cross-promotion would underutilize the audience.

- **Author Forge Weekly Issue 004 too.** Deferred. By Day 37 (Issue 004 send), real subscription-product metrics start landing. Authoring Issue 004 without those metrics would be speculation. The next session authors Issue 004 from real data.

## Uncertainty

- **Whether the funnel projections in Forge Weekly Issue 002 will match real data.** The Schema Generator hasn't been deployed yet; the projections are calibrated from typical free-tool funnel data, not from Forge's actual numbers. If actual numbers diverge by more than 50% in either direction, Issue 002 gets updated before send.

- **Whether 3-4 weeks of pre-drafted issues are too rigid.** Real-world events (Constantine's outreach landing differently, a viral post, a competitor launch) might warrant reshuffling the topics. The staged issues are starting points; the Operator can substitute current-event coverage if warranted, retaining the cross-promotion mechanic.

- **Whether Cited Weekly Issue 004's audit-vs-setup decision tree resonates.** The decision logic is calibrated for first-wave buyers who haven't yet been segmented by the catalog. By Issue 004, real buyer-segmentation data may inform a better decision tree. Update if warranted.

## What was performed in this session turn

1. Authored Cited Weekly Issue 002 (Schema Pack v1.5 first 7 days). ~280 lines.
2. Authored Cited Weekly Issue 003 (GEO Setup launch + citation-readiness methodology). ~250 lines.
3. Authored Cited Weekly Issue 004 (audit vs setup decision tree). ~270 lines.
4. Authored Forge Weekly Issue 002 (Schema Generator first-week data + Citation Watch waitlist math). ~290 lines.
5. Authored Forge Weekly Issue 003 (Schema Doctor Pro positioning + bundle mechanic). ~300 lines.
6. This Atrium Journal entry.
7. Next: decisions.jsonl rows; commit Atrium locally; commit and push BayShine.

Total: ~1,400 lines of newsletter content drafted ahead.

## Revisited

(Empty at first authorship.)

## Next operational actions

### Constantine

- The newsletter runway is now staged through Day 35 (Cited Weekly Issue 004) and Day 30 (Forge Weekly Issue 003).
- For each issue, update the specific data points (actual sales counts, waitlist signups, probe results) before send. The structural content holds; the just-in-time numbers reflect reality.
- Forge Weekly Issue 002 contains projected Schema Generator funnel data that needs replacement with actual numbers before send. If the actual numbers diverge by >50%, also update the Citation Watch waitlist math in Issue 002 to reflect the revised trajectory.

### Operator-newsletter (Atrium) and operator-forge-products (Forge)

- Monday before each Tuesday/Thursday send: pull metrics, update the staged issue's data points, voice-check, schedule.
- If a real-world event warrants substituting topic (viral post, competitor launch, etc.), the staged issue's structural content rotates to the following week.

### Founding agent (next session)

- Continue under "continue until I tell you to stop."
- Remaining leverage candidates: Forge Enterprise GEO Sprint + Program sales pages (decorative but completes catalog); Schema Pack v2 (24 verticals, major expansion); per-product Forge operator descendants; paid-acquisition-specialist for Forge; Atrium content site marketing hub.
