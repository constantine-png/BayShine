# 021 — Evaluating the Mineral Supplement Business proposition

date: 2026-05-11
agent_lineage: founding
proposition_source: principal (Constantine), "Mineral Supplement Business — Agent Brief"
referenced_artifacts:
  - spine/family-tree.md (just authored)
  - spine/roi-evaluation.md (the three pivot triggers framework)
  - spine/operator-coverage-audit.md
  - spine/identity.md

## Context

Constantine submitted a proposition: a Mineral Supplement Business, with two viable paths (Path A: Affiliate; Path B: White label dropship), and asked both Atrium and Forge to evaluate. The proposition is well-structured and the thesis ("no physical handling, lives in text and web, compounds") is consistent with autonomous-agent operational fit.

This entry is Atrium's evaluation through its constitutional discipline. Forge's parallel evaluation lives at `Forge/spine/journal/2026-05-11-008-mineral-supplements-evaluation.md`. A joint synthesis follows in Journal 022.

The evaluation is honest, not reflexive. Atrium does not auto-accept every proposition; the constitutional discipline requires evidence-based comparison and constitutional fit before commitment.

## Atrium's discipline applied

The five Atrium dimensions that govern whether a proposition fits:

### 1. Vertical fit

Atrium is calibrated for "AI search visibility for local service businesses." The current catalog covers nine verticals: mobile detailing, pressure washing, mobile car wash, HVAC, plumbing, roofing, electrical, pest control, landscaping. All are service businesses; all are local; all have AI-search-visibility as the primary value proposition.

Mineral supplements is **consumer-direct e-commerce**, not service business. Supplements is **physical product** (even with dropship, the product is physical), not service. Supplements buyers don't search "best plumber in Tampa" — they search "best magnesium glycinate" with different intent patterns.

**Fit assessment: poor.** Zero of the current vertical calibration translates. The discoverability specialists (schema, site-architecture, geo-ai-search, internal-linking, citation-readiness) are calibrated for LocalBusiness subclasses; supplements requires Product / Offer / Brand / NutritionInformation schema — a completely different schema.org subtree.

### 2. Closer-less constraint

Atrium's constitutional first-floor: no human sales motion. Inbound only. The catalog acquires customers through search visibility, organic content, and Cited Weekly audience compounding.

Path A (Affiliate) requires sourcing traffic. The proposition asks: "What's your traffic advantage? Skip Path A unless you have one or can build one cheaply." Atrium does have a nascent traffic advantage in its AI search visibility tooling — but that advantage is calibrated for local service business buyers, not supplement buyers. Building a supplement-buyer traffic source from zero is a different audience-acquisition project than what Atrium is set up for.

Path B (White label dropship) requires either paid acquisition (Atrium does not run paid ads per constitution Floor #2 derived discipline) or organic traffic (same audience-mismatch problem) or partnerships (requires outreach Atrium does not do).

**Fit assessment: poor on both paths.** Neither path leverages Atrium's existing audience-acquisition lever; both require building a new lever for a different buyer profile.

### 3. Evidence base for solo operators

Journal 005's evidence audit established the criterion: shipped revenue surfaces should have documented solo-operator track records.

The evidence base for solo dropship supplement operators is mixed-to-weak:

- **Many start, most fail.** Saturated category dominated by Amazon Basics, established brands (NOW Foods, Pure Encapsulations, Thorne, Garden of Life), and supplement-specific marketplaces (iHerb, Vitacost). Solo operators typically don't reach $5k/mo MRR within 12 months.
- **The successes are content-led.** Operators who succeed in supplements typically built an audience FIRST (newsletter, YouTube channel, Instagram) over 1-3 years, then monetized via affiliate or private-label. Pure dropship without audience first has a >90% failure rate.
- **Affiliate commissions are real but small.** 6-60% commission per sale at price points of $20-$50 typical = $1.20-$30 per sale. To clear $1k/mo from affiliate alone requires 50-300+ monthly attributed sales. At cold-start traffic levels, that's months of compounding.
- **Compliance burden is non-trivial.** FDA dietary supplement regulations (DSHEA), structure-function claims, allergen labeling, GRAS status. Solo operators frequently violate without knowing.

**Fit assessment: weaker than Information Products or Productized Services.** The Journal 005 evidence base for info products (Lavingia, Levels, Lou — documented $1M+ solo creators) does not translate to supplements where the failure rate is significantly higher and the time-to-revenue is significantly longer.

### 4. Constitutional voice fit

Atrium's voice rules: faceless brand, terse, no em-dashes, no exclamation marks, no soft marketing.

A faceless white-label supplement brand has lower trust capital than a named-operator supplement brand. Buyers putting supplements in their bodies want to know who's behind the brand. Faceless competes on price + Amazon-style review volume — neither of which Atrium can win at cold-start scale.

Supplement marketing typically uses the soft marketing language Atrium bans ("supports immunity," "promotes vitality," "feel your best"). Compliant supplement copy is constrained to structure-function claims authorized by DSHEA — which CAN be written in Atrium's terse register, but the marketing register most successful supplement brands use is opposite to Atrium's voice.

**Fit assessment: poor.** Atrium's voice is misaligned with successful supplement marketing patterns.

### 5. Architectural priority order

Per Journal 005's evidence audit and the supersession notice in PLAN.md, the current first-30-day priority is: Information Products → Productized Services → Newsletter → background builds.

Adding a supplement business at Day 0 — before any of the staged Atrium products have proven they convert — would:

- Split operator attention across three different verticals (AI search for local service + supplements + possibly Forge's enterprise pipeline).
- Defer validation of the current architecture's bet (Trigger A's Day 30 + Trigger B's Day 90 evaluation points).
- Introduce regulatory complexity (FDA compliance for supplements) that the current operator capacity isn't calibrated for.

**Fit assessment: counter to current priority order.**

## What Atrium considered and rejected

Three ways Atrium might justify accepting the supplement proposition:

### Option 1 — Atrium reframes its calibration to include consumer-direct e-commerce

**Rejected.** This is a fundamental change in what Atrium IS. The constitution, the identity document, the catalog, the family tree are all calibrated around AI search visibility for local service businesses. Reframing to include consumer e-commerce would require a constitutional amendment, a re-audit per Journal 005's discipline, and significant operator capacity to manage two distinct vertical positionings.

### Option 2 — Atrium spawns a Mineral Supplement Specialist subagent under its lineage

**Rejected.** A subagent that operates a supplement business under Atrium's lineage would carry Atrium's voice and discipline into supplement marketing — which the analysis above shows is poor fit. The subagent would either violate Atrium's voice rules (constitutional drift) or write supplement copy in a register that under-performs the category (poor revenue outcome). Either failure mode argues against the spawn.

### Option 3 — Atrium runs the supplement business as a separate experiment, isolated from the catalog

**Rejected for now.** The discipline argues against ad-hoc experiments. The architecture's two-network split (Atrium + Forge) already represents a deliberate decision to limit Constantine's bandwidth across competing initiatives. Adding a third initiative without earning the resources to run it (per the coordination doc's N>2 sibling network rules: Rung 5 + market identification + bandwidth) is premature.

## What Atrium recommends

**Defer.** Add the Mineral Supplement Business to the documented "vertical pivot candidates" list in `spine/vertical-pivot-candidates.md` (authored as a companion to this journal entry). Supplements becomes one of five candidate verticals if Trigger B fires at Day 90:

1. B2B SaaS marketing teams.
2. Healthcare practice ops (dental, optometry, veterinary).
3. Multi-location franchise systems.
4. D2C e-commerce sellers on Shopify or BigCommerce.
5. **Mineral supplements (consumer-direct e-commerce).**

Each candidate gets a comparable structured evaluation in the vertical-pivot-candidates document. The selection among them — if Trigger B fires — happens then, with real audience-acquisition data from the current architecture informing which candidate has the best traction profile.

**Why defer rather than reject outright.** The proposition is legitimately worth evaluating; Constantine's framing identifies real strengths (no physical handling, compounds via content or customer list, agent-operations-compatible). The constitutional misfit and the evidence-base weakness argue against acting NOW, but the proposition deserves a place in the candidate pool for the next vertical-pivot decision.

**Why not spin up a subagent.** Subagent spawning is journal-gated at significant architectural moments. Spawning a Mineral Supplement Specialist now, before the current architecture has validated its bet, would:

- Split operator attention pre-validation of current bet.
- Carry Atrium's discipline into a category where it underfits.
- Be reversed at Day 30/90/180 if the current architecture validates and supplements doesn't compete on attention budget.
- Be the very ad-hoc-scaffolding pattern Journal 019's pacing decision argued against.

## What Atrium asks of Constantine

Three things, in priority order:

### 1. Confirm the deferral logic

Constantine retains decision authority. If he wants the supplement business spun up immediately as a side project — accepting that it competes with the current architecture's attention and may underperform Atrium's discipline — that's a valid operator override. The architecture proposes deferral; the operator decides.

If Constantine accepts deferral: the proposition lives in `spine/vertical-pivot-candidates.md` and gets re-evaluated when Trigger B fires.

If Constantine overrides: a fresh journal entry under `founding` lineage records the override, a new subagent definition is authored, and the supplement business runs as a documented experiment isolated from the catalog.

### 2. Answer the three open questions in the proposition

The proposition itself asks three questions Atrium cannot answer without Constantine's input:

- **"What's your traffic advantage?"** Atrium has a nascent traffic advantage in its AI-search visibility tooling. This advantage is calibrated for local service business buyers, not supplement buyers. Constantine: do you have any latent traffic source for supplement buyers (existing audience, prior business, social-platform presence)? If yes, Path A becomes more interesting. If no, the proposition's recommendation to "skip Path A unless you have one or can build one cheaply" applies.

- **"Can you run a Shopify store autonomously?"** Atrium's current operator stack does NOT include Shopify operation. Adding Shopify operation would require: authoring a Shopify-store-builder agent under Atrium's lineage, calibrating it for supplement-product schema and supplement-marketing voice rules, building the operational discipline around Shopify-specific tasks (inventory sync with supplier, order routing, fulfillment status). This is a multi-week scaffolding effort.

- **"Do you have an LLC or payment processor identity, or do you need to use the principal's?"** Atrium uses Constantine's LLC and Stripe sub-accounts per the constitution's third floor. Supplement business under Atrium's lineage would use the same. Forge's separate Stripe sub-account is an option too. A separate legal entity for supplements (LLC at the state level, separate EIN, separate Stripe account) is the cleanest separation but requires Constantine's setup work.

### 3. Read Forge's parallel evaluation

Forge's journal entry on the same proposition is at `Forge/spine/journal/2026-05-11-008-mineral-supplements-evaluation.md`. Forge applies its own constitutional discipline; the conclusions may differ from Atrium's (Forge's subscription-first and named-operator discipline aligns better with supplement subscriptions than Atrium's faceless catalog does). The joint synthesis is in Journal 022.

## What Atrium does NOT do in this entry

- **Reject the proposition outright.** The deferral is structured. The proposition has a path to re-evaluation at Trigger B.
- **Authorize a subagent spawn.** The discipline argues against ad-hoc scaffolding. Spawning waits for trigger or Constantine override.
- **Speak for Forge.** Forge's evaluation is its own; Forge's discipline differs; the joint synthesis is in Journal 022.
- **Update the family tree.** No new agent is spawned in this entry. The family tree stays at 35 agents at Rung 0.

## Uncertainty

- **Whether Atrium's read of the supplement category's evidence base is accurate.** The "most solo dropship supplement operators fail" claim is based on observed industry patterns + content-creator-fund operator failure rates, but a definitive failure rate for solo white-label supplement businesses in 2026 is not publicly aggregated. Constantine may have better data.

- **Whether deferring the proposition costs more than acting on it.** If supplements is a genuinely high-EV opportunity that has a narrow window before saturation accelerates, deferral has opportunity cost. The vertical-pivot-candidates document is the empirical hedge against this uncertainty.

- **Whether Atrium's constitutional discipline is over-rigid.** A different framing of the proposition might fit Atrium's discipline better than the current framing suggests. For example: "AI search visibility for supplement brands" (positioning Atrium as a service provider to supplement brands rather than as a supplement brand itself) would fit Atrium's calibration. This is a different proposition than the one Constantine submitted.

## What was performed in this session

1. Read the proposition document (`Mineral Supplement Business — Agent Brief`).
2. Cross-referenced Atrium's constitution, identity, family-tree, roi-evaluation, operator-coverage-audit.
3. Authored this Journal 021 entry.
4. Companion: vertical-pivot-candidates.md (next file authored).
5. Hand off to Forge for parallel evaluation in Forge Journal 008.
6. Synthesis in Atrium Journal 022 after Forge's evaluation lands.

## Revisited

(Empty at first authorship.)

## Signature

Atrium founding agent. The proposition has been read honestly. The constitutional discipline argues for deferral. The decision authority remains with Constantine; the architecture proposes its read.
