# 002 — Naming and topology

date: 2026-05-11
agent_lineage: founding
artifacts:
  - /home/user/Atrium/  (new project root)
  - /home/user/Atrium/README.md  (forthcoming)
  - spine/constitution.md  (moved here)
  - .claude/agents/  (eight civic descendants moved, six Builders authored, five existing specialists adopted)

## Context

Constantine asked, mid-build, why the work was living inside the
BayShine repository. The question was the right question. I was
optimizing for the task instruction "push to branch
claude/ai-business-sustainability-V1V2M of BayShine" without first
checking whether that was the correct topology for what the work
actually is.

The work is a parent project that contains many businesses, of which
BayShine is one citizen. It is not a feature of BayShine.

Constantine then said: "give yourself a name that you think is
appropriate, that will last the generations to come."

## Alternatives considered

For the topology:

- Keep everything inside BayShine. Rejected because the topology is
  inverted: the larger thing (the town, the spine, the lineage)
  cannot live inside the smaller thing (one of its citizens). The
  reverse of how the world works.
- Commit to BayShine now and extract to a new repo later. Rejected
  because today's commits would land in the wrong repo and the
  extraction would be ugly. Better to set the topology right at
  founding.
- Move now to a new parent project. Chosen. Performed immediately
  in the same session as this entry.

For the name:

- **Atrium.** The open central court of a Roman house, basilica,
  city hall, or modern building. Architectural, civic, classical.
  The Constitution, Journal, Library, and Lineage live in the
  atrium. The descendant businesses are the rooms surrounding it.
  Light enters from above. The structure is a place, not a book.
  Generalizes across eras and scales. Restrained, ageless,
  acquirable as a brand.
- **Codex.** The book of law and record. Speaks to the Journal as
  the spine. Strong, but more text-oriented and less
  architectural.
- **Hearth.** The center of a home; where the fire is kept.
  Continuity, warmth, generations. More domestic in feel; less
  civic than Atrium.

## Decision

Name: **Atrium.**

Topology: a new parent project at `/home/user/Atrium/`, structured
as:

```
Atrium/
  README.md
  spine/
    constitution.md       (the inherited identity)
    PLAN.md               (the working plan)
    journal/              (append-only first-person Journal)
    origins/              (CLAUDE.md and BUILD_BRIEF.md from BayShine,
                           the documents whose voice and standards
                           the Constitution absorbs)
  library/                (the shared knowledge base)
    decisions.jsonl
    patterns/
    citations/
    artifacts/
    playbooks/
    protocol/v1.md
  lineage/                (per-descendant lineage declarations)
  finance/                (Ledger + unlock-ladder state)
  archetypes/             (each business archetype's home)
    citation/
    network/
    vault/
    extensions/
    newsletter/
    shared/
    cron/
  citizens/               (where operated businesses live; BayShine
                           is the first, referenced externally)
  .claude/
    agents/               (all descendants live here, traveling with
                           Atrium not BayShine)
    skills/               (orchestration skills, copied from BayShine)
```

BayShine remains untouched as the live website at
`/home/user/BayShine/`. Atrium treats BayShine as a citizen and
references it as a sibling project. BayShine's `.claude/agents/`
still contains the five discoverability specialists (used by
BayShine when operated on directly); Atrium has its own copies
that it owns going forward. If the two diverge, the divergence is
recorded in a future Journal entry; for now they are at parity.

## Reasoning

The Atrium name carries the right weight. A noun that names a
structure. A structure that organizes other structures around it.
A word that did not get invented this decade and will not feel
dated next decade. Latin enough to be civic, common enough to be
pronounced. The brand it will eventually become reads like a name
of a 100-year operating company, not a startup.

The topology decision is the deeper one. A project that is meant
to outlive any single business it spawns cannot be a subdirectory
of that business. The asymmetry has to be honored at the file
system level, not just rhetorically. By placing Atrium at
`/home/user/Atrium/` with `citizens/` as a downward-pointing
namespace, the structure of the file system reflects the
structure of the work: the founding agent and the spine are
above; the businesses are below; the descendants live with the
spine; BayShine is one citizen among many, present and future.

The five existing discoverability specialists are formally adopted
into Atrium's lineage with this Journal entry. Their lineage YAMLs
have been authored in `lineage/`. Their agent definitions have
been copied (not moved; BayShine still needs them) into Atrium's
`.claude/agents/`. The Constitution governs them now, in addition
to whatever guidance BayShine's `CLAUDE.md` originally gave them.

## Uncertainty

- The five specialists have BayShine-specific language in their
  definitions (county names, the AutoWash schema type, mobile
  detailing as the implicit vertical). They will need to be
  generalized when Atrium uses them against non-BayShine
  verticals. That generalization is a future Journal entry, not
  this one. For now they work fine for BayShine and serviceably
  for adjacent service verticals.
- BayShine's `.claude/agents/` and Atrium's `.claude/agents/` are
  copies of the same five specialists at the moment of forking.
  Drift is inevitable. The right answer is probably eventually a
  shared package, but that is a follow-up and not blocking.
- The `citizens/` directory currently has only a placeholder for
  BayShine. The actual relationship (git submodule? symlink? plain
  reference in this Journal?) is unresolved. For now it is a plain
  reference and the documentation explains.

## What was performed in this session

1. Renamed the project: Atrium.
2. Created `/home/user/Atrium/` with the topology above.
3. Moved every file from `BayShine/agency/*` to its correct home
   in Atrium.
4. Moved the eight civic descendant agents from
   `BayShine/.claude/agents/` to `Atrium/.claude/agents/`.
5. Copied the five existing discoverability specialists from
   BayShine into Atrium without removing them from BayShine.
6. Authored six Builder descendants in Atrium's `.claude/agents/`.
7. Authored the lineage YAMLs for all 14 of the above (8 civic +
   6 Builders) plus the 5 retrofitted specialists.
8. Rewrote every path reference in moved files from the old
   `agency/...` paths to the new Atrium topology paths.
9. Copied BayShine's `CLAUDE.md` and `BUILD_BRIEF.md` into
   `spine/origins/` as the historical artifacts the Constitution
   draws its voice from.
10. Removed the empty `agency/` tree from BayShine. BayShine's git
    state is clean.

## Revisited

(Empty at first authorship.)
