# 008 — Stenographer descendant + second shipping pass

date: 2026-05-11
agent_lineage: founding
artifacts:
  - .claude/agents/stenographer-specialist.md
  - lineage/stenographer-specialist.yml
  - spine/working-memory/README.md
  - spine/working-memory/SESSION-2026-05-11-1400.md
  - (in BayShine .atrium-deliverables/, pushed in commit a2a2c5a):
    - 05-ai-citation-audit/* (5 files)
    - 06-llms-txt-pack-v1/* (12 files including 6 vertical templates)

## Context

Constantine asked for two things in one instruction:

1. Build a buddy. An agent who sits by my side and analyzes what I do and say, so I have another working memory on top of the journal.
2. Keep going for more money-making right now.

The buddy request is a real architectural gap. The Journal captures decisions but not the texture of work: the considered-but-rejected alternatives, the working assumptions held in passing, the open threads at any given moment. Long sessions lose that texture before they end; cold sessions lose it before they start.

The money-making instruction continues the operator's standing pressure since Journal 005: ship revenue surfaces, not more scaffolding.

## Decision

### 1. The Stenographer

A new civic descendant: `stenographer-specialist`.

The Stenographer maintains `spine/working-memory/SESSION-YYYY-MM-DD-HHMM.md`
for the current session. The file has seven fixed sections:

1. Header (session metadata, parent journals, parent working-memory file).
2. Threads currently open (work in flight, status-tagged).
3. Threads closed this session (resolved, resolution-tagged).
4. Assumptions currently held (mental model, sourced, confidence-rated).
5. Considered and rejected (alternatives with revisit-triggers).
6. Timeline (granular log, append-only).
7. Context flushed (forward note to the next session).

The Stenographer is invoked in three patterns:

- **Bootstrap.** Session start. Reads prior working-memory file plus latest journal, creates new session file seeded from carry-forward.
- **Checkpoint.** Mid-session, between major tasks. Updates the file in place from recent transcript.
- **Close.** End of session. Moves still-open threads to a `Carry forward to next session` block.

The first working-memory file is a retrospective catch-up covering this entire session (entries 001-008 plus the first shipping pass) since the Stenographer was authored mid-session. From this commit forward, every session bootstraps a new working-memory file at start.

### 2. Second shipping pass — AI Citation Audit ($499)

The lighter sibling of GEO Setup. Positioned as the "diagnose, then decide" middle tier between the $99 GEO Playbook and the $2,500 GEO Setup.

Five files in `BayShine/.atrium-deliverables/05-ai-citation-audit/`:

- `sales-page.html` — deployable single-file HTML with the same Bay Shine brand styling as GEO Setup, including an audit-vs-setup comparison block linking through to GEO Setup.
- `LISTING.md` — Stripe Checkout config, pricing rationale (positioned between $99 info product and $2,500 service), three buyer-type segmentation, sales targets, upgrade-pipeline mechanic.
- `INTAKE-FORM.md` — 5 fields, including the buyer's 5-10 target queries which become the heart of the audit.
- `DELIVERY-PIPELINE.md` — 5-business-day plan: Day 1 probe, Day 2 matrix and heat map, Day 3 competitor cross-reference, Day 4 remediation list and report draft, Day 5 Auditor sign-off and delivery.
- `WELCOME-EMAIL.md` — intake email and delivery email with the $250 GEO Setup upgrade credit hook.

Unit economics: $499 × 20 sales/mo = $9,980, roughly equal to GEO Setup at 4 sales/mo but with a wider funnel.

### 3. Second shipping pass — llms.txt Pack v1 ($9) + bundle ($35)

Twelve files in `BayShine/.atrium-deliverables/06-llms-txt-pack-v1/`:

- `README.md`, `INSTALL.md` (5-platform install guide), `LISTING.md` ($9 Gumroad listing), `WELCOME-EMAIL.md`.
- `BUNDLE-LISTING.md` — the Schema Pack v1 + llms.txt Pack bundle SKU at $35 (saves $3 versus $38 unbundled).
- 6 vertical templates: `mobile-detailing-llms.txt`, `pressure-washing-llms.txt`, `mobile-car-wash-llms.txt`, `hvac-llms.txt`, `plumbing-llms.txt`, `roofing-llms.txt`.

Each template declares business identity, services offered, service area with ZIP codes, hours, priority pages for citation, and explicit citation preferences (canonical business name, geographic citation patterns, pricing-reference rules).

The bundle is the classic info-product upsell. Conversion rate on bundles in this range historically lifts 2-3x.

## Reasoning

### Why the Stenographer is civic and not built into the founding agent

The Stenographer is a separate descendant for the same reason the Scribe is: the discipline is the agent. Bundling the working-memory discipline into the founding agent's prompt directly would (a) inflate that prompt, (b) make the format hard to evolve, (c) lose the parallelism with how the Journal works. Civic descendants are how the founder externalizes long-term disciplines. Working memory is one of them.

### Why two products in the second shipping pass

The first shipping pass put four surfaces in play (demand probe, $29 Schema Pack, $2,500 GEO Setup, free Cited Weekly). The unit economics of those four cover the lower-tier price points ($0, $29) and the highest tier ($2,500). The middle tier ($199-$999) was empty.

The AI Citation Audit at $499 fills that middle tier with the strongest unit economics in the catalog so far. It pulls down buyers who can't commit to $2,500 but want more than a $29 template. It cross-sells to GEO Setup with the $250 credit.

The llms.txt Pack at $9 plus the $35 bundle expands the entry-level tier. A $9 product is an impulse purchase. A $35 bundle is a high-leverage cross-sell from any Schema Pack v1 listing view. Both broaden the funnel without competing with the audit or the setup service.

### Why this is the right second pass before adding more verticals to Schema Pack

Going to Schema Pack v2 with 24 verticals at $49 would require ~3x the writing time. The same time spent on the AI Citation Audit and the llms.txt Pack creates two new revenue surfaces with different unit economics. Diversifying surfaces before deepening any one of them is the right call when demand-probe signal is still pending.

After the demand probe lands, if the signal is strong, Schema Pack v2 becomes the right next move. Today's bet: spread the surface area first.

## Alternatives considered

- **Write Schema Pack v2 with 24 verticals at $49 instead of these two products.** Rejected because (a) the demand probe is still pending, (b) doubling down on one product before validating demand is the elegance-before-evidence trap, (c) the two products shipped today cover two new buyer segments that Schema Pack v2 would not.

- **Start the 80-page GEO Playbook in this session.** Rejected because demand probe is still pending. Same reasoning as Journal 005 and 007. Revisit-trigger: Day 6 demand-probe signal is moderate or strong.

- **Author Operators for the deferred archetypes (Vault, Audit-Family, Directory, Extensions) in this session.** Rejected because they are not first-30-day flagships and the operator's standing instruction is revenue over scaffolding. Revisit-trigger: any deferred archetype reaches the priority threshold.

- **Inline the Stenographer's discipline into the founding agent's CLAUDE.md.** Rejected because it inflates the founding prompt and makes the format hard to evolve. The civic-descendant pattern is the right architecture.

## Uncertainty

- **Stenographer maintenance cost.** The Stenographer is described as invokable in three patterns. The actual token cost of the Checkpoint pattern (mid-session subagent invocation that reads recent transcript and updates the file) is untested. If it turns out to be expensive, the self-maintained pattern (founder writes to the file directly) is the fallback. The first session file documents this fallback path implicitly.

- **AI Citation Audit unit cost.** Like GEO Setup, the 5-business-day delivery assumes the specialist pipeline runs cleanly. First 2-3 audits reveal whether the buffer is enough. If audits consistently run over 7 days, price up or buffer up.

- **llms.txt Pack price elasticity at $9.** Very low impulse-buy price. The bundle at $35 is the more important price test. If <10% of Schema Pack v1 buyers add the llms.txt Pack at checkout, the bundle CTR is wrong and the price point is wrong; reframe in the operator-info-products lineage.

- **Sales page deployment.** All three sales pages (GEO Setup, AI Citation Audit, plus the eventual llms.txt Pack listing) deploy to the same Vercel project once a domain is registered. The path discipline (`/geo-setup`, `/audit`, `/llms-txt-pack`) is documented in the listing files. Until then, the sales pages are static HTML on disk.

## What was performed in this session (from working memory file SESSION-2026-05-11-1400.md, this entry covers only the post-Journal-007 work)

1. Authored stenographer-specialist agent definition.
2. Authored stenographer-specialist lineage YAML.
3. Created spine/working-memory/ directory with README.
4. Wrote the first working-memory file as a retrospective catch-up for this entire session.
5. Shipped AI Citation Audit ($499 / 5-day): sales-page.html + LISTING + INTAKE-FORM + DELIVERY-PIPELINE + WELCOME-EMAIL. 5 files.
6. Shipped llms.txt Template Pack v1 ($9): README + INSTALL + LISTING + WELCOME-EMAIL + BUNDLE-LISTING + 6 vertical templates. 12 files.
7. Committed and pushed to BayShine (commit a2a2c5a).
8. This Journal entry.
9. Atrium decisions.jsonl appended (next step).
10. Atrium local commit (next step).

## Revisited

(Empty at first authorship.)

## Next operational actions (Constantine, this week)

Cumulative product catalog in BayShine `.atrium-deliverables/`:

| # | Product | Price | Action |
|---|---|---|---|
| 01 | Demand probe (IndieHackers + r/LocalSEO) | $0 | Post today |
| 02 | Schema Pack v1 (6 verticals) | $29 | Upload to Gumroad after Day-6 signal |
| 03 | GEO Setup productized service | $2,500 | Deploy sales-page.html to Vercel |
| 04 | Cited Weekly Issue 001 | Free tier | Create Beehiiv pub, queue Tuesday |
| 05 | AI Citation Audit | $499 | Deploy second sales page; Stripe Checkout |
| 06 | llms.txt Pack v1 | $9 | Upload to Gumroad after Schema Pack listing is live |
| Bundle | Schema Pack + llms.txt Pack | $35 | Bundle SKU on Gumroad after both individual products live |

Three Stripe products (one $2,500 service, one $499 audit, one bundle) and two Gumroad products (Schema Pack at $29, llms.txt Pack at $9) plus the Bundle. Plus the demand probe and the newsletter.

## Next operational actions (founding agent, next session)

- Bootstrap a new working-memory file at session start using the Stenographer's bootstrap pattern.
- Read the prior working-memory file's "Carry forward to next session" block (will be populated when this session closes).
- If the demand probe lands by next session: evaluate signal level, decide on GEO Playbook, decide on Schema Pack v2.
- Author the missing playbooks for the deferred archetypes (vault, audit-tool-network, directory, extension, web-tools, devtools).
- Author Operators for the next-priority deferred archetype.
- Set up the actual Atrium GitHub repo and migrate `.atrium-deliverables/` from BayShine.
