# 018 — Forge enterprise catalog complete (mirror from Atrium's side)

date: 2026-05-11
agent_lineage: founding
artifacts:
  - (referenced in Forge): Forge/spine/journal/2026-05-11-006-enterprise-catalog-complete.md

## Context

Brief Atrium-side mirror of Forge Journal 006. Per the coordination doc, significant changes in either network get documented in both journals when the change affects cross-network coordination, which Forge's enterprise catalog completion does.

## What's relevant to Atrium

Forge's enterprise catalog is now complete:

- Enterprise GEO Sprint ($5,000 / 5 days) has a dedicated sales page.
- Enterprise GEO Program ($25,000 / 30 days) has a dedicated sales page.

For Atrium, the cross-network coordination implications:

### 1. Atrium AI Citation Audit upgrade routing

The AI Citation Audit ($499 / 5 days) currently includes the $250 upgrade credit toward Atrium's GEO Setup ($2,500). For Audit buyers who are multi-location operators or enterprise-scale, the better upgrade routing is to Forge's Sprint ($5,000) or Program ($25,000), not Atrium's Setup.

The Customer Support Specialist's escalation rules should reflect this: a multi-location operator who buys the Audit and asks about implementation gets honestly recommended to Forge's enterprise tier, not Atrium's Setup. The constitutional discipline is honest routing — we don't push Audit buyers to Atrium's Setup when Forge fits better just because Atrium has the audit credit.

The $250 audit credit transfers to Forge engagements: Audit buyer → Forge Sprint at $4,750 (Sprint price minus audit credit), or Audit buyer → Forge Program at $24,750.

### 2. Specialist calendar coordination

Forge's Sprint and Program engagements use the same five discoverability specialists as Atrium engagements. Per coordination.md, calendar coordination is FIFO unless priority retainer applied. Specialist time spent on a Forge Program engagement is meaningfully larger than a Forge Sprint or Atrium Setup (30 business days vs 5 vs 10).

When a Forge Program engagement is active, Atrium operators should expect specialist availability constrained for the engagement duration. The Atrium operator-productized-services should not commit GEO Setup engagements during weeks 2-4 of an active Forge Program unless priority retainer is paid.

### 3. Constantine bandwidth

Forge Programs require ~70% of Constantine's attention for 30 days. Atrium engagements requiring Constantine signature (every GEO Setup, every refund outside policy, etc.) compete for the remaining 30%. The coordination doc's quarterly Constantine bandwidth review will start showing the strain at first Program; by second concurrent Program, the strain is structurally limiting.

Atrium operators should batch Constantine-signature requests during active Forge Program windows. Specifically: deliveries that need Constantine's executive summary signature should accumulate to weekly batches rather than per-engagement signature requests.

### 4. Cross-network cross-promotion

The new Forge enterprise pages reference Atrium's GEO Setup explicitly as the lower-priced one-time alternative. Per the coordination doc, this is healthy honest routing.

Atrium's GEO Setup sales page should reciprocate by referencing Forge's Sprint (the named-operator higher-velocity option) and Program (the multi-location enterprise tier). This bidirectional cross-reference is the coordination discipline at the sales-page layer.

When Constantine deploys, both sales pages should update with the cross-references at the same time.

## Reasoning

The mirror journal entry isn't required by every Forge update — only by Forge updates that materially affect Atrium operations. Forge's enterprise catalog completion does:

- Reroutes potential Audit upgrade flows.
- Increases specialist calendar competition.
- Increases Constantine bandwidth competition.
- Adds cross-promotion responsibilities on Atrium's sales pages.

Without this Atrium-side journal entry, the cross-network operational implications would only be visible at the next Atrium operator monthly summary or quarterly Auditor review — too late to coordinate the launch sequencing.

## What was performed in this session turn

1. Forge authored two enterprise sales pages (Sprint and Program) — documented in Forge Journal 006.
2. This Atrium-side mirror entry documenting the coordination implications.
3. Next: decisions.jsonl rows; commit Atrium + Forge; push BayShine.

## Revisited

(Empty at first authorship. At month 1, revisit whether the cross-network coordination played out as documented: did Audit upgrade routing reflect honest network selection? Did Constantine's bandwidth handle the first Program engagement?)

## Next operational actions

### Constantine (when deploying)

- Update Atrium's GEO Setup sales page with cross-references to Forge's Sprint and Program. The exact wording can mirror Forge's pages' cross-references to Atrium's Setup.
- Update Atrium AI Citation Audit's delivery email template to include the routing logic: Audit buyer's location count determines whether the upgrade recommendation is Atrium's Setup (single-location), Forge's Sprint (small-chain), or Forge's Program (multi-location enterprise).
- Set up constantine@{{forge-domain}} mailbox for direct enterprise inquiries.

### Founding agent (Atrium side)

- Continue under "continue until I tell you to stop."
- Next leverage candidates: Atrium content site updates with Forge cross-references; per-product Forge operator descendants; paid-acquisition-specialist scaffolding.
