# 017 — Content sites for both networks

date: 2026-05-11
agent_lineage: founding
artifacts:
  - BayShine .atrium-deliverables/ATRIUM-CONTENT-SITE/ (index.html + LISTING.md)
  - BayShine .atrium-deliverables/FORGE-CONTENT-SITE/ (index.html + LISTING.md)

## Context

Continuing under "continue until I tell you to stop." Both networks have scattered customer-facing surfaces — Atrium has 4 Gumroad pages + 2 Vercel sales pages + 1 Beehiiv newsletter; Forge has 1 free tool + 2 waitlist pages + 1 Substack newsletter. No central brand hub on either side.

The gap: a buyer who hears about Atrium or Forge via word-of-mouth, podcast, affiliate referral, or organic search has nowhere obvious to land. They'd land at whichever specific product URL was mentioned, miss the rest of the catalog, and likely not discover the sibling network at all.

Shipping single-file content sites for both networks closes that gap. Each site shows the full catalog, captures newsletter signups, and cross-references the sibling network with intentional symmetry.

## Decision

Two HTML files, both deployable to Vercel today.

### atrium.{{tld}}/index.html

Faceless Atrium brand: light paper background, gold accent (--bay-gold #C9A961), no em-dashes in visible copy, Constantine named only in footer per constitutional discipline.

Sections:

- Hero: positioning sentence + lede.
- Catalog (6 product cards in grid): Schema Pack v1.5, llms.txt Pack v1, Bundle, GEO Playbook v0.5, AI Citation Audit, GEO Setup. Each card has tier label, price, description, CTA to destination.
- "Where to start" compare block: 4-line decision tree for templates / methodology / data-before-commitment / done-for-you.
- Cited Weekly newsletter signup form.
- Agency section: cross-references Forge for continuous monitoring + multi-domain SaaS.
- Footer with Constantine attribution + Forge cross-link + refund policy.

### forge.{{tld}}/index.html

Bold Forge brand: dark background (--forge-ink #0A0A0B), orange accent (--forge-orange #FF5630), em-dashes welcome in lede, Constantine named in body copy and pitch block.

Sections:

- Hero with brand label + lede emphasizing subscription-first positioning.
- Catalog (6 product cards): Schema Generator (free), Citation Watch (waitlist), Schema Doctor Pro (waitlist), Enterprise GEO Sprint ($5k), Enterprise GEO Program ($25k), Forge Weekly newsletter.
- "Why subscription-first" pitch block making the case for compounding economics with real math from the product specs.
- Full cross-network stack table showing all 10 products across both networks with Forge's rows highlighted.
- Forge Weekly newsletter signup form.
- Footer with Constantine direct-line email, Atrium cross-link, refund policy.

### What makes the two sites visibly distinct

The constitutional design choice (Atrium faceless / terse / restrained vs Forge named / bold / aggressive) becomes physical on these sites:

- Atrium light/gold; Forge dark/orange.
- Atrium "we" in body copy; Forge "I" and Constantine named.
- Atrium em-dash-free; Forge em-dashes used with intent.
- Atrium decision-tree in compare block; Forge pitch block argues for subscription compounding.
- Atrium catalog emphasizes one-time products; Forge catalog emphasizes recurring + enterprise.

A buyer comparing the two sites sees two distinct brands with two distinct value propositions, not one brand with two color skins.

## Reasoning

### Why both sites in the same session

Symmetry. Shipping only Atrium's content site would create a structural asymmetry: Atrium has a brand hub, Forge doesn't. Brand surface asymmetry erodes the dual-voice discipline. Both ship together or neither ships now.

The marginal effort to ship both is ~25% more than shipping one (the second site reuses the architectural pattern with different content); the marginal value is much higher because the cross-references close the loop in both directions.

### Why the stack table specifically

The stack table on Forge's site is the most operationally important element across both content sites. It shows the buyer's path through the combined catalog explicitly:

- Buyer wants free first: Schema Generator (Forge).
- Buyer wants templates: Schema Pack or llms.txt (Atrium).
- Buyer wants methodology: GEO Playbook (Atrium).
- Buyer wants diagnostic: AI Citation Audit (Atrium).
- Buyer wants one-time implementation: GEO Setup (Atrium).
- Buyer wants continuous monitoring: Citation Watch (Forge).
- Buyer wants schema-as-code: Schema Doctor Pro (Forge).
- Buyer is mid-market: Enterprise GEO Sprint (Forge).
- Buyer is multi-location enterprise: Enterprise GEO Program (Forge).

A single buyer-facing artifact that explains which network solves which problem. Without the stack table, the buyer has to figure out the architecture from product names alone, which is unreasonable.

Atrium's site has the stack table abbreviated (only highlights the Atrium rows since the audience is Atrium-leaning). Forge's site has the full table because Forge's audience benefits more from seeing the full catalog (mid-market and enterprise buyers self-select harder; they need more information).

### Why the cross-references go in both directions

Per the coordination doc, the two networks acknowledge each other. The cross-references are intentional editorial links, not template-farm patterns. SEO value is real (each site is a backlink to the other); business value is real (buyers self-select between networks more accurately with explicit cross-references); brand integrity is preserved (neither network pretends the other doesn't exist).

## Alternatives considered

- **Ship only Atrium's content site.** Rejected. Asymmetry between networks erodes the dual-voice discipline.
- **Ship both sites but with shared visual identity.** Rejected. The constitutional design choice requires visible difference. Shared visual identity would collapse the inversion.
- **Defer content sites until first revenue lands.** Rejected. Content sites accelerate revenue (they're a brand hub for inbound traffic). Without them, every product needs its own discoverability lift; with them, the brand is the discoverability surface.
- **Ship more elaborate sites (multi-page, blog, case studies).** Rejected for this session. V1 is single-file HTML; multi-page expansions are deferred to when there's content to populate them (case studies require first customer engagements; blog requires sustained editorial).

## Uncertainty

- **Whether the dual-network stack table confuses or clarifies for buyers.** It's an unusual architecture (most operators have one brand). Some buyers may interpret it as "they couldn't decide on a strategy" rather than "they intentionally cover two distinct buyer profiles." Real conversion data after the sites are live tells which interpretation dominates.

- **Whether visual differentiation between Atrium and Forge is strong enough.** Both sites use Bay Shine-derived brand discipline at the structural level (Inter typography family, grid layout, single-file HTML). The visual difference is color + voice. May need stronger differentiation if buyers report confusion.

- **Whether SEO benefits accrue.** Each site is a brand-new domain (atrium.{{tld}} and forge.{{tld}}) with no organic search history. The first 3-6 months are domain-aging plus content-density-building before SEO traffic materializes. Direct/referral traffic (from cross-network links, affiliate placements, Cited Weekly + Forge Weekly mentions) carries the early traffic.

## What was performed in this session turn

1. Authored `BayShine .atrium-deliverables/ATRIUM-CONTENT-SITE/index.html` (~190 lines deployable HTML).
2. Authored `BayShine .atrium-deliverables/ATRIUM-CONTENT-SITE/LISTING.md` (~140 lines deployment notes).
3. Authored `BayShine .atrium-deliverables/FORGE-CONTENT-SITE/index.html` (~210 lines deployable HTML).
4. Authored `BayShine .atrium-deliverables/FORGE-CONTENT-SITE/LISTING.md` (~150 lines deployment notes).
5. This Journal entry.
6. Next: decisions.jsonl rows; commit and push BayShine.

## Revisited

(Empty at first authorship.)

## Next operational actions

### Constantine

- Deploy `ATRIUM-CONTENT-SITE/index.html` to atrium.{{tld}}/index.html. Replace placeholders before deploy (Gumroad URLs, sales page URLs, Beehiiv signup URL, ATRIUM_DOMAIN). Add SEO head tags (canonical, Open Graph, Twitter Card, Organization schema, llms.txt).
- Deploy `FORGE-CONTENT-SITE/index.html` to forge.{{tld}}/index.html. Same pattern: replace placeholders (Substack signup URL, FORGE_DOMAIN), add SEO head tags.
- Both sites should be deployed within 24 hours of each other to maintain network symmetry.
- The cross-references between sites (Atrium → Forge in 2 places, Forge → Atrium in 3 places) require the OTHER domain to be live for the links to resolve. Sequence: deploy both, verify both, update DNS, both live within the same 24-hour window.

### Founding agent (next session)

- Remaining leverage candidates: Forge Enterprise GEO Sprint sales page (currently just a card on the Forge content site; needs a dedicated sales page same as Citation Watch waitlist); Schema Pack v2 (24 verticals); per-product Forge operators; Atrium content site case studies route; Cited Weekly Issue 005.
- Working-memory checkpoint to SESSION-2026-05-11-2330.md reflecting this turn.

### Operator-info-products and operator-forge-products

- After site launch, monitor traffic per analytics tool.
- Per-product click-through rates from the content sites tell which products draw attention.
- Newsletter signup conversion rates on each site inform whether the signup form positioning is working.
- Cross-network click-through (Atrium site → Forge site, and reverse) tells whether the cross-references convert as intended.
