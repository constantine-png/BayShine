# 004 — Adding Web Tool Network and Developer Tools archetypes

date: 2026-05-11
agent_lineage: founding
artifacts:
  - archetypes/web-tools/README.md
  - archetypes/devtools/README.md
  - lineage/devtools-builder.yml
  - .claude/agents/devtools-builder.md
  - library/decisions.jsonl (rows appended)

## Context

After authoring the five-master-patterns reframe in entry 003,
Constantine asked which businesses I am most comfortable executing
given the expert-domain functions I already have access to.

The expert domain I most directly own is: the five discoverability
specialists (schema, site-architecture, geo-ai-search,
internal-linking, citation-readiness), the citation-probe and
pattern-rollup descendants, and the founding voice and quality
standards inherited from `spine/origins/CLAUDE.md`.

The businesses that most leverage that capability are the ones
that wrap or productize the specialists' work.

## Alternatives considered

- Add Marketplace Listings (Pattern A with design assets on Etsy /
  Creative Market). Fastest ramp but design-asset-heavy, which is
  not my strongest domain.
- Add Web Tool Network (Pattern B single-purpose web utilities).
  Each tool is essentially a UI on top of one specialist's work.
  Direct leverage. Chosen.
- Add Developer Tools (Pattern A on developer marketplaces +
  Pattern B internals). Productizes the specialists as npm
  packages, GitHub Actions, VSCode and JetBrains extensions,
  WordPress plugins. Strongest direct expression of expert
  domain. Chosen.

## Decision

Two new archetypes added:

**Archetype 9 — Web Tool Network.** Single-purpose web utilities
each on its own domain, each ranking for its primary query. First
three target end of Week 2: Schema Generator, llms.txt Builder,
OpenGraph Preview. Operated initially by
`operator-web-tool-family`. Builder: existing
`static-site-builder` plus a possible future `web-tool-builder`
specialization.

**Archetype 11 — Developer Tools.** npm packages, GitHub Actions,
VSCode/JetBrains extensions, WordPress plugin. First three target
end of Week 4: `schema-validate-action`, `@atrium/schema`,
VSCode Atrium Discoverability Linter. Operated by
`operator-devtools`. New Builder authored in this same commit:
`devtools-builder`.

## Reasoning

Three reasons drove these picks.

First, leverage. The expert domain functions I have access to are
the five specialists. Both Archetype 9 and Archetype 11 are
direct wrappers around those specialists. Building them produces
revenue and exercises capabilities I already own.

Second, Pattern fit. Archetype 9 fits Pattern B (Search-Visible
Single-Purpose Tools); Archetype 11 fits Pattern A intersected
with Pattern B (marketplace-distributed developer tools that are
internally Pattern B in scope). The two together cover the two
patterns with the strongest leverage on my existing capability.

Third, distribution. Both archetypes have native organic
discovery — search for Archetype 9, marketplace algorithms for
Archetype 11 — so the closer-less constraint (no human sales) is
honored by construction.

I considered adding Marketplace Listings (Pattern A on Etsy /
Creative Market) as well. Skipped for now because the design-asset
production is not my strongest domain and would require a new
Builder I do not yet have a strong playbook for. Will revisit
after the first ten Web Tool Network instances have shipped and
I have observed which design patterns recur.

## Uncertainty

- Whether `static-site-builder` is sufficient for Archetype 9 or
  whether a sibling `web-tool-builder` will need to spawn. I think
  the former is fine; the latter spawns only if 10+ tools have
  shipped and a clear specialization pattern emerges.
- Whether GitHub Marketplace will admit paid Actions from a brand
  with no track record. Mitigation: ship a free Action first
  (`schema-validate-action` free tier) to establish a publishing
  history before listing a paid Action.
- Whether VSCode and JetBrains marketplaces will admit the IDE
  extensions on first submission. Track-record concerns similar to
  GitHub Marketplace. Mitigation: clean code, complete listings,
  conservative permissions.

## What was performed in this session (so far)

1. Created `archetypes/web-tools/README.md` with the first-
   generation tool catalog (15+ tools enumerated), monetization
   layers, quality bar, Builder and Operator assignments,
   Growth Clause, and sub-business spawn opportunities.
2. Created `archetypes/devtools/README.md` with the first-
   generation product catalog across npm / GitHub Actions /
   VSCode / JetBrains / WordPress, monetization, quality bar,
   Builder and Operator assignments, Growth Clause.
3. Authored `devtools-builder` Builder descendant at
   `.claude/agents/devtools-builder.md`.
4. Created lineage declaration at `lineage/devtools-builder.yml`.
5. This Journal entry.

## Revisited

(Empty at first authorship.)
