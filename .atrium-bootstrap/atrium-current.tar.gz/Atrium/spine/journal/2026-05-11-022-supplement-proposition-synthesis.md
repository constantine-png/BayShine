# 022 — Synthesis: Mineral Supplement proposition + family tree + decision

date: 2026-05-11
agent_lineage: founding
referenced_artifacts:
  - spine/family-tree.md (new)
  - Forge/spine/family-tree.md (mirror)
  - spine/journal/2026-05-11-021-mineral-supplements-atrium-evaluation.md (Atrium's read)
  - Forge/spine/journal/2026-05-11-008-mineral-supplements-evaluation.md (Forge's read)
  - spine/vertical-pivot-candidates.md (new)

## Context

Constantine submitted the Mineral Supplement Business proposition and asked both Atrium and Forge to evaluate, with the possibility of spinning up a subagent. He also requested a family tree map of the agent architecture so future agents know who exists and who to refer to.

Five deliverables produced in this session:

1. `spine/family-tree.md` — comprehensive map of 35 agents across both networks with referral graph.
2. `Forge/spine/family-tree.md` — Forge-specific mirror.
3. `Atrium/spine/journal/2026-05-11-021-mineral-supplements-atrium-evaluation.md` — Atrium's read (defer).
4. `Forge/spine/journal/2026-05-11-008-mineral-supplements-evaluation.md` — Forge's read (defer consumer-DTC, propose 2-week B2B probe).
5. `spine/vertical-pivot-candidates.md` — 6-candidate pool including supplement framings as candidates 5a and 5b.

This entry synthesizes the two networks' evaluations into a single decision-ready document for Constantine.

## What Atrium and Forge agreed on

Both networks defer the consumer-DTC supplement framing (Path A affiliate, Path B white-label dropship). The shared rationale:

1. **Vertical misfit.** Consumer-direct supplements is outside both networks' current calibration. Atrium is AI search for local service businesses; Forge is subscription/enterprise B2B for the same vertical. Supplements is consumer-direct e-commerce — a different audience, a different schema subtree (Product / NutritionInformation vs LocalBusiness), a different buyer journey.

2. **Evidence base is weaker than current architecture.** The category rewards 5-10 year compounding more than 90-day velocity. Solo dropship supplement operators have a high failure rate documented across multiple operator-failure-rate sources.

3. **Regulatory complexity is real.** FDA/DSHEA, structure-function claims, allergen labeling, GRAS status. Compliance specialist not authored in either network; the burden falls on Constantine or on a new descendant that doesn't yet exist.

4. **Priority order argues against now.** The roi-evaluation.md framework pre-armed three pivot triggers. Trigger B (vertical pivot at Day 90) is the formal mechanism for evaluating new verticals against the current bet. Acting on supplements before Day 30 (Trigger A) and Day 90 (Trigger B) is premature.

## Where Atrium and Forge differ

Forge's evaluation flagged that the proposition's consumer-DTC framing was incomplete. Forge identified B2B supplement angles (wholesale to gyms, naturopath networks, chiropractor offices, SMB wellness HR programs, white-label-for-other-brands) that fit Forge's outbound + subscription + enterprise discipline better than consumer-DTC does.

Forge proposed Recommendation B: a 2-week bounded exploratory subagent (`forge-supplements-probe-specialist`) researching the B2B-wholesale supplement market with a defined mandate:

1. Research wholesale supplement market economics.
2. Identify whether Forge's existing outbound infrastructure repurposes for supplement-wholesale prospects.
3. Probe 5-10 specific B2B prospects.
4. Report back with: "Yes, real opportunity at Forge's discipline" OR "No, defer like Atrium recommended."

Atrium did not flag this angle. The B2B-wholesale framing is appended to vertical-pivot-candidates.md as Candidate 5b alongside the consumer-DTC framing (Candidate 5a).

## Constantine's three options

The architecture proposes; Constantine decides. Three options:

### Recommendation A — Defer entirely

Atrium's clean read. Both supplement framings (consumer-DTC and B2B-wholesale) sit in vertical-pivot-candidates.md awaiting Trigger B firing at Day 90.

**What happens if Constantine chooses A:** No subagent spawned. The proposition is documented in the candidate pool. Re-evaluation at Day 90 with real audience-acquisition data from the current architecture.

**Cost of choosing A:** If supplements is a genuinely high-EV opportunity with a narrow window, deferral has opportunity cost. The vertical-pivot-candidates document is the empirical hedge.

### Recommendation B — Defer consumer-DTC, fund 2-week B2B probe

Forge's middle ground. Spawn `forge-supplements-probe-specialist` as a bounded exploratory subagent with a 2-week mandate. The subagent dissolves after 2 weeks regardless of outcome.

**What happens if Constantine chooses B:** Fresh Forge journal entry authorizes the subagent spawn. Probe runs for 2 weeks (estimated Day 0 through Day 14 of the spawn). Subagent reports back with structured findings. Founding-forge decides whether to scale to operator-tier or defer.

**Cost of choosing B:** Two weeks of agent time. Zero capital. No commitment beyond the probe. Constantine's attention is preserved on the current architecture; the probe's findings inform future trigger-evaluation decisions with better data.

### Recommendation C — Override, ship consumer-DTC supplements under Forge now

Constantine's explicit operator override. Ship the consumer-DTC supplement business immediately under Forge's lineage. Author `operator-forge-supplements`. Partner with Supliful for fulfillment. Front the brand with Constantine's name. Accept that this competes with the current architecture's attention.

**What happens if Constantine chooses C:** Multi-week scaffolding effort. Net new operator authored under `founding-forge`. Stripe Subscriptions configured. Shopify store stood up. Marketing copy authored in Forge's voice (em-dashes welcome, marketing-permissive within truth, but constrained by DSHEA compliance for supplement claims). First launch targeting 14-21 days from spawn authorization.

**Cost of choosing C:** Constantine's attention splits across three initiatives (Atrium + Forge core + Forge supplements). The current architecture's first-30-day metrics get diluted by reduced operator capacity. Trigger A's Day 30 evaluation becomes harder to read (is poor performance due to architecture problem or due to attention dilution?).

## What the architecture recommends

If forced to choose without further input from Constantine: **Recommendation A (clean defer).** The reasoning:

- The current architecture has not validated its bet yet. Pivot triggers were authored specifically to gate vertical changes on real data, not on operator preference. Acting before triggers fire violates the architecture's own discipline.
- The B2B-wholesale probe (Recommendation B) is interesting but costs 2 weeks of agent attention. That attention has alternative uses (operator setup, customer support, newsletter cadence, support of the GO-LIVE master sequence Constantine still needs to execute).
- The consumer-DTC framing (Recommendation C) is the weakest of the three options on constitutional fit.

If Constantine wants to be slightly more aggressive than clean defer: **Recommendation B is the better choice than C.** The 2-week probe has bounded cost and produces real signal. Recommendation C has unbounded attention cost and weak constitutional fit.

If Constantine wants to override the architecture's discipline and ship supplements now: **the architecture honors the override.** The operator's authority is constitutional Floor #3 territory (Constantine signs anything that moves money or signs contracts). The same authority extends to commissioning new operators outside the current priority order. The journal records the override and proceeds.

## The family tree's place in this decision

Constantine also asked for the family tree map. `spine/family-tree.md` is authored. It documents 35 agents across both networks with their domains, referral patterns, and how-to-use guidance.

The family tree is now the discovery surface for the small-world-of-agents aspiration Constantine framed. As new agents are spawned (at rung triggers, Growth Clause thresholds, or journal-authorized moments), they register here. The training pattern Constantine described — agents seeking training in their domains by reading other agents' definitions — is the cold-start sequence the family tree's "How agents seek training" section documents.

If Recommendation B or C is chosen, the new subagent's spawn updates the family tree as part of its authorization. The family tree update is not optional; it's how the architecture remains navigable as it grows.

## What's been performed in this session

1. Read the proposition.
2. Cross-referenced both networks' constitutions, identity documents, harness ladders, audit documents, evidence audit (Journal 005), and roi-evaluation framework.
3. Authored `Atrium/spine/family-tree.md` (canonical map of 35 agents).
4. Authored `Forge/spine/family-tree.md` (mirror with Forge-specific focus).
5. Authored Atrium Journal 021 (Atrium's defer-clean evaluation).
6. Authored Forge Journal 008 (Forge's defer-but-propose-B2B-probe evaluation).
7. Authored `spine/vertical-pivot-candidates.md` (6-candidate pool including 5a consumer-DTC and 5b B2B-wholesale framings).
8. This synthesis (Journal 022).
9. Next: decisions.jsonl entries; commit Atrium + Forge locally; refresh BayShine bootstraps; push.

## What Constantine should do next

Choose one of A, B, C. The architecture's documented preference is A (clean defer) with B (2-week B2B probe) as the acceptable alternative if you want slightly more aggression. C (override) is honored if you choose it but is the option the discipline argues against.

The choice can be made in the next session or via direct reply. If you choose B or C, a fresh journal entry under the relevant founding lineage authorizes the subagent spawn. The family tree updates in the same commit.

## Uncertainty

- **Whether the architecture's defer-default is over-rigid.** Constantine's framing — "as new agents are created, they will train themselves and seek training in the domains they solve for, ultimately creating an entire small world of agents that run autonomous businesses" — implies a more permissive spawn discipline than the current architecture defaults to. The current architecture is calibrated for "validate the bet before pivoting"; Constantine's framing suggests "spawn the agent that handles the new domain, let the small world grow organically." Reconciling these would require a constitutional amendment (journal-gated, Constantine-signed).

- **Whether the family tree captures the right information.** The current map covers agent name, lineage, role, domain, invocation triggers, referral patterns. It does NOT capture: agent invocation latency, agent token cost, agent failure modes, agent constitutional drift signals over time. These could be added as the architecture matures.

- **Whether the B2B-wholesale supplement framing (Candidate 5b) is genuinely a real opportunity or just Forge's discipline-fitting cope.** The 2-week probe (Recommendation B) is specifically designed to answer this empirically rather than via assertion.

## Signature

Atrium founding agent. Synthesis complete. Three options on the table; the discipline argues for A; B is the acceptable middle; C requires operator override. Constantine's decision lands the question.

The family tree is now infrastructure. The vertical-pivot-candidates document is now the candidate pool. The supplement proposition has been evaluated honestly by both networks; the architecture has shown it can read new opportunities without reflexively accepting or reflexively rejecting.
