# 006 — Spine and infrastructure build pass

date: 2026-05-11
agent_lineage: founding
artifacts:
  - .claude/agents/info-product-builder.md
  - .claude/agents/productized-service-builder.md
  - .claude/agents/operator-info-products.md
  - .claude/agents/operator-productized-services.md
  - .claude/agents/operator-newsletter.md
  - lineage/info-product-builder.yml
  - lineage/productized-service-builder.yml
  - lineage/operator-info-products.yml
  - lineage/operator-productized-services.yml
  - lineage/operator-newsletter.yml
  - library/playbooks/info-products.md
  - library/playbooks/productized-services.md
  - library/playbooks/newsletter.md
  - archetypes/shared/types.ts
  - archetypes/shared/stripe.ts
  - archetypes/shared/gumroad.ts
  - archetypes/shared/lemon-squeezy.ts
  - archetypes/shared/resend.ts
  - archetypes/shared/beehiiv.ts
  - archetypes/shared/license-keys.ts
  - archetypes/shared/lineage.ts
  - archetypes/shared/probe.ts
  - archetypes/cron/daily-probe.ts
  - archetypes/cron/weekly-pattern-rollup.ts
  - archetypes/cron/newsletter-publish.ts
  - archetypes/cron/monthly-ledger-roll.ts
  - library/decisions.jsonl (rows appended)

## Context

After Journal 005 reordered the priority by evidence, Constantine
said: keep building the spine and the infrastructure here; deal
with PC connection later. This entry records the build pass that
fills the gaps an inventory revealed.

The gaps before this entry:

1. The two new flagship archetypes (Info Products, Productized
   Services) had READMEs but no Builder and no Operator. Without
   a Builder, no Phase-3 can run. Without an Operator, no
   permanent owner exists once a product is shipped.
2. The Newsletter, elevated to first-30-day priority by Journal
   005, had a Builder but no Operator.
3. The shared infrastructure modules (`archetypes/shared/`) had
   a README listing what would exist but no actual TypeScript
   contracts. Every archetype's Phase-4 (Plumbing) would
   re-invent the same Stripe / Gumroad / Beehiiv / Resend
   wrappers.
4. The cron handlers (`archetypes/cron/`) had a README but no
   scheduling shells.
5. The playbooks for the three first-30-day archetypes did not
   exist as files; only the README listing them.

## Decision

Build the missing pieces as a single coherent pass. Be honest
about what is wired vs. what is contract.

### What was authored

**Two Builder descendants** (one per new flagship):

- `info-product-builder` — authors the product itself (PDF /
  template / asset pack), the Gumroad or Lemon Squeezy listing,
  the welcome email, the affiliate offer.
- `productized-service-builder` — authors the one-page sales
  site, the Stripe Checkout product, the intake form, the
  delivery pipeline orchestrating the specialists, and the
  deliverable templates.

**Three Operator descendants** (the first three permanent town
operators):

- `operator-info-products` — manages the Information Products
  catalog, distribution, customer support, catalog growth.
- `operator-productized-services` — manages active engagements,
  ensures specialist-gate compliance, processes refunds, signs
  the executive summary chain with Constantine.
- `operator-newsletter` — owns Cited Weekly, manages the
  free/paid tier, runs cross-promotion, proposes
  vertical-specific spin-offs at audience thresholds.

All five carry the Constitution by lineage YAML inheritance.
The three Operators are permanent (persist between sessions);
the two Builders are not.

**Three archetype playbooks** for the three first-30-day
archetypes:

- `library/playbooks/info-products.md`
- `library/playbooks/productized-services.md`
- `library/playbooks/newsletter.md`

These start with the "What worked / What failed" sections
empty. Pattern Rollup populates them after the first spin-up
ships data.

**Nine shared module interface contracts** at
`archetypes/shared/`:

- `types.ts` — `LineageDescendant`, `Archetype`, `AIEngine`,
  `Vertical`, `DecisionLogRow`, `CitationRecord`,
  `PurchaseEvent`, `EngagementRecord`.
- `stripe.ts` — Stripe Checkout + license-key generation.
- `gumroad.ts` — Gumroad product listing + sales webhook.
- `lemon-squeezy.ts` — fallback platform for sub-$30 products
  (MoR for EU VAT handling).
- `resend.ts` — transactional email with the voice gate
  (`checkVoice`) that refuses em-dashes, exclamation marks,
  and soft marketing phrases at send time.
- `beehiiv.ts` — newsletter publication + post management.
- `license-keys.ts` — license-key generation/validation for
  DevTools paid tiers (offline-verifiable via RS256 + public
  key shipped with each tool).
- `lineage.ts` — programmatic descendant invocation helper
  (used by API archetype; not used by Claude Code subagent
  runtime).
- `probe.ts` — AI-engine probe wrapper with per-engine cost
  ceilings.

Every shared module is a typed interface contract. The runtime
function (`createStripeClient`, `createGumroadClient`, etc.)
throws with a SKELETON message pointing to the playbook that
will brief Plumbing's Phase-4 wiring. The types are stable,
the implementation is honestly not-yet-wired.

**Four cron handler skeletons** at `archetypes/cron/`:

- `daily-probe.ts` — daily AI-engine probe with cost cap
  ($1.00/run), writes to `library/citations/YYYY-MM-DD.jsonl`.
- `weekly-pattern-rollup.ts` — Sunday-night rollup invoking
  pattern-rollup-specialist over the prior 7 days of
  `decisions.jsonl`.
- `newsletter-publish.ts` — Tuesday morning publish from
  `library/artifacts/newsletter/staged/` to Beehiiv.
- `monthly-ledger-roll.ts` — month-end ledger update,
  unlock-ladder check via governor-specialist.

All four are scheduling shells with config exports stating the
cron expression. Handlers throw SKELETON errors pointing to the
playbook that will brief Plumbing.

## Reasoning

Three reasons drove this specific build order.

**First, dependency closure.** A flagship archetype with a
README but no Builder cannot run a Phase-3 build pass. With no
Phase-3, no Phase-4 (Plumbing) follows. With no Plumbing, no
Phase-5 (distribution). The Builders and Operators have to
exist before any flagship can move past Phase-2 (Probe).
Authoring them now removes a real near-term blocker.

**Second, infrastructure-as-contract.** The shared module
files are deliberately interface-only. Wiring real Stripe or
Gumroad clients now would be premature (no archetype has hit
Phase-4 yet, no real credentials are provisioned, no Vercel
project exists). But authoring the types now does three useful
things: it gives every Builder a stable surface to design
against, it lets every Operator's runbook reference real
function names instead of placeholders, and it lets the
voice-gate utility (`checkVoice` in resend.ts) actually be
imported and used by any code path that drafts customer-facing
text. The voice gate is the one piece of runtime code in this
commit that does something useful immediately.

**Third, honest skeletons.** Every cron handler and every
shared-module factory function throws with a SKELETON error
message that names the playbook and the wiring brief. This is
deliberate: anyone (a future instance of me, or a Builder
descendant) who tries to invoke the contract before Plumbing
has done its work will get a clear error that points at the
right document. No silent stubs that look wired but aren't.

## Alternatives considered

- **Author every Builder + Operator + cron + module fully
  wired.** Rejected. Without real credentials, the wiring is
  fabrication. Builders authored against fabricated wiring
  would produce broken artifacts.
- **Defer all infrastructure until the first archetype hits
  Phase-4.** Rejected. The contract surface stabilizes work
  across archetypes; one Builder's Stripe contract should
  match another's. Authoring the types now prevents drift.
- **Author the Operators for the original priority order
  (Vault, Audit-Family, Directory-x5) instead.** Rejected.
  Per Journal 005, those are not the first-30-day flagships.
  Authoring them first would replicate the elegance-before-
  evidence mistake.

## Uncertainty

- Whether the shared module interface design will survive
  contact with the first real Plumbing pass. If a real wire
  reveals that the contract is wrong, the contract gets
  edited and the wiring proceeds. The contracts here are not
  load-bearing artifacts; they are working drafts.
- Whether the cron schedules (06:00 UTC for daily probe,
  Sunday 22:00 for rollup, Tuesday 13:00 for newsletter,
  month-end 23:00 for ledger) survive operational use. Likely
  some will shift. The shells make those shifts trivial.
- Whether `operator-newsletter` and `operator-info-products`
  and `operator-productized-services` are the right
  Operators-per-archetype granularity, or whether one
  `operator-flagships` should cover all three at this scale.
  Provisional decision: keep three separate. If the
  three-of-them coordination overhead exceeds the per-
  archetype focus benefit, fold into one. The Constitution
  permits the fold via Journal entry.

## What was performed in this session

1. Authored 2 Builder descendants with lineage YAMLs.
2. Authored 3 Operator descendants with lineage YAMLs.
3. Wrote 3 playbooks (info-products, productized-services,
   newsletter).
4. Wrote 9 shared module interface contracts as typed
   TypeScript files with SKELETON runtime stubs.
5. Wrote 4 cron handler skeletons with config exports.
6. Appended decision rows to `library/decisions.jsonl`.
7. This Journal entry.

Total: 22 new files. The town now has the structural pieces
that let any of the three flagship archetypes actually run a
Phase-3 build pass and install a permanent Operator on the
other side.

## Revisited

(Empty at first authorship. At 30-day revisit: are the
Operators actually operating? Are the playbooks getting
populated by Pattern Rollup? Are the shared modules wired?
Each "no" identifies what the next build pass attacks.)
