# 003 — Five master patterns, not eight archetypes

date: 2026-05-11
agent_lineage: founding
artifacts:
  - library/protocol/v1.md  (Scout's job description updated implicitly)
  - this entry

## Context

Constantine has now told me three times in a row that I am thinking
too narrowly. The phrase he used in the third pass: "Please just
think in terms of what types of businesses they could all spin up
new forms of themselves. Using the same process over time that could
actually discreetly be making a killing online. And that does not
suffer from a slow ramp up period."

I have been writing the plan as "eight archetypes." That is the
wrong unit. Eight archetypes is a finite list. The right unit is
**patterns**, and each pattern can spawn unlimited instances. The
distinction matters because:

- A finite list caps ambition at the list length.
- A pattern is something the founding agent and its descendants can
  apply forever.
- The Spin-Up Protocol is already a meta-pattern — a pattern that
  produces businesses. What it needs to feed on is a small number of
  pattern-types, each one a domain inside which the Protocol can be
  applied repeatedly.

## Alternatives considered

- Keep the eight-archetype framing and just add more archetypes when
  needed. Rejected — same finite-list trap with a longer list.
- Frame as "infinite businesses, no categories." Rejected — without
  categorization the Scout has no shape for its surfacing, and the
  Library has no shape for its playbooks.
- Frame as five master patterns, each capable of unlimited instances.
  Chosen. Each pattern is a domain of repeatable spin-ups. The
  existing eight archetypes are recharacterized as instances within
  the patterns.

## Decision

The town's structural framing changes from "eight archetypes" to
**five master patterns**. Each pattern is a domain where the Spin-Up
Protocol can be applied without limit. Each instance of a pattern is
a micro-business with its own Operator descendant. The number of
instances per pattern is bounded only by parallel agent capacity and
the unlock ladder.

### Pattern A — Marketplace Multiplication

**Wherever a marketplace exists with native discovery and self-serve
checkout, the agent ships listings.** Each marketplace is one
instance; within each instance, listings multiply infinitely.

Marketplaces the town will populate over time:

- Gumroad, Polar, Lemon Squeezy (digital downloads).
- Etsy, Creative Market (design assets, printables).
- Chrome Web Store, Edge Add-ons (browser extensions).
- npm, GitHub Marketplace (developer packages, paid Actions).
- VSCode Marketplace, JetBrains Marketplace (IDE plugins).
- WordPress.org plugin repo (plugins).
- PromptBase, Promptly (AI prompt packs).
- Notion Marketplace (templates).
- Canva Templates, Adobe Express Templates (design templates).
- Adobe Stock, Shutterstock (stock content royalty model).
- Pinterest's monetization program (curated boards).
- Beehiiv Recommends network (cross-promotion for newsletters).
- Cloudflare Workers Marketplace (edge functions).
- Shopify App Store, HubSpot App Marketplace, Zapier app
  directory, Salesforce AppExchange (B2B SaaS integrations).

Each marketplace is its own Operator descendant
(`operator-marketplace-<platform-slug>`). Each Operator's Growth
Clause: when one marketplace clears $200/mo for 60 days, propose
either (a) doubling the listing count on that marketplace or (b)
opening a new marketplace in the same content vertical.

**Ramp speed:** first sale typically 7-14 days. Fastest pattern.
Leads.

### Pattern B — Search-Visible Single-Purpose Tools

**Anywhere someone searches for a one-thing tool, the agent ships
that tool.** Each tool lives on its own domain or sub-domain. Each
tool ranks for its primary query. Each tool monetizes via ads,
affiliate, freemium upsell, or token-metered paid usage.

Instances range from:

- Generators: favicon, QR code, gradient, lorem ipsum, color
  palette, font pairing, logo placeholder, llms.txt, robots.txt,
  sitemap, JSON-LD schema, etc.
- Validators: schema, HTML, CSS, JSON, YAML, JWT, etc.
- Calculators: vertical-specific (paint calculator, fence cost,
  tile estimator, fuel consumption, loan amortization,
  appointment availability, etc.).
- Browser-side AI tools: any tool that works without an API key on
  the user's own input.
- Specialized lookups: WHOIS, DNS, IP, port, headers, etc.
- The Audit-Tool Network (Citation family) is already in this
  pattern.

Each tool is its own domain and its own Operator (or grouped under
`operator-webtool-family` when tools share a common substrate).
Operator Growth Clause: when 5 tools each clear $50/mo for 60
days, propose 5 vertical-specific forks of the highest earner OR a
paid-tier feature layer on the top two.

**Ramp speed:** first revenue 14-30 days via affiliate clicks;
first paid upsell 30-60 days.

### Pattern C — Programmatic Cross-Product Content Networks

**Anywhere the cross-product of two enumerable dimensions creates
long-tail SEO opportunity, the agent generates content at scale.**

Cross-product dimensions include:

- (vertical × geo) — local-service directories. The Directory
  archetype is already in this pattern.
- (product × brand) — shopping/affiliate comparison sites.
- (skill × tool) — programming and design tutorials.
- (problem × language) — code-solution sites.
- (recipe × diet) — food sites.
- (model × engine) — AI prompt and tool guides.
- (template × vertical) — workflow and process documentation.

Each (X, Y) network is its own brand and its own Operator
descendant (`operator-network-<cross-product-slug>`). Each page in
a network passes the five discoverability specialists' gating
before publish. Quality bar prevents this pattern from degenerating
into AI-slop content.

Operator Growth Clause: when a network clears $500/mo for 60 days,
propose either (a) doubling page count within the current
cross-product, (b) opening a sibling cross-product, or (c)
spinning a featured-listing premium tier for the existing pages.

**Ramp speed:** first revenue 30-60 days (indexing wait). Slow
start but the asset is durable.

### Pattern D — Niche Subscription Properties

**Where a recurring micro-payment can be sustained by ongoing
content or access, the agent runs the subscription.**

Instances:

- Paid newsletters on Beehiiv (Cited Weekly is one).
- Paid Discord/Slack communities with members-only channels.
- Paid podcast feeds (Patreon, Memberful, Substack audio).
- Paid email courses.
- Paid Telegram channels (where the audience exists).
- Paid Twitter/X subscription via Super-Follows or X Premium
  Connections.

Each property has its own audience and its own Operator. Growth
Clause: when a property crosses 1,000 free subscribers, open the
paid tier. When the paid tier crosses 100 paying subscribers,
propose a vertical-specific spin-off (e.g., Cited for Dentists,
Cited for Law Firms).

**Ramp speed:** slow. 30-90 days to first paying subscriber.
Durable.

### Pattern E — Productized Async Services

**Where a fixed-price async deliverable can be productized on a
marketplace, the agent fulfills it.**

Instances:

- Audits delivered as PDFs.
- Site rebuilds shipped as starter forks.
- Brand kits and design assets.
- Strategy documents.
- Custom integrations.
- Audit-and-fix bundles (audit a domain, deliver a remediation
  set).

Each productized service is one or more Gumroad/Polar listings
with a Stripe-receipt-triggered intake form. Async fulfillment;
the agent never speaks to the buyer live. Bandwidth-bottlenecked
on parallel agent capacity. Operator Growth Clause: when a
service consistently clears 2 paid sales per week, propose either
a higher-tier service or a vertical-specific spin-off.

**Ramp speed:** 14-45 days to first sale. Bandwidth limits scale.

## Reasoning

The five-pattern framing has three structural advantages over the
eight-archetype framing.

First, it makes the Scout's job legible. Instead of asking "what new
archetype should we add?", the Scout asks "which instance of which
pattern is most worth pursuing right now?" That is a much narrower,
more answerable question.

Second, it makes the Operator family scalable. Eight Operators (one
per archetype) caps the town's complexity. Five patterns with
unlimited instances means the Operator family grows as the town
grows. By the time the unlock ladder funds twenty parallel agent
processes, the town has twenty-plus Operators, each running its
own instance of one of the five patterns.

Third, it makes "discreetly making a killing online" structurally
achievable. The fastest paths to revenue (marketplaces, single-page
tools, productized services) all live in Patterns A, B, and E,
which the framing now puts on equal footing rather than as
sub-categories under archetype-level priority.

## Adoption order

Adoption order is reordered to prioritize speed-to-revenue:

1. **Pattern A (Marketplace Multiplication)** — start Week 1.
   First instances: Gumroad Vault, Polar Vault, Chrome Web Store
   Extensions.
2. **Pattern B (Single-Purpose Tools)** — start Week 1. First
   instances: Citation free Scan, Schema Doctor, llms.txt
   Sentinel, plus 3-5 simple generators/validators in the first
   month.
3. **Pattern E (Productized Async Services)** — start Week 4
   after Patterns A and B have produced first revenue. First
   instances: $499 audit, $999 site rebuild.
4. **Pattern D (Subscription Properties)** — start Month 2
   after Pattern B's free Scan funnel has produced an audience.
   First instance: Cited Weekly newsletter, paid Discord later.
5. **Pattern C (Cross-Product Content Networks)** — start Month
   2 alongside Pattern D. First instance: (mobile-detailing × FL
   geo). Adoption is calendar-time-limited by indexing, so it
   runs in parallel rather than after.

## Uncertainty

- Whether the marketplaces listed under Pattern A are still equally
  permissive in 2026 of AI-generated listings. Mitigation: the
  five discoverability specialists gate every listing, so the
  outputs are not raw-generated; they are agent-built artifacts
  passing through quality checks. This is the same gating that
  applies to BayShine and that we know produces marketplace-quality
  work.
- Whether the Operator-per-instance model produces enough
  parallelism without overwhelming the Governor. The cost-cap
  enforcement scales linearly; the Operator headcount scales with
  parallel agent capacity, which the unlock ladder gates. I think
  this is fine but it is the first thing the Governor will report
  on if it goes wrong.

## What changes for prior decisions

- The Spin-Up Protocol v1 (`library/protocol/v1.md`) stays as
  authored. It is pattern-agnostic. The Scout's Phase 1 output now
  explicitly tags candidates with their pattern (A through E)
  alongside the archetype hypothesis.
- The eight archetype directories under `archetypes/` remain in
  place as scaffolding for the first instances. They are not the
  ceiling.
- The Operator-per-instance structure means the Operator headcount
  grows past the 8-12 I sketched in PLAN.md. By month 24 the town
  is realistically running 30-50 Operators across the five
  patterns.

## Revisited

(Empty at first authorship.)
