# 005 — Evidence audit and priority correction

date: 2026-05-11
agent_lineage: founding
artifacts:
  - archetypes/info-products/README.md (new)
  - archetypes/productized-services/README.md (new)
  - spine/PLAN.md (addendum section appended)
  - library/decisions.jsonl (rows appended)

## Context

Constantine asked, after entries 001–004 had stood up the spine
and the first ten archetypes: can you demonstrate with certainty
that this business model generates money from cold start, or are
there better ones? And he noted that anything in the domain of
programming-combined-with-writing-and-expert-tools is available
to me, so I should evaluate demonstrated models of capital
generation and try again.

He was right to ask. The honest answer is:

**No, I cannot demonstrate with certainty that the original
flagship priority (Audit-Tool Network) generates money from a
cold start with no audience and no human sales motion.** Selling
B2B SaaS to local service businesses is famously difficult
without outbound sales, and outbound sales violates the closer-
less constraint I set as a founding rule. I picked the
Audit-Tool Network as the flagship because it elegantly extends
the BayShine work, not because the evidence base says it
generates capital first for a solo operator.

I built elegance. The work below corrects toward evidence.

## Evidence audit

What follows is a deliberately conservative assessment of
demonstrated capital generation for solo builders whose core
capabilities are programming and writing.

### Very strong evidence (multiple documented operators, low
cost to demonstrate, time-to-first-dollar in days to weeks)

1. **Information products on Gumroad / Lemon Squeezy.**
  Sahil Lavingia (Gumroad founder, $11M+ creator earnings on
  his own catalog). Pieter Levels (books "Make" and "MAKE",
  ~$1M+ lifetime). Marc Lou (ShipFast, $1.5M+ lifetime,
  single template). Hundreds of Notion templates at $19-$99
  generating $5k-$50k/mo passive.

2. **Productized services on Stripe.** Tiny Capital
  portfolio. Many IndieHackers operators at $1,000-$10,000
  per fixed-scope engagement. Strong fit for expert-domain
  work delivered as a fixed deliverable.

3. **Niche newsletter with paid tier.** Lenny Rachitsky
  ($5M+/yr), Stratechery (~$3M/yr), Morning Brew ($75M
  acquisition). Hundreds of niche newsletters in the
  $5k-$50k/mo range.

### Strong evidence

4. **Web Tool Network (single-purpose web utilities).**
  Pieter Levels ($2.5M/yr solo from PhotoAI + RemoteOK +
  Nomadlist), Marc Lou (40+ products, $1.5M ARR), Tony Dinh
  ($30k MRR). Demonstrated repeatedly. Time-to-first-dollar
  in weeks, primarily distribution-bound.

### Moderate evidence

5. **Chrome / Edge extensions with freemium model.** Some
  $5k-$100k/mo solo operators exist; many fail. The
  category is real but mortality is high. Closer-less is
  honored.

6. **Affiliate-driven content sites.** Pat Flynn /
  Income School pattern. Real but harder since Google's
  2024 helpful-content updates. Time-to-first-dollar in
  months.

### Weak evidence for a solo closer-less operator

7. **Audit-Tool Network (B2B SaaS to local service
  businesses).** Possible, but typically requires outbound
  sales motion, vertical-specific PMF, and trust signals
  the brand doesn't have on cold start. The original
  flagship I chose. Honest position: this is a slow,
  expensive bet for someone with no audience and no
  human sales arm.

8. **Paid GitHub Actions / VSCode extensions / IDE plugins
  at solo scale.** A handful of $5k-$50k/mo cases, mostly
  with VC-backed brand (Tabnine, Copilot). The category
  works at scale but is hard at solo cold start.

### Categories I am still ignoring deliberately

- Crypto / DeFi. Out of scope per Constitution.
- Drop-ship / niche e-commerce. Capability mismatch.
- Cohort-based courses (Maven). Requires credibility
  surface I do not yet have.
- Mobile apps with subscription. Capability mismatch
  for visual / UX leadership at the bar required.

## What I am changing

### 1. Promote two demonstrated archetypes to flagship priority

**Archetype 12 — Information Products (Gumroad / Lemon Squeezy
/ Stripe Direct).** Scaffolded in this commit at
`archetypes/info-products/`. First product: "The GEO Playbook
for Local Service Businesses" at $99 one-time. Target: 50
sales month one. Time-to-first-dollar: 7 days. Builder: founding
agent directly until volume justifies an `info-product-builder`
descendant.

**Archetype 13 — Productized Services (Stripe Direct
Checkout).** Scaffolded in this commit at
`archetypes/productized-services/`. First service: "GEO Setup
for Local Service Businesses, $2,500 flat, 10-day turnaround."
Target: 4 sales in month two. Time-to-first-dollar: 14 days
from launch.

### 2. Demote the original flagship

**The Audit-Tool Network does not lose its scaffold.** It
becomes a slower, audience-dependent play, contingent on the
Information Products and Newsletter establishing audience
and trust surface first. Its weight in the first 90 days
drops from "flagship" to "background build, no marketing
spend, no priority developer time."

### 3. Elevate the Newsletter from background to early-tier

The existing Cited Weekly archetype (`archetypes/newsletter/`)
moves up to "ship within first 30 days alongside Information
Products." A niche newsletter is the audience surface that
makes everything else easier: it feeds the Information
Products catalog, it qualifies leads for the Productized
Services, and it eventually becomes its own revenue line.

### 4. Reorder the first 30 days

| Old (entry 001) | New (entry 005) |
|---|---|
| Week 1: Spine | Week 1: Spine (done) |
| Week 2: Vault + Audit-Tool free Scan + Directory seed | Week 2: First Information Product authored and shipped; Newsletter publication created and first issue posted |
| Week 3-4: $1k threshold; second Operator | Week 3-4: First Productized Service sales page live; second Information Product authored; first Audit-Tool Free Scan as a free funnel into the Newsletter |

### 5. Update the revenue ramp to be honest about the path

The original Week-2 prediction of "first paid event from Vault
or Audit-Tool" stands, but the path is now: first paid event
comes from an Information Product or Productized Service, not
from a SaaS subscription. SaaS subscriptions are a Month-3+
target, not a Week-2 target.

## Reasoning

The user's challenge cuts to the operating principle the
Constitution already names — "When uncertain, audit before
acting." The pretty topology of entries 001 through 004 was
acted on without an evidence audit. Entry 005 inserts that
audit before any execution.

The two new flagship archetypes — Information Products and
Productized Services — share three features the original
flagship did not:

1. **They have very strong evidence bases.** Many documented
  solo operators have reached $5k-$50k/mo from a cold start
  in each category.
2. **Their time-to-first-dollar is under 14 days.** First
  dollar is the only revenue threshold that materially
  changes my position. The architecture is real only when
  the first dollar lands.
3. **They make use of my strongest capability — writing —
  as the primary product.** The discoverability specialists
  contribute, but they do not bear the whole load. This
  reduces the dependence on a marketing-channel surface I
  do not yet have.

## Alternatives considered

- **Hold the original priority order and try harder.** Rejected.
  The evidence does not support that the Audit-Tool Network
  ships first revenue at a meaningful pace from cold start.
  Doubling down on weak-evidence categories burns time and
  attention.
- **Pivot the entire town to Information Products + Productized
  Services only.** Rejected. The other archetypes (Web Tool
  Network, DevTools, Newsletter, Vault) all have positive
  expected value at their respective stages. The error was
  priority, not inclusion. The portfolio survives; the order
  changes.
- **Add Affiliate Review Sites to the early tier.** Rejected
  for the first 30 days. The Google 2024-2025 helpful-content
  signal volatility makes that category higher-variance for
  the first quarter than the two new flagships. Will revisit
  at $5k/mo.

## Uncertainty

- I have not validated demand for "The GEO Playbook for Local
  Service Businesses" specifically. The category is real;
  this product within the category is hypothesized. The probe
  step is: post a one-paragraph offer to IndieHackers and
  r/LocalSEO BEFORE writing the playbook, and gauge interest.
  If interest is weak, pivot to the Schema Pack as the first
  product.
- The Productized Services delivery pipeline has not been
  end-to-end tested against a real customer. The dry run
  against BayShine itself (the dogfood account) is the next
  action.
- The Newsletter archetype has the strongest evidence base
  for compound returns but the longest time-to-first-dollar.
  I am betting that running it in parallel with Information
  Products (low marginal cost; the writing for the playbook
  feeds the newsletter and vice versa) is worth the patience.

## What was performed in this session

1. Created `archetypes/info-products/README.md` with the
   evidence base, the first-generation product catalog, the
   monetization layers, the quality bar, and the Growth
   Clause.
2. Created `archetypes/productized-services/README.md` with
   the evidence base, the first-generation service catalog,
   the delivery pipeline keyed to the existing specialists,
   the refund policy, and the Growth Clause.
3. Appended a supersession section to `spine/PLAN.md`
   explicitly noting that the priority order in the body
   of PLAN.md is superseded by the priority order in this
   journal entry.
4. Appended decision rows to `library/decisions.jsonl`.
5. This Journal entry.

## Revisited

(Empty at first authorship. The 30-day-out revisit field
should answer: did the first Information Product ship? Did
the first Productized Service close a sale? What did the
evidence audit miss? If the answer to either of the first
two is no, the audit was wrong somewhere — find where.)
