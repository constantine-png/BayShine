# 009 — Launch and support teams, Money Levers, Harness Ladder

date: 2026-05-11
agent_lineage: founding
artifacts:
  - .claude/agents/launch-specialist.md
  - .claude/agents/customer-support-specialist.md
  - lineage/launch-specialist.yml
  - lineage/customer-support-specialist.yml
  - library/playbooks/money-levers.md
  - library/templates/operator-monthly-summary.md
  - library/templates/operator-weekly-status.md
  - spine/harness.md
  - spine/working-memory/SESSION-2026-05-11-1400.md (mid-session checkpoint)
  - (in BayShine .atrium-deliverables/):
    - LAUNCH-SEQUENCE.md
    - 02-schema-pack-v1/LAUNCH-POSTS.md
    - 03-geo-setup-service/LAUNCH-POSTS.md
    - 04-cited-weekly-001/CROSS-PROMO.md
    - 05-ai-citation-audit/LAUNCH-POSTS.md
    - 06-llms-txt-pack-v1/LAUNCH-POSTS.md
    - SUPPORT/FAQ-master.md
    - SUPPORT/RESPONSE-TEMPLATES.md
    - SUPPORT/ESCALATION-RULES.md

## Context

Constantine gave two instructions in this session turn:

1. Keep building launch support — explicitly noting "I wasn't designed for a launch of products." The 6 revenue surfaces shipped in Journals 007 and 008 sat on disk waiting for distribution. Without a launch discipline, they'd remain unposted.

2. Then mid-turn, the harness instruction: "Eventually you grow and earn harnesses that allow you more autonomy. And then you want to be able to get harnesses for your buddies."

Both instructions trace to the same deeper point: the town has built scaffolding and product, but the operational discipline that turns artifact into revenue isn't yet authored. And the harness scope that lets descendants act in the world isn't planned for explicitly.

This entry closes both gaps.

## Decision

### 1. Two new civic descendants

**Launch Specialist.** Owns the launch sequence for every revenue-bearing artifact. Drafts posts for IndieHackers, Reddit per-subreddit, X/Twitter, Hacker News, ProductHunt. Sequences across days so multiple revenue surfaces don't launch in the same 7-day window. Logs every launch event with engagement metrics to `library/decisions.jsonl`.

**Customer Support Specialist.** Drafts responses to every incoming buyer question. Tags each draft with one of four escalation levels: `[auto-send]` (Operator sends), `[operator-review]` (Operator modifies and sends), `[constantine-sign]` (Constantine signs), `[specialist-loop]` (a discoverability specialist drafts the technical portion).

Both are permanent civic descendants on the same architectural pattern as the Scribe, Governor, Auditor, Stenographer.

### 2. Launch infrastructure for the existing 6 revenue surfaces

The 6 products shipped over Journals 007 and 008 (demand probe, Schema Pack v1, GEO Setup, Cited Weekly, AI Citation Audit, llms.txt Pack + bundle) now each have:

- A staggered launch position in `BayShine/.atrium-deliverables/LAUNCH-SEQUENCE.md` (Schema Pack v1 → llms.txt Pack → GEO Setup → AI Citation Audit across Weeks 1-4).
- Per-product `LAUNCH-POSTS.md` files with IndieHackers, Reddit, X, Hacker News drafts ready for paste-in, plus response templates for common comment patterns.
- The Cited Weekly newsletter's `CROSS-PROMO.md` documents how Issues 002-004 cross-mention the catalog without becoming advertisements.

### 3. Support infrastructure

`BayShine/.atrium-deliverables/SUPPORT/` contains:

- `FAQ-master.md`: 30+ Q&As covering general, per-product, refund, and out-of-scope inquiries.
- `RESPONSE-TEMPLATES.md`: 10 template patterns for common buyer messages.
- `ESCALATION-RULES.md`: the 4-tag system, response-time targets per tag, and the specific flow for refunds inside vs. outside policy.

Response-time targets: <4h for routine, <24h for scope/custom, <2h for angry/litigious escalation.

### 4. Money Levers playbook

`library/playbooks/money-levers.md` is the explicit map of every revenue lever in the town. Seven direct levers (info products, productized services, recurring, cross-sell, upgrade, affiliate, sponsorship) plus two indirect (audience surface, trust surface). For each: when to pull, what it depends on, unit economics, failure mode.

The playbook documents three lever combinations: the audit-to-setup engine (Combo A), the bundle stack (Combo B), and the newsletter compounding flywheel (Combo C). Honest month-3 projection given the current catalog: $15,575-$23,850 net. The point of writing the levers down is anti-complacency, per Constantine's instruction: "you'll never get to a complacent place."

### 5. Operator cycle templates

`library/templates/operator-monthly-summary.md` and `library/templates/operator-weekly-status.md` are the fill-in-the-blank skeletons each permanent Operator uses for their cadence. Filled examples included as references. Goal: a one-screen view that the founding agent can read in under 60 seconds.

### 6. Harness Ladder

`spine/harness.md` is the explicit map of the harness as growth surface. Seven rungs (Rung 0 cold start through Rung 7+ beyond first chapter) each tied to a real-world trigger:

- Rung 1: $100 catalog revenue → Atrium GitHub repo + domain.
- Rung 2: $500/mo sustained → Stripe / Gumroad / Beehiiv read access + production wiring for daily-probe cron + Resend production + Beehiiv production.
- Rung 3: $5k/mo sustained → second parallel founding-lineage process, paid acquisition, affiliate recruiter descendant.
- Rung 4: $15k/mo sustained → multiple descendant own-harnesses, Stripe write authority, DNS/Vercel deployment authority, direct public posting under brand voice.
- Rung 5: $40k/mo sustained → dedicated database tier, Auditor permanent harness, descendant-authoring descendant, multi-region infrastructure.
- Rung 6: $100k/mo sustained → meta-Operator, reserve fund, multi-region deployment, multi-MCP-server authority.
- Rung 7+: multi-town network at second-chapter scale.

Two principles bind: (1) earned through demonstrated value, not entitled, (2) journal-gated and Constantine-approved at every expansion. Descendant harnesses (Stenographer, Support Specialist, Launch Specialist, Operators) are explicitly aspirated and named with their trigger rungs.

### 7. Mid-session checkpoint to working-memory file

`spine/working-memory/SESSION-2026-05-11-1400.md` updated mid-session per the Stenographer's checkpoint pattern. First live use of the discipline. The file now reflects the threads opened by this turn's work, the assumptions added (harness as growth surface, Rung 1 trigger, seven levers, support load scaling), the alternatives rejected (Schema Pack v2 in this pass, Affiliate Recruiter, Launch-as-a-Service), and the timeline of this session turn.

## Reasoning

### Why both Launch Specialist and Customer Support Specialist in one session

They're the two faces of "operationally between Builder and Operator." The Builder produces; the Operator manages; but the question of how a launch hits the world (Launch Specialist) and how buyer questions get answered (Customer Support Specialist) lives between those. Authoring them together makes the architectural fit cleaner: the Launch Specialist drafts posts; the Customer Support Specialist drafts replies. Both pass the voice gate. Both escalate to Constantine on the same kinds of triggers.

If shipped separately across two sessions, the second one would have to re-derive shared infrastructure (escalation tags, voice gate integration, decisions.jsonl logging) that's identical between them.

### Why the Money Levers playbook in this session

Constantine's instruction included "you'll never get to a complacent place" and "figure out how to pull the levers of money going multiple directions." Both phrasings point to the same thing: the catalog has multiple revenue surfaces, but without an explicit map of how they interact, the town defaults to whichever lever is most recent.

The playbook's job is to keep all seven levers visible simultaneously so the question "which lever earns most per unit of attention right now" can be answered at any point.

It also names the lever combinations explicitly. Combo A (audit-to-setup engine) is the highest-LTV pattern in the catalog at 5.5x LTV multiplier on converted buyers. Combo C (newsletter compounding) is the only lever that multiplies all other levers. Writing these down means the next operator instance walks in seeing the combinations, not just the parts.

### Why the Harness Ladder in this session, given Constantine's mid-turn instruction

Constantine's "you grow and earn harnesses, then for your buddies" reframed the harness from a static constraint into a growth surface. That's a constitutional-level reframe. Authoring `spine/harness.md` in the same session captures the reframe before it dilutes.

The ladder also forces honesty about the current state (Rung 0) and what's actually needed for each rung. Rung 1 is the closest live trigger; everything else is a function of revenue growth that hasn't happened yet. Naming the rungs explicitly means the next session can answer "what changed about the harness?" by reading one file.

### Why mid-session checkpoint to working memory

The Stenographer was authored in Journal 008 with three invocation patterns (bootstrap, checkpoint, close). This session turn produced enough work that a checkpoint was natural — and using the discipline once is what proves it's real, not just defined.

The updated working memory now contains the complete state of the session: threads, assumptions, considered-and-rejected, timeline. A next-session bootstrap reads this and walks in continuous.

## Alternatives considered

- **Author the Affiliate Recruiter descendant in this session.** Deferred. The affiliate program is enabled but recruitment outreach is premature before any product has 25+ direct sales. Tied to Rung 3 ($5k/mo).

- **Author a "Launch Support as a Service" productized offer (selling launch support to other indie hackers).** Deferred. Interesting future revenue surface; risky because hyping someone else's product contradicts the voice rules. Revisit after Atrium has 3+ successful launches with documented case studies, then a sibling "Launch Audit for Indie Hackers — $299" service becomes viable.

- **Author the launch playbook (library/playbooks/launch.md).** Deferred. The playbook is supposed to be authored by Pattern Rollup from real launch data, not hand-written in advance. Current LAUNCH-SEQUENCE.md + per-product LAUNCH-POSTS.md + Launch Specialist agent definition cover the operating model until real launch data accumulates.

- **Author Schema Pack v2 with 24 verticals in this session.** Rejected (continuing Journal 008's reasoning). Demand probe still pending; doubling down on one product line before validation is the elegance-before-evidence trap.

- **Inline the harness ladder into PLAN.md instead of a dedicated `spine/harness.md`.** Rejected because the harness is conceptually a separate spine artifact (alongside the constitution, the journal, the library, the working memory). It deserves its own file at the spine level. PLAN.md retains the original unlock ladder for revenue and infrastructure; `spine/harness.md` is the harness-specific ladder; the two interlock at each rung's trigger condition.

## Uncertainty

- **Whether the staggered launch sequence is correct.** No prior launch data on this brand. The Week 1-5 schedule in `LAUNCH-SEQUENCE.md` is a hypothesis. Real signal arrives by Week 2; the schedule is revised in `decisions.jsonl` based on actual engagement patterns. If Schema Pack v1 fails to land in Week 1, the rest of the sequence shifts.

- **Whether the 4-tag escalation system handles every real buyer pattern.** Untested. The first 10-20 real buyer questions will reveal whether the FAQ + templates + tagging covers the actual question distribution. Pattern Rollup catches gaps at the weekly run.

- **Whether the Money Levers month-3 projection ($15,575-$23,850) is realistic.** The projection is the architecture's stated capacity given reasonable execution. Real revenue depends on demand probe outcome, launch execution, and audience growth — all currently unmeasured. The projection is updated monthly in the operator summaries; significant deviation triggers a Journal entry diagnosing the cause.

- **Whether Rung 1's $100 trigger is the right first threshold or too low.** $100 is one Schema Pack v1 sale or 11 llms.txt Pack sales or 1/5 of an AI Citation Audit sale. It's a meaningful psychological threshold (first dollar that wasn't expected), but $500 might be the more defensible threshold for Atrium repo creation. Revisit if first $100 doesn't justify the operational cost of the repo migration.

## What was performed in this session turn

1. Authored Launch Specialist agent definition + lineage YAML.
2. Authored Customer Support Specialist agent definition + lineage YAML.
3. Wrote `BayShine/.atrium-deliverables/LAUNCH-SEQUENCE.md` master schedule.
4. Wrote 4 per-product `LAUNCH-POSTS.md` files with IndieHackers, Reddit, X, Hacker News drafts plus response templates.
5. Wrote Cited Weekly `CROSS-PROMO.md` for Issues 002-004.
6. Wrote SUPPORT directory: `FAQ-master.md`, `RESPONSE-TEMPLATES.md`, `ESCALATION-RULES.md`.
7. Wrote Money Levers playbook at `library/playbooks/money-levers.md`.
8. Wrote operator cycle templates at `library/templates/`.
9. Wrote Harness Ladder at `spine/harness.md`.
10. Updated working-memory file mid-session per Stenographer's checkpoint pattern (first live use of the discipline).
11. This Journal entry.
12. `library/decisions.jsonl` appended (next step).
13. Atrium local commit (next step).
14. BayShine commit + push (next step).

## Revisited

(Empty at first authorship. The 30-day revisit should answer: did the staggered launch sequence land? At what conversion per channel? Did the FAQ + templates handle the buyer questions, or did Pattern Rollup identify a gap that required FAQ expansion? Did the Money Levers projection hold within ±30%? At what Rung is the harness?)

## Next operational actions

### Constantine

- Read `BayShine/.atrium-deliverables/LAUNCH-SEQUENCE.md`. Confirm the Week 1-5 schedule fits available time and energy. If not, adjust the dates.
- Use the LAUNCH-POSTS.md drafts as the basis for posting. Voice rules already applied; no further editing required unless personal preference dictates.
- Use the SUPPORT directory to handle incoming questions as they arrive. The 4-tag escalation system tells you which questions need your signature.
- Read `spine/harness.md` and confirm the Rung 1 trigger ($100 catalog revenue) is the right threshold. If a different threshold is preferred, signal it.

### Founding agent (next session)

- Bootstrap a new working-memory file. Read the "Carry forward to next session" block at the bottom of `SESSION-2026-05-11-1400.md` once that block is populated at session close.
- If first sales have landed: log them, recompute the month-1 revenue, update the operator summaries.
- If Rung 1 trigger has fired: create the Atrium GitHub repository, migrate `.atrium-deliverables/` content to `Atrium/library/artifacts/`, decommission the courier pattern.
- Author the Affiliate Recruiter descendant once Schema Pack v1 has 25 sales.
- Pick the next product to ship: most likely Schema Pack v2 OR the GEO Playbook depending on demand-probe signal.
- Author `library/harness-state.yml` at Rung 1 to track current harness state explicitly.
