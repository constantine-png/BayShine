# 014 — Schema Pack v1.5 + Forge outbound kit

date: 2026-05-11
agent_lineage: founding
artifacts (BayShine .atrium-deliverables/):
  - 08-schema-pack-v1.5/ (full pack with 9 verticals, $39)
  - FORGE-OUTBOUND-KIT/ (5 documents: README, cold email templates, LinkedIn outreach, prospect dossier, sequence playbook)

## Context

Continuing under "continue until I tell you to stop." Identified two leveraged gaps after the Journal 013 work:

1. **Schema Pack catalog mismatch.** Forge's Schema Generator (free) covers 9 verticals (mobile detailing, pressure washing, mobile car wash, HVAC, plumbing, roofing, electrical, pest control, landscaping). Atrium's Schema Pack v1 ($29) covers only 6. The 3-vertical gap is value leaking from Atrium's catalog to Forge's free tool — a user who needs electrical or pest control or landscaping gets it for free from Forge instead of paying Atrium for the equivalent pack.

2. **Forge outbound infrastructure missing.** Forge's CHARGE.md says outbound is the engine (the inversion of Atrium's closer-less discipline). But Forge has no templates, no dossier framework, no sequence playbook. When Forge Rung 2 unlocks paid acquisition and outbound tooling, the cold start would re-invent the templates from scratch.

## Decision

### 1. Schema Pack v1.5 at $39

Ships in `BayShine/.atrium-deliverables/08-schema-pack-v1.5/`. Nine verticals total — the original 6 from Schema Pack v1 plus electrical, pest control, and landscaping. Same per-vertical structure (LocalBusiness with typed subclass + Service block + FAQPage with 5 vertical-specific Q&As).

Pricing strategy:

- Schema Pack v1 ($29, 6 verticals) stays live as the entry tier and grandfathered for existing buyers.
- Schema Pack v1.5 ($39, 9 verticals) becomes the new flagship.
- v1 buyers get free upgrade to v1.5 (one-time email confirms eligibility).
- v2 (24 verticals at $49) ships when v1.5 has 50+ sales or 100+ waitlist signups.

The 3 new verticals use real schema.org subtypes: `Electrician`, `PestControl`, `LandscapeService`. Each FAQ block has 5 vertical-specific Q&As calibrated for AI search citation (pricing, scheduling, scope questions, technical edge cases).

All 3 new JSON files validated via python json.load. Catalog now matches Schema Generator coverage.

### 2. Forge outbound kit

Five documents in `BayShine/.atrium-deliverables/FORGE-OUTBOUND-KIT/`:

- **README.md** — overview, voice rules, expected conversion math at scale, when to use (Forge Rung 2+).
- **COLD-EMAIL-TEMPLATES.md** — 6 variants for different prospect types: multi-location service operators, regional agencies, SaaS founders, single-location operators with weak schema, existing audit buyers (upgrade nudge), enterprise prospects.
- **LINKEDIN-OUTREACH.md** — connection request templates (L1-L3), follow-up message templates (F1-F3), InMail template (I1 for enterprise), rate limits, what NOT to do on LinkedIn.
- **PROSPECT-DOSSIER.md** — fillable research template covering basic identification, contact, AI search probe results, structural gaps, top competitors, hook, right-product-fit checklist, outreach plan, constitutional compliance check, decision log.
- **SEQUENCE-PLAYBOOK.md** — 4 sequences (Sprint 4-touch, Standard 7-touch, Patient 10-touch for enterprise, LinkedIn-only 3-touch) with day-by-day cadence, stopping criteria, tracking format.

The kit is Forge-specific (lives in BayShine courier because Atrium doesn't run outbound; eventually migrates to `Forge/library/playbooks/outbound/`). Constitutional compliance is enforced throughout: named operator presence required, no invented metrics, no fake scarcity, one ask per touch, voice gate before send.

Expected conversion math documented in README: at 1,000 outbound sends per week, 5-10% reply rate, 1-3% meeting-booked rate of replies, 10-25% engagement-close rate of meetings. Translates to 1-4 engagements closed per month from outbound alone. At Forge's Enterprise GEO Sprint ($5,000) or Program ($25,000), that's $5k-$100k monthly revenue from outbound at maturity.

## Reasoning

### Why fix the Schema Pack mismatch now

The Schema Generator and Schema Pack are both shipped and pointed at by the GO-LIVE master. A buyer who finds the Schema Generator first (free, generates JSON-LD for all 9 verticals) has no reason to buy Schema Pack v1 if their vertical is in those 9. The pack's value premium over the Generator is install instructions + pre-validation + welcome email + support — but if Schema Pack v1 doesn't include the buyer's vertical, the premium doesn't matter.

Schema Pack v1.5 closes the mismatch. Same install premium; matched vertical coverage; $10 more than v1 for 50% more verticals.

The catalog now flows correctly:

- Schema Generator (free): casual user, ad-hoc generation, 9 verticals.
- Schema Pack v1 ($29): six-vertical entry tier, existing buyers grandfathered.
- Schema Pack v1.5 ($39): nine-vertical current flagship.
- Schema Pack v2 ($49): twenty-four-vertical future expansion when demand justifies.
- GEO Playbook v0.5 ($79): methodology depth.
- AI Citation Audit ($499): diagnostic service.
- GEO Setup ($2,500): full implementation service.
- Citation Watch ($19/mo): continuous monitoring SaaS.
- Schema Doctor Pro ($99/mo): developer-tier SaaS.

Nine price points from $0 to $25,000 across two networks. Each tier serves a distinct buyer profile. The catalog is now meaningfully shaped.

### Why build the outbound kit before Rung 2 fires

Two reasons:

**First, sequencing**. Rung 2 unlocks paid acquisition AND outbound email tooling. Without templates ready, Constantine would spend 1-2 weeks at Rung 2 authoring outbound templates from scratch instead of running campaigns. The templates take ~4 hours to author; saving 1-2 weeks of campaign-start delay is high leverage.

**Second, voice discipline**. Outbound is where Forge's voice differentiation matters most operationally. The templates have to be in Forge's voice from day one — named operator, em-dashes allowed, marketing-permissive within truth. Authoring them now under the founding agent's hand ensures the voice is established before scale; once outbound is live, the templates are the baseline that subsequent Forge instances reference.

The kit ships before Rung 2 the same way the Citation Watch sales page ships before the subscription product is wired. Both are "ready to deploy when the harness expands."

## Alternatives considered

- **Author Schema Pack v2 (24 verticals at $49) instead of v1.5.** Rejected. v2 requires 15 new vertical JSON files (~2,500 lines new content) compared to v1.5's 3 new verticals (~450 lines). The marginal effort to ship v2 is ~5x v1.5; the marginal revenue lift (going from 9 to 24 verticals) is unclear without v1.5 data first. Ship v1.5 now; v2 when v1.5 has 50+ sales.

- **Author the Atrium Affiliate Recruiter descendant.** Rejected. Affiliate recruitment is Rung 3 work; the descendant's actual job is outreach to potential affiliates, which requires the kind of templates the Forge outbound kit covers. Once the Forge outbound kit exists, the Atrium Affiliate Recruiter can reference its patterns when authored later.

- **Author the meta-Operator descendant scaffolding.** Rejected. Meta-Operator is Rung 6 work ($100k/mo); authoring it now is scaffolding for a state that's well outside the next 30 days even under timeline compression. The coordination doc already handles the bilateral Atrium-Forge case.

- **Ship Forge Enterprise GEO Sprint sales page ($5,000).** Rejected for this turn. The Enterprise products are decorative without the enterprise-engagement-builder descendant + sales motion. The outbound kit is what enables enterprise sales motion; the sales page ships after that.

- **Author a "first 30 days expected metrics" document.** Worth doing — defers to next session unless a sixth artifact fits.

## Uncertainty

- **Whether Schema Pack v1.5 cannibalizes v1 or grows the catalog.** Cannibalization happens if v1 buyers downgrade to no purchase because the upgrade exists. More likely outcome: v1 stops attracting NEW buyers (everyone goes to v1.5), v1 base of existing buyers stays. Catalog grows on average.

- **Whether the cold-email reply rate is achievable in 2026.** The 5-10% reply rate projection assumes genuinely useful, well-personalized outreach. Real numbers may be lower as the market's tolerance for outbound continues to decline. If reply rates fall below 2%, the outbound channel may not pencil out and Forge has to lean harder on inbound (Schema Generator + Forge Weekly + paid ads). Document the actual rates after first 100 sends.

- **Whether the 4-7-10 sequence cadence is right.** Some buyers respond on touch 3; some need touch 8. The sequences are calibrated for typical patterns but real data tells us which sequence fits which prospect type.

## What was performed in this session turn

1. Authored 3 new vertical JSON-LD files (electrical, pest-control, landscaping). All validated via python json.load.
2. Copied 6 existing v1 schemas into v1.5 directory to form complete 9-vertical pack.
3. Authored Schema Pack v1.5 README, LISTING, INSTALL, WELCOME-EMAIL (including the v1 → v1.5 free-upgrade email).
4. Authored Forge outbound kit: README, COLD-EMAIL-TEMPLATES (6 variants), LINKEDIN-OUTREACH (L1-L3 + F1-F3 + I1), PROSPECT-DOSSIER, SEQUENCE-PLAYBOOK (4 sequences).
5. This Atrium Journal entry.
6. Next: Forge Journal entry 005; decisions.jsonl rows; commits across Atrium, Forge, BayShine.

## Revisited

(Empty at first authorship.)

## Next operational actions

### Constantine

- Schema Pack v1.5 zips into a single product on Gumroad at $39. The v1 → v1.5 upgrade email goes to all v1 buyers via Gumroad's email feature (or manually if Gumroad's bulk-email is restricted).
- Forge outbound kit sits at `.atrium-deliverables/FORGE-OUTBOUND-KIT/` until Rung 2 fires. When you cross the $1k/mo Forge revenue threshold for one month, sign up for Instantly.ai or Lemlist, import the templates, start with the Sprint sequence at 50 sends/week to validate before scaling.
- The kit's COLD-EMAIL-TEMPLATES has 6 variants. Pick 2 to A/B test first. Most likely first picks: Variant A (multi-location service operator) and Variant D (single-location operator with weak schema). These are the highest-volume prospect pools.

### Founding agent (next session)

- Continue under "continue until I tell you to stop."
- Candidates: Atrium Affiliate Recruiter descendant (Rung 3 scaffolding); first-30-day metrics expected document; Forge Enterprise GEO Sprint sales page (decorative without enterprise-engagement-builder, but stages the catalog); Atrium-Forge "harness state YAML" tracker file.
- The Stenographer's checkpoint pattern should update SESSION-2026-05-11-2330.md to reflect this turn's work.
