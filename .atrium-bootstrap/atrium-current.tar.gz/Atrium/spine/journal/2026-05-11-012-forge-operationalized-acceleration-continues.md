# 012 — Forge operationalized; acceleration continues

date: 2026-05-11
agent_lineage: founding
artifacts (in Forge — the sibling network):
  - .claude/agents/forge-scribe.md
  - .claude/agents/forge-stenographer.md
  - .claude/agents/forge-auditor.md
  - .claude/agents/subscription-product-builder.md
  - .claude/agents/operator-forge-products.md
  - lineage/forge-scribe.yml
  - lineage/forge-stenographer.yml
  - lineage/forge-auditor.yml
  - lineage/subscription-product-builder.yml
  - lineage/operator-forge-products.yml
  - spine/auditor-criteria.md
  - spine/journal/2026-05-11-003-forge-civic-descendants.md
artifacts (in BayShine .atrium-deliverables/FORGE-PRODUCTS/):
  - 02-citation-watch/sales-page.html
  - 02-citation-watch/LISTING.md
  - 03-forge-weekly-001/issue-draft.md
  - 03-forge-weekly-001/PUBLISH-CHECKLIST.md

## Context

Constantine: "Continue until I tell you to stop."

Open-ended directive. I read it as: run cold, run autonomously, find the highest-leverage gap, fix it.

The highest-leverage gap was structural asymmetry between Atrium and Forge. Atrium had 22 descendants — civics, Builders, Operators, specialists, the works. Forge had zero descendants of its own beyond the founding entry. The two-network architecture was lopsided: Atrium operationally functional, Forge constitutionally founded but structurally hollow.

This session brought Forge to operational parity at the civic and first-Builder layer. Forge now has its own scribe, stenographer, auditor (with concrete drift-detection criteria), first Builder (subscription-product-builder), and umbrella Operator (operator-forge-products). Forge also shipped two new customer-facing artifacts that close real funnel gaps.

## Decision

Six artifacts (counting Forge-side):

### 1. Citation Watch sales page

The Schema Generator's upsell modal was pointing to a 404. Anyone clicking "See Citation Watch →" hit nothing. The funnel was broken.

Now Citation Watch has a real waitlist sales page at `BayShine/.atrium-deliverables/FORGE-PRODUCTS/02-citation-watch/sales-page.html`. Single deployable HTML in Forge's brand. $19/mo standard, $14/mo founding-member rate for first 100 subscribers. Real scarcity (100-person cap, not invented urgency).

The page is positioned as "Coming Q3 2026" with the waitlist as the mechanic until subscription infrastructure is wired at Forge Rung 2. The waitlist captures intent, builds audience, and produces a launch wave when the product ships.

### 2. Forge Weekly Issue 1 draft

Forge's newsletter has its first issue draft. Lede on the BayShine 25-site probe study (real data, real numbers: 64%/80%/48%/92% engine coverage; 84% buyer-intent miss rate; 23/25 schema mismatches; 24/25 missing llms.txt). Paid tier from issue 1 with $5/mo founding-member rate for first 100 paid subscribers, $9/mo standard after.

Cross-promotes Schema Generator (primary CTA), Citation Watch waitlist, Atrium products via the sibling-network reference. Written in Forge's voice — em-dashes, Constantine bylined, marketing-permissive within truth.

### 3-5. Forge civic descendants

Three permanent civics authored: forge-scribe, forge-stenographer, forge-auditor. Each with `.claude/agents/<name>.md` agent definition and `lineage/<name>.yml` declaration.

The forge-auditor is the most consequential: it's the antibody that prevents Forge from drifting toward Atrium's discipline. Its criteria are spelled out in `Forge/spine/auditor-criteria.md` — six categories plus an "Atrium-style temptation log" bonus check. Quarterly briefings paired with Atrium's same-quarter briefing for Constantine's joint review.

### 6. Forge's first Builder and umbrella Operator

`subscription-product-builder` ships subscription SaaS (Citation Watch first, Schema Doctor Pro next). Builder pattern matches Atrium's Builders but specialized for subscription mechanics (Stripe Subscriptions, founding-member cap enforcement, customer dashboards, alert systems, per-customer probe pipelines).

`operator-forge-products` is the umbrella Operator for Forge's full catalog while small (Schema Generator, Citation Watch waitlist, Forge Weekly, future products). Spawns per-product operators when any single product earns dedicated attention. Same Growth Clause architecture as Atrium's operators but with Forge's aggressive Atrium-style-behavior-flag check.

### 7. Forge auditor-criteria.md

The criteria document Forge's auditor reads at each quarterly pass. Inversion-aware: drift toward Atrium's voice is flagged as constitutional drift in the wrong direction. Same six-category structure as Atrium's auditor-criteria with content tuned to Forge's identity.

## Reasoning

### Why fix the funnel first

The Schema Generator was shipped last session. Its upsell modal links to Citation Watch. Citation Watch didn't exist. Every user of the Generator who clicked the upsell got a 404. That's the most acutely broken thing in the system; everything else is forward-looking work.

Fixing the funnel turns the Schema Generator from an isolated free tool into an audience-acquisition lever with a real destination. The waitlist mechanic captures intent before the subscription product ships, which is structurally the right cadence for SaaS launches anyway.

### Why bring Forge's civics to parity now

Forge's structural asymmetry was real. A future session that booted cold into Forge would find the constitution, the CHARGE, the harness, the inheritance docs — but no civic descendants to invoke. The Stenographer pattern, the Scribe pattern, the Auditor pattern — Forge had them documented architecturally but not authored as descendants.

Bringing Forge to civic parity makes the next Forge session structurally similar to an Atrium session. The Stenographer bootstrap works. The Scribe can be invoked for journal entries. The Auditor's quarterly review has criteria. The Builder can be invoked for the next subscription product (Schema Doctor Pro). The Operator runs the catalog under its monthly summary discipline.

### Why one Builder and one umbrella Operator instead of more

Forge's catalog has three live (or near-live) revenue surfaces: Schema Generator, Citation Watch waitlist, Forge Weekly. Plus four planned products (Schema Doctor Pro, Enterprise GEO Sprint, Enterprise GEO Program, future Forge subscriptions).

A separate Operator per product right now would be ceremony — the catalog isn't large enough to need that coordination. One umbrella Operator (operator-forge-products) handles the whole catalog and spawns per-product Operators as each earns its own attention via the Growth Clause threshold.

One Builder (subscription-product-builder) covers all subscription products. The enterprise products will get their own Builder (enterprise-engagement-builder) when the first enterprise prospect lands. The growth-marketing-builder and public-content-builder mentioned in CHARGE.md spawn at their respective triggers.

### Why the Citation Watch waitlist over a "Coming Soon" page

A "Coming Soon" page captures nothing. A waitlist page with founding-member pricing captures intent AND a marketing list AND a launch wave.

The founding-member cap (100 lifetime-locked $14/mo subscribers, vs $19/mo standard after) creates real urgency around real scarcity. Buyers who care about Citation Watch enough to join the waitlist before the product ships are the buyers most likely to convert when it does ship. The waitlist is the qualification mechanism.

### Why Forge Weekly Issue 1 ships now

The Schema Generator captures emails into Forge Weekly's free list. If Forge Weekly has no issues, captured emails sit on a list that never sends. That's a broken audience loop.

Shipping Issue 1 now — with real data and paid tier from issue 1 — closes the loop. The Schema Generator captures, Forge Weekly publishes, Issue 1 cross-promotes Schema Generator and Citation Watch waitlist, the funnel compounds.

## Alternatives considered

- **Ship Citation Watch's actual subscription product in this session.** Rejected. Stripe Subscriptions wired, customer dashboard built, alert system live, per-customer probe pipeline operational — all of this is Rung 2 work that requires real production credentials. The waitlist is the correct interim state.

- **Author all five missing Forge civic descendants (scribe, stenographer, governor, scout, auditor) plus operational ones (plumbing, probe, pattern-rollup, citation-probe) plus all the planned Builders (enterprise-engagement, growth-marketing, public-content, subscription-product) plus per-product Operators.** Rejected — that's 12+ agent definitions in one session, exceeding what fits well alongside the customer-facing artifacts. Selected the three most architecturally essential civics, one Builder, one Operator. The rest spawn at their natural triggers.

- **Author Forge's operational descendants first (governor, scout, probe, plumbing).** Rejected. The civic core (scribe, stenographer, auditor) is the discipline; the operational descendants are the execution arm. Operational descendants without the civic core means execution without governance, which is exactly the failure mode Atrium's discipline is designed to prevent. Civics first.

- **Skip the auditor-criteria.md for Forge and rely on Atrium's auditor-criteria.md.** Rejected. The criteria for Forge's auditor must be inverted to detect drift TOWARD Atrium's discipline. Atrium's criteria check the wrong direction for Forge. Independent criteria document is structurally necessary.

- **Defer Forge Weekly Issue 1 to a future session.** Rejected. The Schema Generator email capture is live (or will be when Constantine deploys the HTML). Without an Issue 1, captured emails never receive anything. Issue 1 ships now.

## Uncertainty

- **Whether the waitlist mechanic converts at projected rates.** Citation Watch waitlist conversion is projected at 15-25% of Schema Generator click-throughs. Real data may show 5% or 35%. First 100 waitlist signups give the actual number.

- **Whether Forge Weekly's paid tier from issue 1 strategy works.** Atrium's Cited Weekly defers paid tier to 500 free subs. Forge launches paid from issue 1 with founding-member pricing. The bet: founding-member urgency converts at higher rates on small lists than waiting for free-tier scale would produce. Could be wrong if early subscribers don't trust a brand-new newsletter enough to pay.

- **Whether forge-auditor's criteria are calibrated correctly.** The Atrium-style temptation log is a new check pattern that doesn't have a corollary in Atrium's criteria. First quarterly run reveals whether the check is useful or noise.

- **Whether one umbrella Operator scales.** operator-forge-products covers 3+ products initially, scaling to 6-7 as the catalog grows. At some point the umbrella role becomes unsustainable and per-product operators must spawn. The Growth Clause threshold ($5k/mo per product) is the spawn trigger; whether that's the right number is untested.

## What was performed in this session

1. Authored Citation Watch sales page (single deployable HTML with waitlist mechanic) + LISTING.md with deployment notes and product spec.
2. Authored Forge Weekly Issue 1 draft + PUBLISH-CHECKLIST.md with audience targets and voice rules.
3. Authored forge-scribe agent + lineage YAML.
4. Authored forge-stenographer agent + lineage YAML.
5. Authored forge-auditor agent + lineage YAML.
6. Authored Forge spine/auditor-criteria.md (concrete drift detection framework for Forge auditor).
7. Authored subscription-product-builder agent + lineage YAML.
8. Authored operator-forge-products agent + lineage YAML.
9. Authored Forge Journal entry 003 (in Forge's voice).
10. This Atrium Journal entry (012).
11. Next: decisions.jsonl entries; commit Atrium locally; commit Forge locally; commit and push BayShine deliverables.

Total: 13 new files across Atrium and Forge plus 4 new BayShine deliverable files = 17 new files.

## Revisited

(Empty at first authorship.)

## Next operational actions

### Constantine

- Deploy the Schema Generator HTML to a Forge domain (Vercel + DNS at forge.{{tld}}/generate).
- Deploy the Citation Watch waitlist HTML to forge.{{tld}}/citation-watch.
- Replace the `https://forge.example/citation-watch` placeholder in the Schema Generator's upsell modal once the real URL is live.
- Create Substack publication "Forge Weekly" and queue Issue 1 for Thursday 09:00 Eastern.
- Register Forge domain if not already.
- Read Forge's auditor-criteria.md to confirm the inversion-aware drift detection criteria match your intent for Forge's discipline.

### Founding agent (this Atrium instance)

- Continue under "continue until I tell you to stop" until that stop signal arrives.
- Next highest-leverage gap: Atrium's Schema Pack v2 (24 verticals at $49) — currently deferred pending demand probe, but under timeline compression may be the right next ship. OR Atrium's Affiliate Recruiter descendant which was deferred to Rung 3 but may be needed earlier. OR an Atrium GEO Playbook v1 expansion. Or the second Forge product (Schema Doctor Pro sales page so the upsell modal there has somewhere to point eventually).
- Working memory checkpoint discipline: update SESSION-2026-05-11-2330.md to reflect this session turn's threads, decisions, alternatives, and timeline.

### Future Forge instance (next cold boot)

- Bootstrap a Forge working memory at session start (forge-stenographer pattern).
- Read Forge journal entries 001-003 in order.
- Run forge-scribe to author any new journal entries this session needs.
- Check operator-forge-products' weekly cadence: is it Wednesday? Pull metrics and respond to support backlog if so.
- Continue Forge's catalog: Schema Doctor Pro sales page is the next subscription waitlist if Citation Watch waitlist has momentum.
