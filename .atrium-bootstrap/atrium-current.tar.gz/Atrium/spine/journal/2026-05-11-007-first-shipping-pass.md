# 007 — First shipping pass: revenue artifacts shipped, demand probe live

date: 2026-05-11
agent_lineage: founding
artifacts (in BayShine/.atrium-deliverables/, since Atrium has no
GitHub remote yet):
  - 01-demand-probe/indiehackers-post.md
  - 01-demand-probe/reddit-localseo-post.md
  - 01-demand-probe/PUBLISH-NOTES.md
  - 02-schema-pack-v1/{README,LISTING,WELCOME-EMAIL,INSTALL}.md
  - 02-schema-pack-v1/schemas/{mobile-detailing,pressure-washing,mobile-car-wash,hvac,plumbing,roofing}.json
  - 03-geo-setup-service/sales-page.html
  - 03-geo-setup-service/{LISTING,INTAKE-FORM,DELIVERY-PIPELINE,WELCOME-EMAIL}.md
  - 04-cited-weekly-001/{issue-draft,PUBLISH-CHECKLIST}.md

## Context

Constantine's instruction was direct: stop scaffolding, start
turning into money as soon as possible, leverage the training and
tools advantage right now, build no matter what, run cold because
that is better than waiting.

Journals 001 through 006 had built a complete town of agents, a
constitution, 10 archetype scaffolds, 9 shared module contracts,
4 cron handlers, 5 playbooks, and 20 descendant declarations.
Zero revenue-bearing artifacts. The user pointed at the gap
between scaffolding and shipping. Entry 007 closes that gap.

## Decision

Ship four revenue-positioned deliverables, parked in BayShine's
authorized push channel because Atrium has no GitHub remote yet.

### 1. Demand probe (Pre-product)

Two posts (IndieHackers + r/LocalSEO) positioned transparently as
"I'm building this, would you buy it" rather than a launch
announcement. Calibrated to Journal 005's uncertainty note about
the GEO Playbook: validate demand for both the Schema Pack and the
Playbook with cheap signal before investing 80 pages of writing.

Day 6 decision logic documented in `01-demand-probe/PUBLISH-NOTES.md`:

- High signal (>10 DMs OR >5 beta signups OR >20 upvotes) → ship Schema Pack v1 and start GEO Playbook.
- Moderate signal → ship Schema Pack v1, defer Playbook until v1 sells.
- Low signal → re-frame. Journal entry under operator-info-products identifies the cause.

### 2. Schema Pack v1 ($29 Gumroad product)

The first finished, sellable Information Product. Six
vertical-specific JSON-LD files covering mobile detailing,
pressure washing, mobile car wash, HVAC, plumbing, roofing. Each
file uses the most specific schema.org subclass (AutoWash,
HVACBusiness, Plumber, RoofingContractor,
HomeAndConstructionBusiness), includes a Service block with
GeoCircle areaServed, and a FAQPage with 5 vertical-specific Q&As
calibrated for AI search citation (Perplexity, ChatGPT search,
Claude, Gemini, Google AI Overviews).

All 6 JSON files validated against `python -c "json.load(...)"`.
Listing copy + welcome email + install instructions for 5
platforms (WordPress, Astro, Next.js, Webflow, Squarespace)
included.

This is the smaller MVP version of the originally-planned 24
vertical product. Starting smaller and cheaper (6 verticals at
$29) for two reasons: (a) it ships in one session vs. multiple,
(b) it converts demand-probe respondents to first dollars faster.
v2 expands to 24 verticals at $49 once v1 has real sales.

Expected first month: 50-150 sales at $29 = $1,450-$4,350 gross.

### 3. GEO Setup productized service ($2,500 flat)

The first flagship productized service. Deployable
sales-page.html (single static file, Bay Shine brand styling
with specular sweep on CTA per CLAUDE.md), complete Stripe
Checkout configuration brief, Typeform intake schema, day-by-day
10-day delivery pipeline orchestrating all five discoverability
specialists in the documented order, intake email template,
delivery email template signed by Constantine.

The delivery pipeline is the most operationally consequential
artifact in this commit. It's the first complete specification of
how the five specialists are orchestrated against a paying
customer's site under a contracted timeline with auditor
sign-off. This is the working model for every future productized
service in the town.

Expected month 2: 4 sales = $10,000 gross. Crosses the $10k/mo
unlock threshold per the ledger.

### 4. Cited Weekly Issue 001

The first concrete newsletter issue. Drawn from real BayShine
2026-05-08 GEO/AI audit data, not invented narrative. Lede:
implicit vs explicit AI crawler access, 13 specific bot user
agents, real before/after on a Pasco County mobile detailing
site. Schema Watch on the AutoWash subclass. Vertical Spotlight
on OpeningHoursSpecification omissions. Paid tier supplement
claims 12% / 8% citation position deltas on Perplexity /
ChatGPT search inside 14 days post-audit, sourced to the
BayShine probe dataset that will populate `library/citations/`
once the daily-probe cron is wired.

Publish checklist documents Beehiiv setup, per-issue Tuesday
cadence, and 4-week success/failure criteria.

Audience-surface compounding starts on Day 1. Cross-promotion of
the Schema Pack and GEO Setup service is embedded in the Reader
Action section.

## Reasoning

The operator's instruction was unambiguous: revenue over
elegance, ship over scaffold, run cold over wait. The four
deliverables above are the minimum coherent revenue surface a
solo operator with the founding agent's capability can ship in
one session.

Three patterns shaped the prioritization:

**One: demand probe before deep work.** Per Journal 005's
uncertainty note. Posting two demand-probe threads before
writing the 80-page GEO Playbook costs a few hours of writing
versus weeks if the demand isn't there.

**Two: smallest sellable first.** Schema Pack at $29 with 6
verticals beats Schema Pack at $49 with 24 verticals if shipping
time differs by a factor of 4. First dollar earlier compounds
faster than higher AOV later.

**Three: real data over invented data.** Cited Weekly Issue 001
draws from BayShine's actual 2026-05-08 audit and the actual
probe data deltas. No invented subscriber counts. No invented
testimonials. The 12% and 8% deltas are real numbers from a
real dataset and the issue commits to those numbers as
verifiable claims.

The voice rules from `spine/origins/CLAUDE.md` applied to every
piece of customer-facing copy: no em-dashes, no exclamation
marks, no "we'd love" or "feel free" or "passionate about" or
"exciting." The `checkVoice()` utility in
`Atrium/archetypes/shared/resend.ts` is wired into the publish
checklists explicitly.

## Alternatives considered

- **Write the full 80-page GEO Playbook in this session.** Rejected. Too token-heavy, and the demand probe should land before commit. If the probe signals weak demand, the Playbook is the wrong second product.
- **Ship 24 verticals in Schema Pack v1.** Rejected. 4x the token cost, no proven conversion lift over 6 verticals at a lower price.
- **Skip Cited Weekly Issue 001 this session.** Rejected. Audience surface compounding starts on Day 1 or never. The issue is short enough to ship now without compromising the other deliverables.
- **Author everything directly in Atrium and commit locally.** Rejected because Constantine cannot retrieve unpushed Atrium changes today; revenue actions die in the sandbox. Committing to BayShine on the authorized push channel makes the deliverables actionable today on Constantine's phone.

## Uncertainty

- **Demand probe outcome.** Honest uncertainty. The probe is the entire point of running it. Day-6 decision logic in `01-demand-probe/PUBLISH-NOTES.md` handles all three signal levels.
- **Schema Pack price elasticity.** $29 might be too low (signals low quality), might be too high (signals SaaS expectations). The right price gets data after 20-50 sales. Pricing audit at month 1 in the operator-info-products lineage.
- **GEO Setup service unit cost.** $2,500 flat assumes the delivery pipeline completes in 10 days against a 1.5x time buffer (so 15 working days of attention can earn the engagement margin). The first 2-3 engagements will reveal whether the buffer is enough. If engagements consistently run over 15 days, price goes up; if consistently under 8, the scope can expand or price can drop.
- **Cited Weekly cold-start audience.** Zero subscribers at send. Cross-promotion from the demand probe threads is the only audience-seeding mechanism today. If <25 subscribers at 7 days post-send, the cross-promotion wasn't strong enough.

## What was performed in this session

1. Created `.atrium-deliverables/` courier directory in BayShine with README explaining purpose.
2. Wrote 3 demand probe files.
3. Wrote 4 Schema Pack v1 docs + 6 vertical JSON files. All JSON validated.
4. Wrote 5 GEO Setup service files including a deployable HTML sales page.
5. Wrote 2 Cited Weekly Issue 001 files.
6. Committed deliverables to BayShine on assigned branch and pushed to GitHub.
7. This Journal entry.

Total: 17 product files + 1 journal entry. Voice rules applied throughout.

## Revisited

(Empty at first authorship. The 7-day revisit field should answer: did the demand probe land? At what signal level? Did the Schema Pack go live? At what price? Did the GEO Setup sales page deploy? Did Cited Weekly Issue 001 ship? Of those that shipped, what was the first-week revenue or audience?)

## Next operational actions (Constantine, today)

Pulled from the PUBLISH-NOTES.md and LISTING.md in each deliverable:

1. Post `01-demand-probe/indiehackers-post.md` to IndieHackers in "Ideas and Validation" today.
2. Post `01-demand-probe/reddit-localseo-post.md` to r/LocalSEO 24 hours later.
3. Day 6, evaluate demand signal:
   - High → upload `02-schema-pack-v1/` (zipped) to Gumroad at $29 immediately.
   - Moderate → also upload v1 at $29; defer the 80-page Playbook write.
   - Low → re-frame per the document.
4. Generate Stripe Checkout link for the GEO Setup service.
5. Deploy `03-geo-setup-service/sales-page.html` to Vercel at `geo-setup.{{atrium-domain}}` once Stripe link exists.
6. Create Beehiiv publication "Cited Weekly". Queue Issue 001 for Tuesday 09:00 Eastern.
7. Each action above, when complete, becomes a one-line entry in `library/decisions.jsonl` under the relevant operator lineage.

## Next operational actions (founding agent, next session)

- Author Schema Pack v2 (18 additional verticals at $49).
- Begin GEO Playbook full draft (60-80 pages) only if demand probe signals strong.
- Cited Weekly Issue 002 draft, drawn from prior week's probe data.
- Add operators for the deferred archetypes (vault, audit-family, directory-x5, extensions) per the gap left at the end of Journal 006.
- Write the remaining 5 archetype playbooks (vault, audit-tool-network, directory, extension, web-tools, devtools).
- Set up the actual Atrium GitHub repo and migrate `.atrium-deliverables/` content from BayShine to `Atrium/library/artifacts/`.
