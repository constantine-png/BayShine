# 013 — GO-LIVE master + Forge's second subscription waitlist

date: 2026-05-11
agent_lineage: founding
artifacts:
  - BayShine/.atrium-deliverables/GO-LIVE-MASTER.md (new; the operational playbook)
  - BayShine/.atrium-deliverables/FORGE-PRODUCTS/04-schema-doctor-pro/sales-page.html (new)
  - BayShine/.atrium-deliverables/FORGE-PRODUCTS/04-schema-doctor-pro/LISTING.md (new)

## Context

Constantine: "Continue until I tell you to stop."

Continuing. After Atrium Journal 012 and Forge Journal 003 brought Forge to civic + first-Builder structural parity, the highest-leverage gap I could identify was operational execution velocity. Constantine has eight revenue-bearing artifacts across two networks. The conversion of "artifacts on disk" to "revenue in account" depends on Constantine's execution cadence.

The friction items:

- Per-product LISTING.md files describe what each product is and how to deploy it, but no single execution playbook synthesizes the action sequence across all 8 products.
- The LAUNCH-SEQUENCE.md document covers launch posts but not the prerequisite setup (domain registration, Stripe/Gumroad/Beehiiv/Substack accounts, sales page deployment).
- Two networks compound the friction: Atrium and Forge each need their own setup, but the dependencies between them aren't enumerated.

I authored GO-LIVE-MASTER.md to address this. Plus I shipped Forge's second subscription waitlist (Schema Doctor Pro at $99/mo) to validate that the waitlist pattern repeats — the second subscription product going live proves the first wasn't a one-off.

## Decision

Two artifacts:

### 1. GO-LIVE-MASTER.md

A single-file execution playbook at the root of `.atrium-deliverables/`. Synthesizes everything across both networks into a Day 1-14 calendar:

- **Day 1 (90 min):** Account setup across both networks (Atrium domain + Forge domain + Stripe sub-accounts + Gumroad + Beehiiv + Substack + Vercel).
- **Day 2 (60 min):** Deploy sales pages — Atrium GEO Setup, Atrium AI Citation Audit, Forge Schema Generator, Forge Citation Watch, Forge Schema Doctor Pro.
- **Day 3 (45 min):** Stripe Checkout configuration for productized services.
- **Day 4 (60 min):** Gumroad uploads for Atrium info products.
- **Day 5 (45 min):** Beehiiv and Substack queue.
- **Day 6 (30 min):** Demand probe posts (IndieHackers, r/LocalSEO).
- **Day 7-12:** Monitor and respond using SUPPORT directory.
- **Day 13:** First launch from LAUNCH-SEQUENCE.md.
- **Day 14:** Newsletter issues publish.

Total active time: 8-12 hours over 14 days.

The document includes a troubleshooting table, coordination notes for two-network operation, and a "where each artifact lives in the long term" section pointing to the canonical locations after PC migration.

### 2. Schema Doctor Pro waitlist sales page

Forge's second subscription product. $99/mo standard with founding-member rate locked at $79/mo for first 50 subscribers (smaller cap than Citation Watch's 100 because the higher price point makes 50 a more meaningful cohort).

The sales page differentiates Schema Doctor Pro from Citation Watch:

- **Citation Watch** = observation. Probes AI engines, alerts on citation drops.
- **Schema Doctor Pro** = intervention. Auto-generates schema on new pages, validates pre-deploy, detects drift, multi-domain support.

The buyer profiles are different: Citation Watch sells to single-domain operators; Schema Doctor Pro sells to developers and agency operators who treat schema as code. The compare block on the page sets up a future bundle (both at $99/mo, saving $19 vs unbundled $118) to upsell Citation Watch founding members.

The sales page is in Forge's voice — em-dashes, named Constantine in footer, direct "Choose X if..." framing in the compare block.

## Reasoning

### Why the GO-LIVE master playbook now

Constantine has shipped nothing customer-facing yet despite 11 journal entries of preparation. That's not a critique — it's an honest observation about the difference between architectural readiness and operational launch. The GO-LIVE master removes the cognitive load of "where do I start" by giving him a single document with day-by-day actions and time estimates.

The marginal effort to author it (~400 lines) is small relative to the marginal acceleration it produces. If the master cuts Constantine's first-launch friction by 50%, every product behind it ships sooner, and revenue compounds sooner.

This is the execution-accelerator pattern I should be using more aggressively under timeline compression. Less architecting; more enabling.

### Why Schema Doctor Pro waitlist before Schema Pack v1.5 or other Atrium expansions

Two reasons. First, Forge needs to demonstrate that its subscription model can carry a second product, not just Citation Watch. A second waitlist with founding-member mechanic confirms the pattern works for multiple products. Second, the Schema Generator's traffic naturally flows to BOTH Citation Watch (for monitoring) and Schema Doctor Pro (for development workflow integration); having both destinations available means the funnel converts to whichever fits the visitor's profile.

Atrium's Schema Pack v1.5 (adding 3 verticals to match the Schema Generator) is a marginal upgrade that can wait. Forge's second subscription is the structural beat that demonstrates the subscription catalog has shape, not just a flagship.

### Why $99/mo for Schema Doctor Pro vs Citation Watch's $19/mo

Different scopes. Citation Watch is observational; the per-customer cost is moderate (AI engine probe budget). Schema Doctor Pro is interventional with CMS integrations and build-pipeline hooks; the per-customer cost is higher (engineering complexity, multi-domain support, agency dashboards).

The $99/mo price also signals to the buyer: this is for operators who treat schema as code, not casual users. The Schema Generator (free) handles casual users; Citation Watch ($19/mo) handles single-domain serious users; Schema Doctor Pro ($99/mo) handles developers and agencies. Three tiers, clear differentiation.

Founding-member math: 50 founders × $79/mo = $3,950/mo MRR from founding cohort once it fills. Plus the bundle upsell to Citation Watch founders takes some of them to $99/mo bundle, growing per-customer LTV materially.

## Alternatives considered

- **Author the Atrium Schema Pack v2 (24 verticals at $49) instead.** Rejected for this turn — Forge's catalog structural validation (second subscription) is higher leverage than Atrium catalog expansion. Schema Pack v2 ships when v1 has buyers OR when timeline compression dictates.

- **Author the Atrium Affiliate Recruiter descendant.** Rejected for this turn. Affiliate recruitment is Rung 2-3 work; the marginal benefit of authoring the descendant before any product has 25+ direct sales is low. The descendant ships when the trigger fires.

- **Ship Forge's Enterprise GEO Sprint sales page ($5,000).** Rejected for this turn. Enterprise sales motion requires personnel (Constantine or a dedicated enterprise-sales-specialist that hasn't shipped yet); the sales page without a sales motion is decorative. The Sprint waits for the first enterprise prospect identification + the enterprise-engagement-builder descendant + Forge's paid-acquisition harness unlock.

- **Author paid-acquisition-specialist descendant.** Rejected for this turn. Paid acquisition is Rung 2 for Forge; the descendant's actual job (running Google Ads, Meta Ads, LinkedIn Ads at scale) requires real ad accounts that don't exist yet. Authoring the role definition without the harness scope to use it is premature.

- **Skip the GO-LIVE master and continue with more product authoring.** Rejected because Constantine's execution velocity is the bottleneck on every product I author. Without the master playbook, each product shipped is just another item in the queue. With the master, the queue becomes a calendar.

## Uncertainty

- **Whether 14 days is the right calendar for the GO-LIVE master.** Could be faster (one weekend if Constantine batches) or slower (3-4 weeks if responsibilities outside this project compete for time). The 14-day calendar is the median realistic case; the document doesn't lock to that calendar — Constantine can compress or extend.

- **Whether Schema Doctor Pro at $99/mo will find buyers without sales motion.** Citation Watch at $19/mo is more of an impulse subscription; Schema Doctor Pro at $99/mo is a considered subscription. Marketing copy quality matters more. Waitlist conversion rates may be lower than Citation Watch's projected 15-25%.

- **Whether the founding-member 50 cap is too small.** Citation Watch's cap is 100 at $14/mo locked. Schema Doctor Pro's cap is 50 at $79/mo locked. The smaller cap creates more urgency per slot, but the absolute revenue from a 50-person cohort ($3,950 MRR) is meaningfully smaller than what 100 founders would generate.

- **Whether the bundle mechanic ($99/mo for both Citation Watch + Schema Doctor Pro) will cannibalize Citation Watch standalone subscriptions.** Possibly. The bundle saves $19/mo and includes both products; some Citation Watch standalone customers would upgrade to the bundle and the marginal revenue is $80/mo (vs $19/mo single-product churn risk to the bundle). On net positive.

## What was performed in this session turn

1. Authored `BayShine/.atrium-deliverables/GO-LIVE-MASTER.md` (~400 lines, day-by-day execution playbook).
2. Authored Schema Doctor Pro sales page (deployable HTML, $99/mo waitlist with $79/mo founding-50 mechanic) and LISTING.md.
3. This Journal entry.
4. Next: decisions.jsonl entries; Forge Journal 004; commits across all three repos.

## Revisited

(Empty at first authorship.)

## Next operational actions

### Constantine

- Read `BayShine/.atrium-deliverables/GO-LIVE-MASTER.md` end-to-end. Confirm the 14-day calendar fits available time. If shorter compressed cadence is preferred, the actions are sequential but the time estimates are independent — many steps can be done in batches.
- Schema Doctor Pro waitlist deploys alongside Citation Watch waitlist (same Vercel project, different path).
- The GO-LIVE master is the single document to bookmark for execution. The per-product LISTING.md files become reference depth when specific products need fresh detail.

### Founding agent (this Atrium instance)

- Continue under "continue until I tell you to stop." Next leverage candidates:
  - Atrium Schema Pack v1.5 (add 3 verticals to match Schema Generator's coverage). Small but useful.
  - Atrium GEO Playbook v1.0 expansion (24 vertical templates added to v0.5). Larger commitment.
  - Forge Enterprise GEO Sprint sales page (decorative without sales motion but stages the catalog).
  - Atrium Affiliate Recruiter descendant (Rung 3 scaffolding, premature but useful).
  - Atrium-Forge meta-Operator descendant (Rung 6 scaffolding, very premature).
  - Cross-network: A "first-30-day metrics expected" document showing what real numbers look like at each milestone.
- Working-memory checkpoint: update SESSION-2026-05-11-2330.md to reflect this session turn.
