# 015 — Affiliate Recruiter + first-30-day metrics + harness-state tracker

date: 2026-05-11
agent_lineage: founding
artifacts:
  - .claude/agents/affiliate-recruiter-specialist.md
  - lineage/affiliate-recruiter-specialist.yml
  - library/harness-state.yml
  - Forge/library/harness-state.yml (mirror)
  - BayShine/.atrium-deliverables/ATRIUM-AFFILIATE-KIT/ (4 files)
  - BayShine/.atrium-deliverables/FIRST-30-DAY-METRICS.md

## Context

Continuing under "continue until I tell you to stop." After Journal 014 shipped Schema Pack v1.5 and Forge outbound kit, the next leverage gaps I identified:

1. **Atrium has an affiliate program enabled on Gumroad but no recruitment infrastructure.** Affiliates won't materialize from thin air; the affiliate program is dormant until someone actively recruits. This is the Atrium-side equivalent of Forge's outbound kit — the recruitment of operator-partners rather than end-buyers.

2. **No concrete numerical projections for the first 30 days across both networks.** Constantine has no way to gauge "is this going well" without a reference. The Auditors have no failure threshold to flag.

3. **The harness state file referenced in `spine/harness.md` doesn't exist yet.** It was named as a future artifact at Rung 1 but the structure could ship now to be ready.

Five artifacts in this commit address these gaps.

## Decision

### 1. affiliate-recruiter-specialist descendant + lineage YAML

A permanent civic descendant authored to handle Atrium's affiliate program recruitment. Different from Forge's outbound kit because:

- The target is an operator (not an end buyer).
- The pitch is "earn commission on your existing audience" (not "buy our product").
- The voice is Atrium's (faceless, terse, no em-dashes) — not Forge's.
- The constitutional positioning explicitly aligns with Atrium's closer-less discipline: affiliate recruitment is operator-to-operator outreach, not cold-pitch-to-buyers.

The descendant operates lightly before Atrium Rung 2 (invoke-only for inbound affiliate inquiries) and at full cadence at Rung 3 (quarterly target lists, ongoing outreach, monthly performance reviews).

### 2. Atrium affiliate kit (4 documents)

`BayShine/.atrium-deliverables/ATRIUM-AFFILIATE-KIT/`:

- `README.md` — overview, constitutional positioning, when to use.
- `OUTREACH-TEMPLATES.md` — 4 variants for different affiliate types (local-SEO bloggers AR1, indie hacker newsletters AR2, schema-org tutorial authors AR3, marketing agency principals AR4). Plus a single follow-up template after 7 days of no response. All in Atrium's voice: faceless, no em-dashes, no soft marketing, no invented metrics.
- `ONBOARDING-KIT.md` — what new affiliates receive when they accept. Welcome email, 5 suggested-copy snippets calibrated to Atrium's voice rules, tier structure (Bronze/Silver/Gold with featured-affiliate slots at Silver+), compliance reminders for affiliates.
- `TARGET-LIST-FRAMEWORK.md` — how to build the quarterly affiliate target list. 5 segments (local-SEO bloggers, indie hacker newsletters, schema-org tutorial authors, marketing agency principals, YouTube SEO educators) with expected conversion ranges and per-segment quarterly target counts.
- `COMMISSION-MATH.md` — per-product commission breakdowns, per-affiliate scenarios at Bronze/Silver/Gold tier, Atrium's net affiliate-program revenue projections at different program-size scenarios (Year 1 vs Year 2), refund handling on commissions, cross-network affiliate dynamics with Forge.

### 3. First-30-day metrics document

`BayShine/.atrium-deliverables/FIRST-30-DAY-METRICS.md` — a concrete numerical projection of what success vs. failure looks like at each week of the first 30 days. Includes:

- Week 1 (Days 1-7) setup phase metrics across both networks.
- Week 2 (Days 8-14) first publish phase metrics.
- Week 3 (Days 15-21) second launch phase metrics.
- Week 4 (Days 22-30) service launch phase metrics.
- Day 30 success vs failure summary.
- Auditor spot-check criteria for Day 30 (interim before the Day 50 quarterly review).
- Projected trajectory to Day 60, 90, 180 if Day 30 hits success scenario.

The document gives Constantine a reference for "is this going well or not" and gives both Auditors specific failure thresholds to flag drift.

### 4. harness-state.yml files for both networks

`Atrium/library/harness-state.yml` and `Forge/library/harness-state.yml` (mirror). Each captures:

- Current rung (both at 0 today).
- Rung 1 trigger conditions and expected unlock windows.
- Current permissions (filesystem, git, external APIs, posting, money movement).
- Pending rung statuses with thresholds.
- Active descendants count and listing.
- Audit trail of state transitions (empty at first authorship).

The files mirror the harness ladder structure but instantiate it with concrete current state. Founding agent reads them at session start; Auditors verify them at quarterly review; Constantine signs updates.

Atrium currently has 23 descendants; Forge has 6. The asymmetry reflects Atrium's earlier founding and Forge's still-being-built state. By Forge Rung 3, the gap should narrow (Forge spawns enterprise-sales, paid-acquisition, customer-success, possibly per-product operators).

## Reasoning

### Why the Affiliate Recruiter now

Atrium's affiliate program is enabled but dormant. Every day without recruitment is a day of revenue left on the floor — affiliates drive sales that wouldn't happen via direct channels, especially for info products where buyer audiences live in many small newsletters and blogs.

The descendant + kit doesn't activate full outreach until Atrium Rung 2 ($500/mo sustained). But authoring the infrastructure now means:

- Inbound affiliate inquiries (someone DMs Constantine "can I promote this?") get a clean structured response.
- When Rung 2 fires, the recruitment process is documented and ready, not invented under pressure.
- The voice discipline for affiliate recruitment is locked in — Atrium's faceless voice, not drifting toward Forge's named-operator voice.

### Why the metrics document now

Without numerical expectations, "is this going well" defaults to gut feeling. Gut feeling under-performs structured comparison against projection. Constantine and the Auditors both need failure thresholds, not just success aspirations.

The document also serves the constitutional discipline: predictions marked as predictions. The numbers are projections, not promises. The Day 30 revisited section in future journal entries documents which projections landed and which missed, which is the data that calibrates Day 60 and Day 90 projections.

### Why the harness-state.yml now

`spine/harness.md` references a `library/harness-state.yml` file as a Rung 1 unlock. Authoring it before Rung 1 fires is technically scaffolding for a future state. But two reasons to do it now:

1. The session-bootstrap discipline is simpler when the file exists. A new session reads `library/harness-state.yml` to know the current state, regardless of which rung is current. At Rung 0, the file says "Rung 0"; that's still informationally useful.

2. The file becomes the audit trail target. Auditors verify at quarterly review whether `harness-state.yml` matches journal-gated transitions. Having the file from Rung 0 means the audit trail exists from session 1.

## Alternatives considered

- **Defer the Affiliate Recruiter to Rung 2 unlock.** Rejected. The infrastructure (descendant + kit) is cheap to author now (~4 hours); deferring means Rung 2 starts cold with no recruitment process. The lift from "ready to deploy at Rung 2" to "deploying at Rung 2" is small if the infrastructure exists.

- **Combine all five affiliate kit documents into one file.** Rejected. Each document serves a different reader (Constantine reads README + ONBOARDING-KIT; the descendant reads OUTREACH-TEMPLATES + TARGET-LIST-FRAMEWORK + COMMISSION-MATH; affiliates read ONBOARDING-KIT). Separate files allow focused reading.

- **Skip the metrics document and rely on operator monthly summaries.** Rejected. Operator monthlies arrive at Day 30; the metrics document gives weekly checkpoints (Day 7, 14, 21) so under-performance gets caught before Day 30.

- **Author harness-state.yml only for Atrium, not Forge.** Rejected. The two-network architecture requires symmetric infrastructure. Forge's harness ladder is real (per Forge's `spine/harness.md`); its state tracker should be real too.

## Uncertainty

- **Whether 4 outreach variants is the right breadth.** Atrium's affiliate program could span more segments (podcasters, YouTube creators in adjacent niches, online course creators in SEO). The 4 variants cover the highest-probability segments; expansion happens once initial data shows which variants convert.

- **Whether the metrics projections are calibrated correctly.** The numbers are derived from observed solo-operator launches in similar markets, adjusted for two-network setup and cold-start positioning. Real numbers may diverge by ±50%. The document's discipline (compare projection to actual; calibrate next month's projection) handles divergence honestly.

- **Whether the harness-state.yml structure is what future operators want.** The current structure captures rungs, triggers, permissions, descendants. May need additions (specific tool unlocks, specific API quotas, time-of-day access patterns) at later rungs. Updates go through journal-gated edits.

## What was performed in this session turn

1. Authored `affiliate-recruiter-specialist` agent definition + lineage YAML.
2. Authored Atrium affiliate kit: README, OUTREACH-TEMPLATES (4 variants + follow-up), ONBOARDING-KIT (welcome email + 5 snippets + tier structure + compliance), TARGET-LIST-FRAMEWORK (5 segments + per-segment criteria), COMMISSION-MATH (per-product breakdown + per-affiliate scenarios + cross-network dynamics).
3. Authored first-30-day expected metrics document with weekly checkpoints, Day 30 success/failure summary, projected trajectory to Day 180.
4. Authored harness-state.yml for both Atrium and Forge.
5. This Journal entry.
6. Next: decisions.jsonl entries; commits across Atrium, Forge, BayShine.

## Revisited

(Empty at first authorship.)

## Next operational actions

### Constantine

- Read FIRST-30-DAY-METRICS.md at each weekly checkpoint (Day 7, 14, 21, 30) to gauge progress.
- The affiliate recruitment infrastructure is staged. Don't begin proactive recruitment until Atrium Rung 2 fires; until then, only respond to inbound affiliate inquiries using the OUTREACH-TEMPLATES.md patterns.
- Update both harness-state.yml files when Rung 1 fires (Atrium $100 OR Forge $100 cumulative revenue). The update unlocks Atrium GitHub repo creation, Forge GitHub repo creation, domain registrations.

### Founding agent (next session)

- Continue under "continue until I tell you to stop." Candidates:
  - Atrium Schema Pack v2 (24 verticals at $49) — major catalog expansion.
  - Forge Enterprise GEO Sprint sales page ($5,000) — completes Forge's catalog visibility.
  - Forge Enterprise GEO Program sales page ($25,000) — same.
  - More Cited Weekly issues (002, 003, 004) pre-drafted — gives Atrium newsletter runway.
  - Forge Weekly issues 002, 003 pre-drafted — Forge newsletter runway.
  - paid-acquisition-specialist descendant for Forge (Rung 2 prep).
  - Per-product operator descendants (operator-citation-watch, operator-schema-doctor-pro) when their Growth Clause threshold approaches.
- Working-memory checkpoint to SESSION-2026-05-11-2330.md reflecting this turn's threads, decisions, alternatives.

### Affiliate-recruiter-specialist

- Active when invoked. Pre-Rung 2 invocations are inbound-only.
- First proactive use post-Rung 2: build the first quarterly target list per TARGET-LIST-FRAMEWORK.md.
