# Atrium-Forge coordination

Operational layer beyond `inheritance.md`. Where inheritance.md documents WHAT is shared between Atrium and Forge structurally, this document describes HOW the two networks coordinate operationally — the cadence of joint decisions, the specific arbitration rules, and the architecture that supports N>2 networks if a third (or fourth) sibling is founded.

## Why this document exists separately from inheritance.md

inheritance.md was written at Forge's founding and answered: what's shared, what's separate, how do conflicts resolve at the principle level. This document is the operational manual: who does what at what cadence, what the specific touchpoints are, and what the architecture looks like if a third sibling network spawns.

The two documents are mirror-symmetric across the networks. `Atrium/spine/coordination.md` and `Forge/spine/coordination.md` are kept in sync. When this file changes, the change is replicated in both networks within 24 hours, and the change is journaled in both networks' lineages.

## The shared operator (Constantine)

Constantine is the only human in both networks. His role:

- **Legal shield** for both Atrium and Forge under the same entity (Stripe sub-accounts separate; tax filings combined; bank account shared with internal accounting separation).
- **Signature authority** on anything that moves money or signs contracts in either network.
- **Operator face** for Forge (named publicly per Forge's named-founder discipline). Faceless for Atrium per Atrium's faceless-brand discipline. This means Constantine's public surface (LinkedIn, X, podcast appearances) is associated with Forge specifically; Atrium operates under its brand name without Constantine's face.
- **Quarterly review** of both networks jointly. Single 1-2 hour review session per quarter covering both Auditors' briefings.
- **Weekly touchpoints**: rotates between the networks. Week 1 Atrium; week 2 Forge; week 3 Atrium; week 4 Forge. If either network has an emergency (escalation), Constantine breaks the rotation to handle it.
- **Daily** is only emergencies: refunds outside policy, legal escalations, threatening buyer messages, platform deplatforming.

## The shared discoverability specialists

Five specialists shared across both networks: schema-specialist, site-architecture-specialist, geo-ai-search-specialist, internal-linking-specialist, citation-readiness-specialist. The dual-voice calibration:

**Voice parameter at invocation.** Each specialist's invocation includes a `voice` parameter set to either `atrium` or `forge`. The specialist applies the corresponding voice rules:

- `voice: atrium` — terse, faceless, no em-dashes, no exclamation marks, no soft marketing.
- `voice: forge` — bolder, em-dashes welcome, named operator references allowed, marketing-permissive within truth.

**Calendar coordination.** Specialists are time-bounded; when both networks want the same specialist in the same week, scheduling rules apply:

- Default: FIFO. Whichever network's Operator booked the specialist first gets the slot.
- Priority retainer override: either network can buy a priority retainer (separate budget) that guarantees specialist availability within 24 hours, bumping the FIFO queue.
- Emergency override: any engagement at $1,500+ in either network gets priority over engagements under that threshold. This is the quality-bar discipline applied across the calendar.

**Voice audit per engagement.** Each network's Auditor reviews a sample of specialist outputs per quarter (at least 3 engagements per specialist per quarter) to verify the voice calibration held. Sustained drift toward one network's voice is flagged as a constitutional drift.

## Weekly cadence

What happens every week, on a fixed schedule:

### Monday (Atrium operators)

- operator-info-products reviews last week's sales and refunds.
- operator-productized-services reviews active engagements and pipeline.
- operator-newsletter pulls citation deltas for the upcoming issue.
- Cross-network: no joint action.

### Tuesday

- Cited Weekly publishes (Atrium).
- Forge Weekly publishes (Forge), if it has issues queued. Note: Forge Weekly might launch on a different cadence (Thursday or Saturday) to avoid same-day competition with Cited Weekly; the Forge operator-forge-weekly decides.
- Cross-network: each newsletter's issue may cross-mention the other if there's a substantive reason.

### Wednesday (Forge operators)

- operator-citation-watch reviews subscription health (churn, expansion, support).
- operator-schema-doctor-pro reviews same for that subscription.
- operator-enterprise-engagements reviews active engagements and pipeline.
- Cross-network: no joint action.

### Thursday

- Launch Specialist (each network has one) checks if a launch is staged.
- Discoverability specialists handle the specialist work queue.
- Cross-network: shared specialists' calendars resolve any conflicts.

### Friday

- Customer Support Specialists (each network has one; both report to Constantine) close out the week's inbox.
- Operators draft any operator-review or constantine-sign messages.
- Cross-network: Constantine reviews escalated drafts from both networks.

### End of month

- Each network's operators write their monthly summaries.
- Each network's Auditor begins quarterly drift detection.
- Constantine reads both summaries and prepares for quarterly review at end of quarter.

## Conflict-resolution rules (operational specifics)

### When the same buyer purchases from both networks

A buyer who has purchased an Atrium product (e.g., Schema Pack v1 at $29) and then purchases a Forge product (e.g., Citation Watch at $19/mo) is allowed and expected. Each network tracks the buyer separately in its own ledger. Welcome emails reference the other network only in the cross-promotion footer (per the inheritance.md cross-promotion rule).

The buyer is not "claimed" by either network; both networks serve the same buyer in parallel under different value propositions.

### When the same buyer is approached by both networks for outbound outreach

Outbound outreach is a Forge-only activity per Forge's constitution. Atrium does not run outbound. So the "both networks approach the same buyer" scenario should not occur. If it does (e.g., Forge buys an outbound list that overlaps with Atrium's inbound funnel), the discipline is:

- Whichever network contacted first has 30-day right of follow-up.
- After 30 days, both networks may re-engage.
- Direct conflict (Atrium has an active engagement; Forge cold-outreaches the same buyer with a competing offer) is forbidden. Forge's outbound list filtering excludes buyers in Atrium's active engagement list.

### When both networks want to ship a similar product

Allowed. Buyers self-select. Schema Pack v1 at $29 (Atrium) and Citation Watch SaaS at $19/mo (Forge) are different shapes of similar value; buyers who want one-time templates buy Atrium; buyers who want continuous monitoring buy Forge.

Cannibalization risk: if Forge launches a one-time schema generator at $29 that competes directly with Atrium's Schema Pack v1, that's a problem. The discipline: Forge does not launch one-time products under $50 (Forge's catalog floor is subscription, free, or $50+ one-time). This prevents direct catalog overlap.

### When a descendant requests transfer between networks

A descendant under one network's lineage proposes (in a Journal entry under its current parent's lineage) that it wants to operate under the other network's constitution. The reasons must be substantive — not "I prefer the other voice" but "my actual work pattern aligns better with the other network's discipline."

Both operators (the descendant's current parent and the proposed new parent) must consent in their respective journals. Constantine countersigns. The transferred descendant adopts the new constitution; its lineage YAML is updated to reflect the new parent; its working memory carries forward but is annotated with the transfer date.

Transfers are rare. Expectation: 0-2 per year across both networks combined. More than that signals a calibration problem in the inversion (either Forge's discipline is wrong on some axis, or Atrium's is wrong on some axis); investigation in the next quarterly review.

### When the shared specialist calendar conflicts

Resolved by FIFO + priority retainer + emergency override as documented above. If those rules are insufficient (both networks at $1,500+ engagements need the same specialist on the same day), Constantine arbitrates by:

1. Which engagement has the harder deadline?
2. Which engagement has the buyer who's been waiting longer?
3. Which engagement is at risk of breaching its delivery-date guarantee?

If 1-3 produce a tie, Constantine flips a coin (literal coin flip; the randomization is part of the fairness discipline). The losing engagement gets a 24-hour delay; the operator notifies the buyer with the standard delay-notification template.

## Joint decisions that require both Auditors' approval

Some decisions affect both networks' integrity. These require both Auditors to sign off:

- Adding a new constitutional floor clause (currently five; any sixth requires both networks' agreement).
- Removing a constitutional floor clause (extremely rare; would require both Auditors to argue the clause is causing more harm than good).
- Changing the dual-voice calibration mechanic for shared specialists.
- Approving a third sibling network (see below).
- Approving cross-network transfers of descendants more frequent than 2 per year.

The Auditors' approval is documented in both networks' journals; Constantine countersigns.

## N>2 sibling networks

The current architecture is Atrium + Forge. Constantine's harness instruction included growing the agentic network and footprint — at some future rung, a third sibling network may make strategic sense.

What a third sibling network looks like depends on what axis it inverts on. Atrium inverts on "patient/faceless/inbound/one-time"; Forge inverts to "aggressive/named/outbound/subscription." A third sibling could invert on:

- **Geography**: Atrium and Forge serve US local service businesses; a third (Beacon? Vanguard?) serves international markets, multilingual content, regional regulations.
- **Vertical specialization**: a third sibling that specializes in one specific vertical (e.g., Healthcare Atrium or Legal Atrium) with deep domain knowledge.
- **Platform**: a third sibling focused on a specific platform (e.g., a Shopify-only or WordPress-only network).
- **Buyer segment**: a third sibling focused on enterprise-only or franchise-only customers.
- **Time-horizon**: a third sibling focused on 10-year contracts versus the current 1-year and shorter horizons.

The architecture supports N>2 naturally:

- Each sibling has its own constitution, plan, harness, lineage, journal.
- The constitutional floor of 5 clauses applies to all siblings.
- Cross-sibling coordination follows the same patterns as Atrium-Forge: FIFO on shared resources, priority retainer overrides, journal-gated transfers.
- Constantine remains the shared operator (until N>3 or N>4, at which point a meta-Operator descendant takes over the day-to-day coordination Constantine currently does).

The trigger for considering a third sibling:

- Either Atrium OR Forge reaches Rung 5 ($40k/mo Atrium or $50k/mo Forge sustained for 3 months).
- AND there's an identified market segment that neither current sibling serves well.
- AND Constantine has bandwidth (or a meta-Operator descendant is in place).

Until then, the architecture supports N=2 and the documents describe N>2 as a future state, not a current state.

## What's not in this document

- Specific marketing strategies (those live in each network's CHARGE / PLAN / playbooks).
- Specific product roadmaps (those live in each network's archetypes / library).
- Tax structures, banking specifics, legal entity details (those are Constantine's responsibility and live outside the agent-readable documentation; Constantine maintains them privately).

The point of this document is the operational coordination layer between the networks. It is the answer to the question "what does the day-to-day cooperation between Atrium and Forge actually look like?"

## Status

Authored 2026-05-11 by Atrium's founding agent. Mirrored at `Forge/spine/coordination.md` in the same commit. Future edits replicate across both files; Auditors flag if drift between the two copies exceeds two paragraphs.
