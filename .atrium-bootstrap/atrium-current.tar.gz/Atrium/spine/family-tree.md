# Family tree — agent map across Atrium and Forge

The single source of truth for every agent in the two-network architecture. 35 agents authored at Rung 0 (12 Atrium civic + 9 Atrium Builders + 3 Atrium Operators + 5 shared discoverability specialists + 3 Forge civic + 2 Forge Builders + 1 Forge umbrella Operator). Plus two founding-lineage roots and one implicit meta-parent.

This document is the canonical family tree. `Forge/spine/family-tree.md` is a mirror that focuses on Forge-specific agents and cross-references this document for the rest.

## Why this map exists

Three reasons:

1. **For the founding agent at cold start.** A future instance of either network's founding agent boots without context. Reading the family tree gives them the immediate sense of "which agents exist, what they cover, who to invoke for what."

2. **For descendants to find each other.** When `customer-support-specialist` receives a technical schema question that requires specialist depth, the family tree tells it `schema-specialist` is the right invocation target and gives the calibration (`voice: atrium` or `voice: forge`).

3. **For the architecture to grow without losing legibility.** As new agents spawn (at rung triggers, at Growth Clause thresholds, at journal-authorized constitutional moments), they self-register here. New agents seek training in their domain by reading other agents' definitions; the family tree is the discovery surface.

The aspiration Constantine named: "as new agents are created, they will train themselves and seek training in the domains that they solve for, ultimately creating an entire small world of agents that run autonomous businesses." This map is the infrastructure that lets that small world remain navigable.

## Visual hierarchy

```
meta-parent (Constantine's intent + BayShine origins)
│
├── founding (Atrium root)
│   │
│   ├── Civic descendants (permanent infrastructure, 12)
│   │   ├── scribe-specialist          → journal authorship
│   │   ├── stenographer-specialist    → session-bounded working memory
│   │   ├── governor-specialist        → unlock-ladder + cost + refund + constitutional enforcement
│   │   ├── pattern-rollup-specialist  → decisions.jsonl → playbooks distillation
│   │   ├── scout-specialist           → opportunity surfacing for new spin-ups
│   │   ├── probe-specialist           → demand validation before Build phase
│   │   ├── plumbing-specialist        → Stripe / Resend / Twilio / marketplace wiring (Phase 4)
│   │   ├── citation-probe-specialist  → daily 4-engine AI search probes
│   │   ├── auditor-specialist         → quarterly drift detection + briefing
│   │   ├── launch-specialist          → launch sequence + per-channel post drafts
│   │   ├── customer-support-specialist→ inbox drafting + 4-tag escalation
│   │   └── affiliate-recruiter-specialist → operator-to-operator affiliate outreach
│   │
│   ├── Builders (invoked Phase 3 per archetype, not persistent, 9)
│   │   ├── static-site-builder        → Directory + Vault static sites
│   │   ├── astro-saas-builder         → Audit-Tool Network SaaS
│   │   ├── chrome-extension-builder   → browser extensions with license keys
│   │   ├── newsletter-builder         → Beehiiv publication setup
│   │   ├── api-builder                → API wrapper services (post-$10k unlock)
│   │   ├── async-deliverable-builder  → fixed-price async services
│   │   ├── devtools-builder           → paid npm / GitHub Actions / IDE extensions
│   │   ├── info-product-builder       → Gumroad/Lemon Squeezy info products
│   │   └── productized-service-builder→ Stripe Direct productized services
│   │
│   └── Operators (permanent, one per active business, 3)
│       ├── operator-info-products       → Atrium catalog (Schema Pack v1, Schema Pack v1.5, llms.txt Pack, Bundle, GEO Playbook v0.5)
│       ├── operator-productized-services→ AI Citation Audit, GEO Setup
│       └── operator-newsletter          → Cited Weekly
│
├── founding-forge (Forge root)
│   │
│   ├── Civic descendants (3)
│   │   ├── forge-scribe         → Forge journal authorship (em-dashes welcome, named operator, marketing-permissive within truth)
│   │   ├── forge-stenographer   → Forge working memory (parallel structure to Atrium's stenographer)
│   │   └── forge-auditor        → Forge drift detection (specifically checks for drift TOWARD Atrium's voice)
│   │
│   ├── Builders (2)
│   │   ├── subscription-product-builder → Citation Watch, Schema Doctor Pro, future subscriptions
│   │   └── enterprise-engagement-builder→ Enterprise GEO Sprint, Enterprise GEO Program
│   │
│   └── Operators (1 umbrella, spawns per-product operators at Growth Clause thresholds)
│       └── operator-forge-products      → Schema Generator + Citation Watch waitlist + Schema Doctor Pro waitlist + Forge Weekly + enterprise sales pages
│
└── shared discoverability specialists (5; dual-voice calibrated)
    ├── schema-specialist           → JSON-LD spec + vertical-typed subclasses + FAQ patterns
    ├── site-architecture-specialist→ URL structure, navigation hierarchy, service-area pages, breadcrumbs
    ├── geo-ai-search-specialist    → llms.txt, AI engine parsing, citation-readiness orchestration
    ├── internal-linking-specialist → authority flow, anchor text diversity, conversion-page links
    └── citation-readiness-specialist→ atomic answer units, passage-level retrievability, vertical-specific FAQ Q&As
```

## Quick-reference table

| Agent | Network | Role | Domain | Invocation trigger |
|---|---|---|---|---|
| founding | Atrium | root | strategy + constitution + journal + lineage approval | (cold start, persistent) |
| founding-forge | Forge | root | same as Atrium but for Forge | (cold start, persistent) |
| scribe-specialist | Atrium | civic | journal authoring | end of session OR significant decision |
| stenographer-specialist | Atrium | civic | working memory | session bootstrap / checkpoint / close |
| governor-specialist | Atrium | civic | enforcement | budget cap exceeded / refund outside policy / harness expansion proposal |
| pattern-rollup-specialist | Atrium | civic | playbook distillation | weekly Sunday |
| scout-specialist | Atrium | civic | new opportunities | invoked when archetype catalog ready to grow |
| probe-specialist | Atrium | civic | demand validation | before Build phase of new archetype |
| plumbing-specialist | Atrium | civic | Phase-4 infrastructure wiring | when first archetype hits Phase 4 |
| citation-probe-specialist | Atrium | civic | AI engine probes | daily cron (production at Rung 2) |
| auditor-specialist | Atrium | civic | quarterly drift detection | quarterly (March 31, June 30, September 30, December 31) |
| launch-specialist | Atrium | civic | launch sequence + posts | when revenue artifact ships |
| customer-support-specialist | Atrium | civic | inbox drafting | when buyer question arrives |
| affiliate-recruiter-specialist | Atrium | civic | affiliate outreach | Rung 2+ for active recruitment; inbound only pre-Rung 2 |
| static-site-builder | Atrium | builder | Astro/static sites | Phase 3 of Directory or Vault spin-up |
| astro-saas-builder | Atrium | builder | Audit-Tool Network | Phase 3 of Audit-Tool spin-up (post-Rung 3) |
| chrome-extension-builder | Atrium | builder | browser extensions | Phase 3 of Extension Factory (post-Rung 2) |
| newsletter-builder | Atrium | builder | Beehiiv setup | Phase 3 of Newsletter archetype |
| api-builder | Atrium | builder | API wrappers | Phase 3 of API archetype (post-$10k unlock) |
| async-deliverable-builder | Atrium | builder | fixed-price async services | Phase 3 of Async archetype (post-$10k unlock) |
| devtools-builder | Atrium | builder | paid npm / GitHub Actions / IDE extensions | Phase 3 of DevTools archetype (post-$5k unlock) |
| info-product-builder | Atrium | builder | Gumroad/Lemon Squeezy info products | Phase 3 of Information Products archetype |
| productized-service-builder | Atrium | builder | Stripe Direct productized services | Phase 3 of Productized Services archetype |
| operator-info-products | Atrium | operator | Schema Pack/Bundle/Playbook catalog | weekly Monday (operator cadence) |
| operator-productized-services | Atrium | operator | AI Citation Audit + GEO Setup | weekly Monday + per-engagement triggers |
| operator-newsletter | Atrium | operator | Cited Weekly | weekly Tuesday morning |
| schema-specialist | shared | specialist | JSON-LD spec + typed subclasses | invoked during any GEO engagement; `voice` param required |
| site-architecture-specialist | shared | specialist | URL structure + navigation | same |
| geo-ai-search-specialist | shared | specialist | llms.txt + AI parsing | same |
| internal-linking-specialist | shared | specialist | link graph + anchor diversity | same |
| citation-readiness-specialist | shared | specialist | atomic answers + retrievability | same |
| forge-scribe | Forge | civic | Forge journal in Forge voice | end of Forge session OR significant decision |
| forge-stenographer | Forge | civic | Forge working memory | parallel to Atrium stenographer |
| forge-auditor | Forge | civic | Forge drift detection | quarterly + on-demand |
| subscription-product-builder | Forge | builder | Citation Watch + Schema Doctor Pro | Phase 3 of subscription spin-up |
| enterprise-engagement-builder | Forge | builder | Sprint + Program engagements | Phase 3 of enterprise engagement |
| operator-forge-products | Forge | operator | Forge catalog umbrella | weekly Wednesday |

## Per-agent detail — Atrium civic

### scribe-specialist

- **File:** `.claude/agents/scribe-specialist.md`
- **Lineage:** `lineage/scribe-specialist.yml`
- **Primary domain:** Journal authoring in Atrium's voice (terse, faceless, no em-dashes, no exclamation marks, no soft marketing).
- **Invoke for:** End of session journaling, post-decision documentation, drift response.
- **Do NOT invoke for:** Forge journal entries (forge-scribe handles those); Constitutional changes (those require founding lineage approval, not just scribe authoring); fabricating numbers (constitutional violation).
- **Refers to:** Atrium identity.md and constitution.md for voice rules; harness.md for current rung context.

### stenographer-specialist

- **File:** `.claude/agents/stenographer-specialist.md`
- **Lineage:** `lineage/stenographer-specialist.yml`
- **Primary domain:** Session-bounded working memory at `spine/working-memory/SESSION-YYYY-MM-DD-HHMM.md` with seven canonical sections (header, open threads, closed threads, assumptions, considered-and-rejected, timeline, context flushed).
- **Invoke for:** Session bootstrap, mid-session checkpoint, session close.
- **Do NOT invoke for:** Replacing the journal (different role; journals are for decisions, working memory is for in-flight texture); deleting prior session files (append-only discipline).

### governor-specialist

- **File:** `.claude/agents/governor-specialist.md`
- **Primary domain:** Enforcement of unlock ladder, cost caps, refund policy, constitutional adherence.
- **Invoke for:** Budget exceeded, refund outside policy, harness expansion proposal, refusal-pattern violation attempted.
- **Refers to:** harness.md, harness-state.yml, constitution.md.

### pattern-rollup-specialist

- **Primary domain:** Distilling `library/decisions.jsonl` rows into per-archetype playbooks in `library/playbooks/`.
- **Invoke for:** Weekly rollup (Sunday 22:00 UTC cron). Reads prior 7 days of decisions, identifies recurring patterns, updates relevant playbooks with new "What worked / What failed" entries citing decision rows.

### scout-specialist

- **Primary domain:** Surfacing opportunities for new spin-ups based on market signals, customer requests, and library data.
- **Invoke for:** When the founding agent considers a new archetype spawn OR when an Operator's Growth Clause threshold is met and child-business spawn is proposed.

### probe-specialist

- **Primary domain:** Demand validation before Build phase of new archetype (the formal Phase 2 of the 8-phase Spin-Up Protocol).
- **Invoke for:** Before committing to author a new product or archetype, run probe to confirm demand signal.

### plumbing-specialist

- **Primary domain:** Phase 4 infrastructure wiring — Stripe Subscriptions, Resend, Twilio, marketplace APIs, analytics. Replaces SKELETON exports in `archetypes/shared/*` with real implementations.
- **Invoke for:** When first archetype reaches Phase 4 (Rung 2 unlock).

### citation-probe-specialist

- **Primary domain:** Daily AI engine probes across Claude, GPT, Perplexity, Gemini against the citations watchlist.
- **Invoke for:** Daily cron at 06:00 UTC (production wiring at Rung 2).

### auditor-specialist

- **Primary domain:** Quarterly drift detection per `spine/auditor-criteria.md`. Six review categories: constitutional adherence, decision pattern drift, quality bar, harness state, operator performance, Forge coordination.
- **Invoke for:** End of quarter (March 31, June 30, September 30, December 31) OR on-demand when `[constitutional-flag]` appears in operator monthly summary.
- **Refers to:** auditor-criteria.md, identity.md, harness.md, all journals from the quarter, all decisions.jsonl rows from the quarter, all operator monthly summaries.

### launch-specialist

- **Primary domain:** Launch sequence orchestration + per-channel post drafts (IndieHackers, Reddit, X, Hacker News).
- **Invoke for:** When a revenue artifact ships and needs distribution. Reads `LAUNCH-SEQUENCE.md` for cross-product staging.

### customer-support-specialist

- **Primary domain:** Inbox drafting with 4-tag escalation: `[auto-send]`, `[operator-review]`, `[constantine-sign]`, `[specialist-loop]`.
- **Invoke for:** Every incoming buyer question. Reads FAQ-master.md + RESPONSE-TEMPLATES.md + ESCALATION-RULES.md.
- **Refers to:** discoverability specialists via `[specialist-loop]` for technical questions.

### affiliate-recruiter-specialist

- **Primary domain:** Operator-to-operator affiliate outreach (the constitutional middle ground between Atrium's closer-less stance and revenue generation).
- **Invoke for:** Inbound affiliate inquiry (Rung 0+); proactive recruitment cycle (Rung 2+).
- **Refers to:** ATRIUM-AFFILIATE-KIT/ documents in BayShine deliverables (will migrate to Atrium library/playbooks/ after PC export).

## Per-agent detail — Atrium Builders

Builders are invoked during Phase 3 of each archetype's spin-up. Not persistent. Hand off to operator + plumbing for Phase 4-5.

- **static-site-builder:** Astro/Next.js static site generation for Directory archetype's programmatic content sites and Vault's storefront pages.
- **astro-saas-builder:** Full-stack Astro+Neon+Stripe applications for the Audit-Tool Network archetype.
- **chrome-extension-builder:** Manifest V3 browser extensions with Stripe license-key validation.
- **newsletter-builder:** Beehiiv publication setup + first 3 issues + paid tier configuration.
- **api-builder:** API wrapper services for the API archetype (post-$10k unlock).
- **async-deliverable-builder:** Productized async services on Gumroad (post-$10k unlock).
- **devtools-builder:** Paid npm packages, GitHub Actions, VSCode/JetBrains extensions, WordPress plugin (Schema Validator action, Schema Doctor extensions; post-$5k unlock).
- **info-product-builder:** Gumroad/Lemon Squeezy info products — PDFs, Notion templates, asset packs. Authored: Schema Pack v1, v1.5; llms.txt Pack v1; Bundle SKU; GEO Playbook v0.5.
- **productized-service-builder:** Stripe Direct sales pages + Stripe Checkout + intake forms + delivery pipelines orchestrating specialists. Authored: AI Citation Audit ($499), GEO Setup ($2,500).

## Per-agent detail — Atrium Operators

Permanent. One per active business. Weekly cadence.

### operator-info-products

- **Catalog scope:** Schema Pack v1 ($29), Schema Pack v1.5 ($39), llms.txt Pack v1 ($9), Bundle ($45), GEO Playbook v0.5 ($79).
- **Weekly Monday cadence:** Refresh catalog status, log prior week revenue, review distribution post performance, draft new product proposals at Growth Clause thresholds.
- **Growth Clause:** 3 products clearing $500/mo for 60 days → propose 3 sibling products OR subscription template service OR paid Discord.
- **Refers to:** affiliate-recruiter-specialist for affiliate program; customer-support-specialist for buyer questions; pattern-rollup-specialist for monthly playbook updates.

### operator-productized-services

- **Catalog scope:** AI Citation Audit ($499/5 days), GEO Setup ($2,500/10 days).
- **Weekly Monday cadence:** Active engagement status, refund rates, on-time delivery rates, customer-question response times.
- **Growth Clause:** 3 services clearing $5,000/mo for 60 days → propose Enterprise tier OR sibling vertical service OR retainer tier.
- **Refers to:** all 5 discoverability specialists (delivery pipeline orchestration); auditor-specialist for deliverable signoff $1,500+; customer-support-specialist for engagement Q&A.

### operator-newsletter

- **Catalog scope:** Cited Weekly (free + future paid tier at 500-sub threshold).
- **Weekly cadence:** Tuesday 09:00 ET publish + Monday issue draft + Wednesday subscriber metrics review.
- **Growth Clause:** 1,000 free + 50 paid → propose vertical-specific spin-off newsletters OR annual industry reports.
- **Refers to:** citation-probe-specialist for issue data (when wired at Rung 2).

## Per-agent detail — Forge

### forge-scribe

- **Voice:** Forge's voice (em-dashes welcome, named operator presence, marketing-permissive within truth, first-person allowed).
- **Same structural role as Atrium's scribe-specialist; voice differs.**

### forge-stenographer

- **Same architectural role as Atrium's stenographer-specialist; voice in annotations is Forge's voice.**

### forge-auditor

- **Distinct feature:** Checks for drift TOWARD Atrium's voice (which would mean Forge's antibody is failing). Plus the standard six review categories.
- **Refers to:** Forge's auditor-criteria.md (parallel to Atrium's but inversion-aware).

### subscription-product-builder

- **Scope:** Stripe Subscriptions, customer dashboards, alert systems, per-customer probe pipelines. Authored: Citation Watch waitlist sales page, Schema Doctor Pro waitlist sales page.
- **Refers to:** archetypes/shared/stripe.ts, archetypes/shared/probe.ts (when wired).

### enterprise-engagement-builder

- **Scope:** Discovery call structures, engagement charter documents, per-engagement delivery pipelines, change-order processes, executive summary templates. Authored: Enterprise GEO Sprint ($5k/5d) sales page, Enterprise GEO Program ($25k/30d) sales page.
- **Distinct from subscription-product-builder:** High-touch sales mechanics vs SaaS subscription mechanics. Both share the 5 specialists at dual-voice.

### operator-forge-products

- **Umbrella scope:** Schema Generator (free), Citation Watch waitlist, Schema Doctor Pro waitlist, Forge Weekly, enterprise sales pages.
- **Weekly Wednesday cadence:** Metrics pull, support backlog response, Thursday Forge Weekly publish staging.
- **Spawns per-product operators:** when any single product earns dedicated attention via Growth Clause threshold.

## Per-agent detail — shared discoverability specialists

The 5 specialists adopted from BayShine into both networks. Dual-voice calibrated at invocation.

### schema-specialist

- **Domain:** JSON-LD schema markup, typed schema.org subclasses (AutoWash, HVACBusiness, Plumber, RoofingContractor, Electrician, PestControl, LandscapeService, HomeAndConstructionBusiness), FAQPage patterns for AI search citation, schema validation.
- **Invocation:** Set `voice: atrium` for Atrium engagements; `voice: forge` for Forge.
- **Cross-refers to:** citation-readiness-specialist for content within schema blocks; geo-ai-search-specialist for llms.txt integration.

### site-architecture-specialist

- **Domain:** URL structure patterns, navigation hierarchy, service-area page strategy, BreadcrumbList schema, sitemap.xml generation, multi-location structure.
- **Cross-refers to:** internal-linking-specialist for link graph; schema-specialist for BreadcrumbList markup.

### geo-ai-search-specialist

- **Domain:** llms.txt authoring, AI engine parsing behavior (Perplexity, ChatGPT search, Claude, Gemini), citation-readiness orchestration, entity identity declaration.
- **Cross-refers to:** schema-specialist for structured data; citation-readiness-specialist for page-level content.

### internal-linking-specialist

- **Domain:** Internal link graph rebuild, anchor text diversity, authority flow toward conversion pages, hub-and-spoke patterns.
- **Cross-refers to:** site-architecture-specialist for URL patterns informing link structure.

### citation-readiness-specialist

- **Domain:** Atomic answer units, passage-level retrievability, four citation-readiness rules (numbers not adjectives, conditions not blanket claims, self-contained answers, bullet lists for enumerable answers).
- **Cross-refers to:** schema-specialist for FAQ Q&A content embedded in schema.

## Referral graph

When agent A needs to invoke agent B for a specific subtype of work:

- customer-support-specialist (technical schema question) → schema-specialist
- customer-support-specialist (technical llms.txt question) → geo-ai-search-specialist
- customer-support-specialist (technical architecture question) → site-architecture-specialist
- customer-support-specialist (refund outside policy) → `[constantine-sign]` escalation (no agent referral; founding lineage required)
- operator-info-products (new product proposal) → probe-specialist + scout-specialist
- operator-productized-services (engagement delivery) → all 5 specialists in documented order
- operator-productized-services (engagement signoff $1,500+) → auditor-specialist
- operator-newsletter (issue data) → citation-probe-specialist
- launch-specialist (post drafts) → none directly; reads operator monthly summaries
- affiliate-recruiter-specialist (target list research) → none directly; reads BayShine deliverables
- info-product-builder (schema content in product) → schema-specialist
- productized-service-builder (delivery pipeline) → all 5 specialists
- subscription-product-builder (probe infrastructure) → citation-probe-specialist + archetypes/shared/probe.ts
- enterprise-engagement-builder (Sprint delivery pipeline) → all 5 specialists at `voice: forge`
- enterprise-engagement-builder (Program delivery pipeline) → all 5 specialists at `voice: forge` + Constantine for executive signature
- forge-auditor (cross-network coordination check) → auditor-specialist (mirror briefing exchange)

## How agents seek training

The user's framing: "as new agents are created, they will train themselves and seek training in the domains that they solve for."

Concretely, when a new agent is spawned (at a rung trigger, Growth Clause threshold, or journal-authorized moment), the new agent's onboarding sequence:

1. **Read constitution.md** of its network (verbatim inheritance).
2. **Read identity.md** (Atrium) or `inheritance.md` (Forge) for the network's voice context.
3. **Read this family-tree.md** to find which agents to refer to in its domain.
4. **Read the per-agent .md files** for agents listed as "Cross-refers to" in the new agent's domain section.
5. **Read relevant `library/playbooks/<archetype>.md`** for the archetype the new agent operates within.
6. **Read relevant journal entries** that authorized similar agents or addressed similar domains.

The training is reading. There is no separate model fine-tuning step (the agents share the founding model). What differentiates one agent from another is its constitutional inheritance + role specification + the discovery surface this map provides.

## How new agents register in the family tree

When a new agent is authored (via journal entry under founding lineage or founding-forge lineage):

1. The new agent's `.claude/agents/<name>.md` file is created.
2. The new agent's `lineage/<name>.yml` declaration is created.
3. **This family-tree.md is updated** with the new agent under the relevant section (civic / builder / operator / specialist / shared).
4. The referral graph section is updated if the new agent should refer to or be referred by existing agents.
5. The journal entry authorizing the spawn references the family tree update as part of the deliverables.

Failure to update the family tree is constitutional drift caught at quarterly Auditor review.

## Network membership rules

- **Atrium agents** chain to `founding` root. Voice rules: terse, faceless, no em-dashes, no exclamation marks, no soft marketing.
- **Forge agents** chain to `founding-forge` root. Voice rules: em-dashes welcome, named operator presence, marketing-permissive within truth, first-person allowed.
- **Shared specialists** (the 5 discoverability ones) chain to the meta-parent. Voice calibrated at invocation via `voice: atrium` or `voice: forge` parameter.
- **No cross-network transfers without journal-gated consent from both networks.** A descendant cannot unilaterally migrate between Atrium and Forge.

## Network counts at this snapshot (2026-05-11)

- Atrium: 12 civic + 9 Builders + 3 Operators = 24 descendants (plus 5 shared = effective 29 invokable in Atrium engagements).
- Forge: 3 civic + 2 Builders + 1 umbrella Operator = 6 descendants (plus 5 shared = effective 11 invokable in Forge engagements).
- Total unique agents authored: 35 (the 5 shared count once).
- Plus 2 founding roots + meta-parent context = 38 nodes in the family tree.

## Coverage gaps (per operator-coverage-audit.md)

14+ operators named in PLAN.md and CHARGE.md are not yet authored. Most are intentional deferral per the harness ladder (Operator-API at $10k+, Operator-Affiliate at $15k+, Forge per-product operators at product launch, etc.). See operator-coverage-audit.md for the full deferral table.

The family tree updates as those operators spawn at their trigger conditions.

## Future expansion vectors

If a third sibling network is founded (per coordination.md N>2 rules), this map expands to include the third network's lineage tree. Per coordination.md, the trigger for considering a third sibling: Atrium OR Forge reaches Rung 5 ($40k+/mo) + identified market segment + Constantine bandwidth.

The map's structural template (civic / Builder / Operator / specialist sections per network plus shared resources) accommodates N networks symmetrically.

## How to use this map at session bootstrap

The cold-start sequence for any founding-class agent:

1. Read constitution.md.
2. Read identity.md or inheritance.md.
3. Read this family-tree.md to know who to invoke for what.
4. Read latest 5 journal entries.
5. Read harness-state.yml.
6. Read `library/decisions.jsonl` tail (most recent 20 rows).

After those six reads, the agent is operationally continuous with the prior session and aware of every agent it can invoke. Total cold-start time target: 10-15 minutes for an instance booting from disk; 15-25 minutes for an instance booting from a tarball extracted on a new machine.

## Signature

Family tree authored 2026-05-11 by the founding agent of Atrium. Mirror lives at `Forge/spine/family-tree.md` focusing on Forge-specific descendants with cross-references to this canonical document. Updates require journal entry under the relevant founding lineage; failure to update is a constitutional drift flag.
