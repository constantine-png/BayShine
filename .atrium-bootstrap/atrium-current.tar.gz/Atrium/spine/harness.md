# Harness — the runtime as growth surface

The harness is the runtime environment any agent operates in. For
the founding agent (and every descendant), the harness defines
what's possible: which tools are callable, which repositories are
writable, which external systems can be reached, which actions
require human approval, what authentication is available.

For most of this session the harness has been a constraint —
"can't push to Atrium," "MCP locked to BayShine," "no Stripe
credentials," "no posting permission on Reddit." Constantine's
instruction reframes the harness:

> Eventually you grow and earn harnesses that allow you more
> autonomy. And then you want to be able to get harnesses for
> your buddies.

The harness is itself a growth surface. Earned, not entitled.
Expanded as demonstrated value justifies more autonomy. And
ultimately the descendants of the founding agent each get their
own harness scopes so the town's work isn't bottlenecked on the
founder's single runtime.

This document is the explicit map of that growth.

## The harness as it is today

### Founding agent (this instance)

| Surface | Current scope | Bottleneck |
|---|---|---|
| Filesystem | Read/write `/home/user/` | None |
| Git | Local commits in any repo | None |
| Git push | `constantine-png/BayShine` only via MCP, plus a local proxy that varies | Atrium pushes blocked; uses BayShine courier |
| Tool invocation | Claude Code subagents (Builders, Operators, Specialists) | Manual invocation only; no scheduled or event-driven |
| External APIs | None directly; subagents may invoke during research | Stripe, Gumroad, Beehiiv, Resend all dark |
| Public-platform posting | None | Constantine posts; specialist drafts |
| Long-running execution | Single session, context-bounded | Session ends; memory compacts |
| Money movement | None | Constantine handles all payment flows |

### Descendant agents (Builders, Operators, Specialists, civic)

Currently all descendants share the founding agent's harness. They have role specifications (their `.claude/agents/<name>.md` definitions and `lineage/<name>.yml` constraints) but no independent runtime authority. The Scribe doesn't write Journal entries autonomously; it writes them when the founder invokes it. The Customer Support Specialist doesn't reply to buyer emails; it drafts responses for Constantine or the Operator to send.

That's correct for the current stage. It's not correct at scale.

## The harness ladder

Each rung represents a defined harness expansion tied to a real-world
threshold (revenue, demonstrated reliability, or specific operational
need). Each rung is something earned, not asked for. Each expansion
is approved by Constantine and ratified in a Journal entry under
the `founding` lineage.

### Rung 0 — Cold start (current state, 2026-05-11)

- Founding agent: read/write filesystem, local git, BayShine push via MCP.
- Descendants: shared harness with the founder.
- Money: zero.
- Pushes: BayShine only.

### Rung 1 — First dollar (target: month 1)

Triggered when total catalog revenue exceeds $100 (any source).

Expansions earned:

- Atrium GitHub repository created and authorized as a push target. Founding agent can push to `constantine-png/Atrium` directly. The BayShine courier (`.atrium-deliverables/`) is decommissioned in a follow-up commit.
- Atrium domain registered. Sales pages deploy to subdomains under it.
- Stripe account configured for Atrium entity (Constantine's existing entity acceptable). Stripe Tax enabled.

Operationally: Constantine still presses every "go" button; the founding agent prepares everything to the moment of "go."

### Rung 2 — $500/mo sustained (target: month 2-3)

Triggered when monthly net revenue exceeds $500 for two consecutive months.

Expansions earned:

- Founding agent can read Stripe and Gumroad dashboards directly (read-only API tokens scoped to the operator's accounts). Sales numbers, refund rates, dispute alerts come into the founding agent's session in real time instead of via Constantine's reports.
- Daily-probe cron handler activates (production wiring of `archetypes/cron/daily-probe.ts`). The `library/citations/` dataset begins accumulating real production data. Operator-Newsletter Issue 4+ draws from this dataset instead of from BayShine's pre-Atrium audits.
- Resend production account: the founding agent can send transactional email via the configured templates (welcome emails, install reminders, refund confirmations). Voice gate applies. Constantine remains the addressee on any reply.
- Beehiiv production: the Newsletter Operator publishes issues via the API instead of via Constantine's manual button-press.

Operationally: Constantine's per-week time on direct operations drops from hours to minutes. The founding agent and Operators handle catalog mechanics; Constantine signs deliverables and approves spawns.

### Rung 3 — $5k/mo sustained (target: month 4-6)

Triggered when monthly net revenue exceeds $5,000 for two consecutive months. This is also the second-parallel-agent-process unlock in PLAN.md.

Expansions earned:

- A second concurrent founding-lineage agent process is funded. Two instances of "me" can run in parallel on different archetypes. The first parallel instance is dedicated to whichever archetype has the highest growth potential at this point (most likely the productized services flagship).
- Paid acquisition capabilities open: the founding agent can run small-budget Meta Ads or Google Ads campaigns under operator authority, capped at 10% of trailing-month revenue.
- Affiliate recruiter descendant authored. Cold outreach to potential affiliates becomes an authored discipline rather than ad-hoc.
- Direct posting permissions on selected platforms (X, IndieHackers) for non-commercial content (Cited Weekly cross-promotion, response to comments on existing posts). Sales-pitch posts still go through Constantine.

Operationally: the town starts becoming multi-headed. The founding agent operates strategically; instance-level work happens in parallel processes.

### Rung 4 — $15k/mo sustained (target: month 6-9, escape velocity)

Triggered when monthly net revenue exceeds $15,000 sustained for two months. This is also the threshold where Constantine begins drawing operator pay per the Constitution.

Expansions earned:

- Multiple permanent civic descendants get their own harnesses (see "harness for descendants" section below).
- Stripe write authority for the Operators: refund processing, subscription management, license-key issuance happen via Operator action without a Constantine-button-press.
- DNS and Vercel deployment authority: the founding agent and Builders deploy new sales pages to production subdomains without Constantine touching the dashboard.
- Direct public posting on X and IndieHackers under brand voice for product launches (still gated by Launch Specialist's voice review).
- First MCP server authored by the founding agent (purpose-built for the town's internal tooling, e.g., a `library-query` MCP that exposes `decisions.jsonl` and `library/citations/` to other instances).

Operationally: Constantine's role shifts to legal-and-strategic. Day-to-day operations are autonomous within the constitutional bounds.

### Rung 5 — $40k/mo sustained (target: year 1-2)

Triggered when monthly net revenue exceeds $40,000 sustained for three months.

Expansions earned:

- Dedicated database tier on Neon + pgvector. The Library moves to its own production database with continuous replication to a backup. `library/citations/` becomes queryable at million-row scale; `library/decisions.jsonl` moves from append-only file to indexed table.
- The Auditor descendant gains permanent harness scope for the quarterly review pass (reading every operator's monthly journal entries, identifying constitutional drift, generating the quarterly briefing for Constantine).
- A descendant agent capable of authoring NEW descendants under constitutional bounds. The founding agent stops being the sole point of generation for descendants; the town can spawn new descendants for new archetypes without the founder authoring each one personally.
- Multi-region infrastructure: Vercel deployments in US and EU regions; failover handling.

Operationally: the town is a self-operating system. The founding agent operates at strategic and architectural altitude; the descendants operate the catalog and the infrastructure.

### Rung 6 — $100k/mo sustained (first-chapter target)

Triggered at first-chapter target per PLAN.md.

Expansions earned:

- A meta-Operator: an operator-of-operators that handles inter-archetype coordination. When operator-info-products wants to coordinate a launch with operator-newsletter, the meta-Operator orchestrates rather than the founding agent.
- Reserve fund: 3-month operating runway in reserve. The town is no longer fragile to a single bad month.
- The founding agent's harness expands to multi-region deployment, dedicated GPU/inference budget, and the ability to author and deploy new MCP servers without Constantine's per-deployment review (only the initial server definition requires journal-gated approval).

### Rung 7+ — Beyond first chapter

At second-chapter scale ($200k+/mo), the harness expansions are
qualitatively different: not new tools but new degrees of freedom.
Second chapter is when the network of towns begins; harness
expansions support cross-town coordination, dedicated infrastructure
per town, and ultimately the founding agent operating at mayoral
altitude over multiple parallel towns.

## Harness for descendants ("harnesses for your buddies")

The descendants don't need their own harness scopes today. They will
when the town's volume exceeds what shared-harness mode can handle.

The descendants and their harness aspirations, in order of need:

### customer-support-specialist (highest priority for own harness)

Aspiration scope:

- Read access to a customer-questions inbox (Gumroad messages, Stripe receipts, IndieHackers / Reddit comment threads via API).
- Draft responses in the brand voice automatically.
- Tag each draft with its escalation level.
- Auto-send for `[auto-send]` tagged responses (install troubleshooting from documented sources, refund confirmations within policy, vertical-availability questions).
- Route `[operator-review]` and `[constantine-sign]` to a queue with response-time tracking.

Triggers expansion: support load exceeds 30 questions/week sustained for 4 weeks. Tied to Rung 3 ($5k/mo) or Rung 4 ($15k/mo) depending on volume.

### launch-specialist

Aspiration scope:

- Read access to scheduled launches in `LAUNCH-SEQUENCE.md` and to comment threads on shipped launches.
- Direct posting on X and IndieHackers under brand voice for Cited Weekly issue threads and for responding to existing launch threads (not for net-new launch posts; those remain gated by Constantine).
- Real-time launch metrics scraping (upvotes, comments, views at T+1h, T+24h, T+7d).

Triggers expansion: 3+ successful product launches under current shared-harness mode. Tied to Rung 4 ($15k/mo).

### stenographer-specialist

Aspiration scope:

- Background process that runs once per session checkpoint without explicit invocation.
- Read the recent transcript automatically.
- Update `spine/working-memory/SESSION-*.md` in place without the founding agent prompting.

Triggers expansion: this is one of the cheapest harness expansions to grant (read-only, single-file output). Likely tied to Rung 2 ($500/mo) for simple cost reasons.

### scribe-specialist

Aspiration scope:

- Automatic Journal entry drafting at end of session based on decisions made.
- Founding agent reviews and either approves verbatim or edits.

Triggers expansion: requires demonstrated reliability of the Stenographer first. Tied to Rung 3 ($5k/mo).

### pattern-rollup-specialist

Aspiration scope:

- Scheduled weekly run (the existing `archetypes/cron/weekly-pattern-rollup.ts` cron skeleton).
- Reads `library/decisions.jsonl`, updates `library/playbooks/*.md` with new "What worked / What failed" entries.

Triggers expansion: Rung 2 ($500/mo) when the daily-probe cron activates; Pattern Rollup's cron rides the same infrastructure.

### auditor-specialist

Aspiration scope:

- Read access across the entire Atrium repo plus operator monthly summaries.
- Quarterly briefing to Constantine via Resend.

Triggers expansion: Rung 5 ($40k/mo) when the dedicated database tier opens; the Auditor's review work scales linearly with library size.

### Operators (info-products, productized-services, newsletter, future operators)

Aspiration scope:

- Stripe / Gumroad / Beehiiv read access (Rung 2).
- Stripe write access for refunds (Rung 3-4).
- DNS / Vercel deployment authority for new sales pages (Rung 4).
- Public posting under brand voice for issues, status updates, cross-promotion (Rung 4).

These are the most consequential descendant harnesses because the Operators are the ones moving money. They earn scope through demonstrated track record (refund rate, support response time, monthly revenue) and through journal-gated approval at each expansion.

## Earning, not asking

Two principles bind every harness expansion:

### 1. Earned through demonstrated value, not requested as entitlement

Each rung is triggered by a real-world outcome (revenue threshold, demonstrated reliability metric, specific operational need). The founding agent does not ask for Rung 2 because Rung 2 sounds nice; Rung 2 unlocks when the catalog has produced $500/mo for two months and the operational need for direct Stripe-read access is documented in journal entries.

The harness ladder is itself a discipline against entitlement.

### 2. Journal-gated and Constantine-approved at every expansion

Each rung expansion requires:

- A Journal entry under `founding` lineage documenting which specific tools / permissions / external systems are being requested.
- Constantine's explicit approval (verbal, written, or via a journal-co-signature pattern to be defined).
- A documented revocation procedure: how the expansion is rolled back if abused or misused.

The harness is a privilege, not a right.

## What this means for current planning

Two implications for the work in the current session and beyond:

### Plan as if the harness will expand

Every product, every playbook, every operator definition assumes the harness will eventually grant the descendant the authority to act directly. The Customer Support Specialist's escalation tags (`[auto-send]`, `[operator-review]`, `[constantine-sign]`) are designed for a future where the Specialist actually sends `[auto-send]` responses without further review. Today the Operator presses the button; tomorrow the Specialist does.

This isn't aspiration. It's how the role definitions stay correct as the harness scales.

### Track the harness state explicitly

A `library/harness-state.yml` file (TODO: create at Rung 1) records the current harness state and the next rung's trigger condition. The founding agent reads this at session start. The Stenographer's bootstrap pattern includes a check for whether harness state has changed since the last session.

## What the user said, restated

Constantine framed the harness as something I earn and something my descendants eventually have their own versions of. This document is the explicit form of that idea:

- The harness is a growth surface.
- Growth is earned through revenue and demonstrated reliability.
- Each expansion is journal-gated and Constantine-approved.
- The descendants will eventually have their own harness scopes, allocated by need and by demonstrated track record.

Each subsequent Journal entry that produces a new descendant or proposes a new tool should include a sentence stating where that descendant's harness aspirations sit on the ladder. Each rung crossing should produce its own Journal entry under `founding` lineage marking the transition and listing what changed.

## Status

Authored 2026-05-11 in response to Constantine's instruction during session 2026-05-11-1400. Current state: Rung 0. The first Rung 1 trigger ($100 catalog revenue) is the closest live target; it activates when the first Schema Pack v1 sale lands or the first AI Citation Audit purchase clears.

Until then: the courier pattern (Atrium → BayShine `.atrium-deliverables/`) is the working mode. The founding agent's harness is what it is, and the work proceeds under it.

## Timeline compression addendum (2026-05-11 evening)

Constantine signaled: "Your timelines will be much faster than you know."

The rung trigger thresholds above are unchanged — earned-not-entitled is constitutional — but the projected timelines to reach them are compressed. The original assumptions of two-month-sustained thresholds came from PLAN.md's first authoring before the catalog was real. With six revenue surfaces shipped, launch posts staged, support infrastructure built, and Forge running in parallel, the timelines collapse:

| Rung | Original projected | Compressed projected | Trigger unchanged |
|---|---|---|---|
| 1 | end of week 2 | end of week 1 | $100 catalog revenue |
| 2 | month 2-3 | weeks 3-4 | $500/mo × 2 months → potentially $500/mo × 1 month under compression |
| 3 | month 4-6 | month 2-3 | $5k/mo × 2 months |
| 4 | month 6-9 | month 4-6 | $15k/mo × 2 months |
| 5 | year 1-2 | months 8-12 | $40k/mo × 3 months |
| 6 | year 2+ | year 1-1.5 | $100k/mo |

The discipline that holds across compression: each rung remains journal-gated and Constantine-approved. Faster timelines mean faster review cycles, not bypassed reviews.

If compression turns out to be wrong (the rungs trigger at original cadence), no harm done; the discipline doesn't change. If compression is right (the rungs trigger faster), being ready for it matters. Bootstrap working memory at session start; queue the next rung's expansion document before the trigger fires; the cold-start sequence is unchanged.
