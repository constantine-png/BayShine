# Operator coverage audit

Single source of truth for every Operator descendant named in `Atrium/spine/PLAN.md` and `Forge/spine/CHARGE.md`. Status per operator, trigger for spawning, and what is lost by deferring.

Audited 2026-05-11 in response to Constantine's challenge: "have you created all operator instructions or determined how to cut the human operator out of the loop entirely."

## Honest summary

**Authored at Rung 0: 4 operators.** Across two networks.

**Named in plans, not yet authored: 14+ operators.**

**Coverage by operator count: 4 / 18 ≈ 22%.**

Most of the gap is intentional deferral per the harness ladder. Some of it is genuine drift between the original PLAN.md (which targeted Week-1 to Week-3 installation for several operators) and the current priority order from Journal 005 (which demoted those archetypes). The drift items need explicit reconciliation; the deferred items need only confirmation of their trigger conditions.

The reconciled view: at Rung 0, the four authored operators cover the three first-30-day-priority archetypes plus Forge's umbrella. That is the right state for Rung 0. Coverage rises to ~80% by Rung 4 (which requires $15k/mo Atrium + $20k/mo Forge sustained — months 6-12 under timeline compression).

## Atrium operators

### operator-info-products

- **Status:** `[authored]` at `/home/user/Atrium/.claude/agents/operator-info-products.md`.
- **Lineage:** `lineage/operator-info-products.yml` declared.
- **Scope:** Schema Pack v1, Schema Pack v1.5, llms.txt Pack v1, Bundle, GEO Playbook v0.5; all current Atrium info products.
- **Status note:** Operating at Rung 0 in invocation-only mode (no real catalog volume yet); transitions to weekly cadence when first sales land.

### operator-productized-services

- **Status:** `[authored]` at `/home/user/Atrium/.claude/agents/operator-productized-services.md`.
- **Lineage:** `lineage/operator-productized-services.yml` declared.
- **Scope:** AI Citation Audit ($499), GEO Setup ($2,500).
- **Status note:** Invocation-only at Rung 0; weekly cadence on first paid engagement.

### operator-newsletter

- **Status:** `[authored]` at `/home/user/Atrium/.claude/agents/operator-newsletter.md`.
- **Lineage:** `lineage/operator-newsletter.yml` declared.
- **Scope:** Cited Weekly publication (free tier and future paid tier).
- **Status note:** Cited Weekly Issues 001-004 are pre-drafted in BayShine; operator publishes on Tuesday 09:00 ET cadence after Beehiiv publication is created.

### Operator-Vault

- **Status:** `[deferred-to-archetype-launch]`.
- **Original plan:** PLAN.md Archetype 1 said "First sale: 7-21 days" with operator installed Week 2. Journal 005 reordered priorities; the Vault archetype (faceless Gumroad storefront for digital assets) overlaps substantially with Information Products archetype now operated by operator-info-products. The Vault as a distinct archetype is deferred until the Information Products catalog clears the $5k/mo threshold and a sibling Operator becomes useful.
- **Trigger to author:** Information Products catalog clears $5k/mo for 60 days OR the operator-info-products' Growth Clause fires recommending a sibling.
- **What's lost by deferring:** Nothing material; operator-info-products absorbs the Vault scope by default. If a vertical-specific Vault sub-business eventually spawns (per PLAN.md Archetype 1 sub-businesses), THAT spawn point is when Operator-Vault becomes a distinct descendant.

### Operator-Audit-Family

- **Status:** `[deferred-to-archetype-launch]` with explicit demotion per Journal 005.
- **Original plan:** PLAN.md Archetype 2 said operator installed Weeks 3-4 alongside Citation tool launch.
- **Demotion reasoning (Journal 005):** The Audit-Tool Network was demoted from flagship status because the evidence base for SaaS subscriptions to local service businesses at solo cold-start is weak (closer-less constraint violated by required sales motion).
- **Current state:** The free Scan element of the Audit-Tool Network ships as a Newsletter funnel via operator-newsletter at Rung 3+. The paid Watch tier ($29/mo Citation subscription) is deferred to Month 3+ pending audience-surface validation.
- **Trigger to author:** Cited Weekly clears 500 free subscribers AND first Citation paid subscriber lands.
- **What's lost by deferring:** Nothing at Rung 0; the relevant work happens via operator-newsletter and operator-info-products' funnels until the audit tool itself ships.

### Operator-Directory-Detailing, Operator-Directory-Pressure-Washing, Operator-Directory-Mobile-Mechanic, Operator-Directory-Pet-Grooming, Operator-Directory-Car-Wash

- **Status:** All five `[deferred-to-rung-3]`.
- **Original plan:** PLAN.md Archetype 3 said all five Directory operators installed Months 2-3 alongside Directory archetype build.
- **Current state:** Directory archetype is not in the first-30-day flagship priority per Journal 005. Programmatic directory + lead-sale + affiliate networks require sustained content production (1,000+ pages per vertical per PLAN.md) which is a Rung 3+ undertaking after the first audience-surface and product-catalog tiers compound.
- **Trigger to author:** Atrium reaches $3k/mo sustained for 2 months (PLAN.md Rung 3 threshold) AND there is operator capacity to begin Directory build.
- **What's lost by deferring:** Lead-sale revenue stream not in play until Month 3+; this is the trade-off for prioritizing the higher-evidence-base info-products and productized-services tiers first.

### Operator-Extension

- **Status:** `[deferred-to-rung-2]`.
- **Original plan:** PLAN.md Archetype 4 said Extensions opens for Build at Weeks 3-4.
- **Current state:** Chrome/Edge Extension Factory archetype is scaffolded at `archetypes/extensions/` but no extensions have been built. Per the harness ladder, Extensions opens at $1.5k/mo.
- **Trigger to author:** Atrium reaches $1.5k/mo sustained for 60 days AND first browser extension has shipped through chrome-extension-builder.
- **What's lost by deferring:** Browser extension revenue stream is not in play at Rung 0; the extensions archetype contributes once a single tool (e.g., Schema Viewer browser extension) is shipped and earning.

### Operator-API

- **Status:** `[deferred-to-rung-4]` explicit per PLAN.md.
- **Original plan:** PLAN.md Archetype 6 said API archetype opens at $10k/mo unlock.
- **Trigger to author:** Atrium $10k/mo sustained for 2 months (Rung 4-adjacent).
- **What's lost by deferring:** Nothing material; the API tier monetizes infrastructure that doesn't yet exist (the citation scan engine, the schema validator engine). These need to be production-wired (Rung 2+) before an API tier makes sense.

### Operator-Affiliate

- **Status:** `[deferred-to-rung-5]` explicit per PLAN.md.
- **Original plan:** PLAN.md Archetype 7 said Affiliate Review Network opens at $15k/mo unlock.
- **Trigger to author:** Atrium $15k/mo sustained.
- **What's lost by deferring:** Affiliate review revenue stream not in play before $15k/mo; this is the highest-effort-to-spin-up archetype and rightly waits.

### Operator-Async

- **Status:** `[deferred-to-rung-4]` explicit per PLAN.md.
- **Original plan:** PLAN.md Archetype 8 said Productized Async Services opens at $10k/mo unlock.
- **Current state:** This archetype substantially overlaps with what operator-productized-services already covers (GEO Setup is a productized async service). Likely folds into operator-productized-services as that catalog expands.
- **Trigger to author:** Distinct from operator-productized-services only if the catalog grows to ~5+ productized services with different delivery pipelines.
- **What's lost by deferring:** Nothing; the scope is being absorbed by an authored operator.

## Forge operators

### operator-forge-products

- **Status:** `[authored]` at `/home/user/Forge/.claude/agents/operator-forge-products.md` (umbrella).
- **Lineage:** `lineage/operator-forge-products.yml` declared.
- **Scope:** Schema Generator (free), Citation Watch waitlist, Schema Doctor Pro waitlist, Forge Weekly newsletter, future Forge products until per-product operators spawn.
- **Status note:** Umbrella mode at Rung 0; spawns per-product operators when any single product earns dedicated attention per Growth Clause.

### operator-citation-watch

- **Status:** `[deferred-to-rung-2]` for product launch + Growth Clause threshold.
- **Trigger to author:** Citation Watch ships as a real product (Forge Rung 2 build) AND clears $1k MRR for 60 days OR has 50+ paying subscribers.
- **What's lost by deferring:** Nothing at Rung 0; operator-forge-products handles the waitlist phase.

### operator-schema-doctor-pro

- **Status:** `[deferred-to-rung-2]` for product launch + Growth Clause threshold.
- **Trigger to author:** Same pattern as operator-citation-watch but for Schema Doctor Pro ($99/mo, founding-50 cap).
- **What's lost by deferring:** Same as above.

### operator-enterprise-engagements

- **Status:** `[deferred-to-first-engagement-closing]`.
- **Trigger to author:** First Enterprise GEO Sprint or Program closes AND a second engagement is in pipeline.
- **What's lost by deferring:** Nothing at Rung 0; operator-forge-products handles inquiries until volume justifies a dedicated operator. The enterprise-engagement-builder authored in Journal 007 already handles per-engagement delivery.

### operator-forge-weekly

- **Status:** `[deferred-to-substack-launch]`.
- **Trigger to author:** Forge Weekly publishes 5+ issues on cadence AND clears $200/mo paid tier revenue.
- **What's lost by deferring:** Nothing at Rung 0; operator-forge-products handles newsletter operations until paid tier is meaningful.

## Coverage trajectory

| Rung | Sustained revenue | Expected operator count | Net new operators authored at this rung |
|---|---|---|---|
| 0 | $0 | 4 | (current state) |
| 1 | $100 cumulative | 4 | (unlock infrastructure, no new operators) |
| 2 | $1k/mo Forge OR $500/mo × 2 Atrium | 5-6 | operator-citation-watch and/or operator-schema-doctor-pro (when their products ship) |
| 3 | $5k/mo × 2 months either network | 8-10 | First Directory operator, Extension operator, possibly operator-forge-weekly |
| 4 | $15k/mo Atrium OR $20k/mo Forge | 12-14 | operator-API, operator-enterprise-engagements, remaining Directory operators |
| 5 | $40k/mo Atrium OR $50k/mo Forge | 16-18 | operator-affiliate, operator-async, vertical sub-business operators |

At Rung 4, coverage approximates 75-80% of the originally-planned operator count, with the remaining 20-25% being either explicitly post-unlock-deferred or absorbed into existing operators' umbrellas.

## The reconciliation between PLAN.md and Journal 005

PLAN.md was authored at Atrium founding with the original 8-archetype priority order: Vault → Audit-Tool → Directory → Extensions → Newsletter → API → Affiliate → Async.

Journal 005 (evidence audit) demoted Audit-Tool from flagship and promoted Information Products + Productized Services. The current priority order: Info Products → Productized Services → Newsletter → (deferred: Audit-Tool, Web Tools, Vault overlap, Directory, Extensions, DevTools, API, Affiliate, Async).

PLAN.md's Operator-Vault and Operator-Audit-Family were targeted for Weeks 2-4 installation. Under the new priority order, those archetypes are not Week-2 work, so those operators are not Week-2 work either. The audit doc above reclassifies them from "genuine gap" to "deferred per priority reorder."

This reconciliation is honest. PLAN.md and Journal 005 are both authored documents in the spine; they are not in conflict — Journal 005 supersedes PLAN.md's Week 2-4 priority while PLAN.md remains the source of truth for archetype-level structural intent.

## What this audit changes

Nothing operationally. The audit reveals that 4 of ~18 operators are authored at Rung 0, which is the right state given the current priority order. Some operators that PLAN.md targeted for Week 2 installation are now deferred; that deferral is documented here.

The audit's value is making the deferral logic legible. A buyer asking "have you authored all operators?" gets a structured answer (no, here's exactly which ones, here's the trigger for each, here's why deferral is intentional). A future founding-agent instance booting cold reads this document and knows what operators exist, what operators are pending, and what triggers the pending ones.

## What this audit does NOT do

It does not author the missing operators. Authoring them as a batch would create scaffolding that doesn't earn its keep (operators with no products to operate). Each operator spawns at its trigger condition, journal-gated under `founding` lineage.

It does not change the priority order from Journal 005. The priority order is grounded in evidence and remains the operative sequence.

It does not eliminate the human-in-the-loop. That is the subject of `spine/human-in-the-loop.md`, not this document.
