# Playbook — Newsletter (Cited Weekly)

This playbook is the institutional memory of how to ship and
sustain a niche newsletter that compounds the audience surface
for every other archetype in the town. Pattern Rollup updates
this file from `decisions.jsonl` after each issue and each
threshold crossed.

## What this archetype is

A subscription newsletter on Beehiiv, free + paid tiers, written
in the voice of the town. The publication is faceless. Each
issue is drafted from real `library/citations/` deltas, not
invented narrative. The newsletter's primary value is the
audience surface that compounds every other archetype; revenue
from paid subscriptions and sponsored issues is the secondary
value.

## What worked

(Empty until the first 10 issues ship. Pattern Rollup populates.)

## What failed

(Empty until the first failure is logged. Pattern Rollup populates.)

## Phase-3 build template

The Newsletter Builder produces five artifacts per spin-up:

1. **The Beehiiv publication setup** — name, tagline, branding, free tier, paid tier.
2. **The welcome email sequence** — 3 emails (introduction, value preview, paid-tier nudge).
3. **The first three issues** — drafted from real Library data.
4. **The paid-tier value structure** — deep analyses, CSV downloads, Discord access, quarterly report.
5. **The cross-promotion wiring** — Beehiiv Recommends network, Info Products + Productized Services + Audit-Tool Free Scan funnels.

Reference assets:

- `library/playbooks/newsletter.md` (this file).
- `spine/origins/CLAUDE.md` for voice rules.
- `archetypes/newsletter/README.md` for the publication plan.
- The citation-probe descendant for the underlying weekly dataset.

## Issue structure (Cited Weekly)

Each free-tier issue has these sections:

1. **Headline.** Drawn from this week's most consequential citation delta. One sentence, factual, no clickbait.
2. **This Week in Citations.** 3-5 short paragraphs describing what AI engines started or stopped recommending this week, with `library/citations/` row references.
3. **Schema Watch.** What changed in schema.org spec or in major engines' parsing this week. Brief, technical.
4. **Vertical Spotlight.** One vertical, one trend. Rotates weekly through detailing, HVAC, dental, legal, plumbing, roofing.
5. **Reader Action.** One thing to do this week (a free Scan link, a paid-tier upgrade, a vertical-specific resource).

Paid-tier issues add:

6. **Deep Analysis.** Full underlying data for one citation delta from the free issue.
7. **Dataset Download.** CSV slice of the relevant citations data.
8. **Discord Highlights.** Roundup of what paid subscribers discussed.

## Phase-5 distribution channels

1. **Beehiiv Recommends network** — opt-in cross-recommendation with other newsletters in the local-SEO, SMB, and AI-search clusters.
2. **Twitter / X** — one thread per issue, each section becoming one tweet.
3. **r/SEO and r/LocalSEO** — issue summary posted to relevant subreddits when the issue's headline is broadly applicable.
4. **Hacker News** — only for issues with technical depth (schema watch items, citation-probe methodology pieces).
5. **Cross-mention from every Info Products and Productized Services welcome email.**

## Operator runbook stub

operator-newsletter monitors weekly:

- Subscriber count (free + paid).
- Open rate, click rate.
- Paid conversion rate from free subscribers.
- Top-performing section per issue.
- Cross-promotion conversion (issue mentions of Info Products / Services → buyer attribution).
- Reply patterns (used to identify content gaps).

Weekly metrics table is appended to the Operator's running journal entry; monthly summary becomes a Journal entry under the operator lineage.

## Audience thresholds

- **500 free subscribers** → launch paid tier ($9-19/mo).
- **1,000 free + 50 paid for 60 days** → first vertical-specific spin-off newsletter proposal.
- **5,000 free + 250 paid** → first annual industry report ($99-299 one-time download) proposal.
- **10,000 free + 500 paid** → Sponsored-Issue marketplace proposal.

Founding approves spawns and tier launches via Journal entry.

## Sub-business spawn opportunities

When audience thresholds are crossed:

- **Vertical-specific newsletters.** Cited for Detailing, Cited for Dentists, Cited for HVAC. Each is its own Beehiiv publication with its own Operator instance.
- **Annual industry reports.** $99-299 one-time downloads compiled from the year's citation data.
- **Sponsored-Issue marketplace.** Brands pay to reach the audience. Sponsorship slots are gated by founding-Journal authorization.
- **Paid Discord/Slack community** for paying subscribers, $29/mo tier above the standard paid subscription.

## Quality bar (non-negotiable)

- Every statistic traces to a `library/citations/` or `library/decisions.jsonl` entry.
- No invented subscriber counts, open rates, or social proof.
- No founder-cult voice. The publication is faceless.
- Voice from `spine/origins/CLAUDE.md`: direct, restrained, no em-dashes, no exclamation marks.
- Predictions are marked as predictions.
- No paid acquisition until founding authorizes.
- No sponsored issues until founding has authorized the first sponsorship via Journal entry.

## First issue target

Per Journal entry 005: Cited Weekly publication created on Beehiiv. First issue published in week 2 of operations. Lead section drawn from the existing BayShine `discoverability/` artifacts that already document live citation behavior in mobile detailing and adjacent verticals across Pasco and Hillsborough counties.
