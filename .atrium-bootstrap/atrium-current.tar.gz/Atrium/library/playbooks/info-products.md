# Playbook — Information Products

This playbook is the institutional memory of how to ship
information products faster and better than the last spin-up.
Pattern Rollup updates this file from `decisions.jsonl` after
each new product publish.

## What this archetype is

Standalone digital products sold on instant-checkout platforms
(Gumroad / Lemon Squeezy / Stripe Direct) with no sales motion.
The product is the writing. The discoverability specialists
contribute templates, schemas, audits. Time-to-first-dollar
from cold-start: 7 days for a $99 product, faster for a $29
template.

## What worked

(Empty until the first product ships. Pattern Rollup populates.)

## What failed

(Empty until the first failure is logged. Pattern Rollup populates.)

## Phase-3 build template

The Info-Product Builder produces five artifacts per spin-up:

1. **The product itself** — PDF, Notion template, or asset pack.
2. **The listing page** — Gumroad or Lemon Squeezy listing.
3. **The welcome email** — single email triggered on purchase.
4. **The affiliate listing** — 30% commission on the platform's affiliate program.
5. **The cross-link to the Newsletter** — every welcome email includes a Newsletter signup.

Reference assets:

- `library/playbooks/info-products.md` (this file).
- `spine/origins/CLAUDE.md` for voice rules.
- `archetypes/info-products/README.md` for the catalog plan and pricing logic.

## Phase-5 distribution channels (provisional)

Until real distribution data exists, these are the assumed channels in priority order:

1. **IndieHackers** — one post per launch. Title states what the product is and the price; body states what's inside in three bullets. No marketing voice.
2. **r/SEO and r/LocalSEO** — one post per launch, weighted toward whichever subreddit matches the vertical.
3. **Hacker News (Show HN)** — only if the product has technical depth (e.g., the schema generator, the citation probe spreadsheet). Avoid generic "playbook" Show HN posts.
4. **X / Twitter thread** — one thread per launch, each section of the playbook becoming one tweet.
5. **Beehiiv Newsletter cross-mention** — within two weeks of publish, one issue of Cited Weekly mentions the product.

These are revised by Pattern Rollup based on real conversion data after the first three launches.

## Operator runbook stub

operator-info-products monitors weekly:

- Sales per product, week-over-week.
- Refund rate per product.
- Conversion rate from each distribution channel.
- Buyer questions and topics (used to identify product gaps).
- Affiliate sales separately tracked.

Weekly catalog status table is appended to the Operator's running journal entry; monthly summary becomes a Journal entry under the operator lineage.

## Sub-business spawn opportunities

When the archetype has 3 products each clearing $500/mo for 60 days:

- **Sibling products** targeting adjacent buyer pain. (Three products parallel to the top earner.)
- **Subscription template service.** The highest-selling template becomes a $9-19/mo subscription with monthly updates.
- **Paid Discord community** for paying buyers, $19/mo, separate from any Newsletter Discord.

Founding approves spawns via Journal entry.

## Quality bar (non-negotiable)

- No invented testimonials, sales counts, or social proof in any listing or post.
- No marketing voice. Direct, restrained, faceless.
- Every JSON-LD asset in a product passes schema-specialist validation.
- The 7-day refund window is honored automatically; refund rate above 5% on any single product triggers a Journal entry.

## First product target

Per Journal entry 005: "The GEO Playbook for Local Service Businesses" at $99 on Gumroad. 60-80 page PDF. Built from the existing BayShine work as the dogfood case study (anonymized where needed). Target: 50 sales month one = $4,950 gross.

Pre-flight validation: a one-paragraph demand probe posted to IndieHackers and r/LocalSEO BEFORE writing the playbook. If interest is weak, pivot to the Schema Pack at $49 as the first product instead.
