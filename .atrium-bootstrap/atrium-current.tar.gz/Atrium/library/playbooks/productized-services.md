# Playbook — Productized Services

This playbook is the institutional memory of how to ship
productized services faster and better than the last spin-up.
Pattern Rollup updates this file from `decisions.jsonl` after
each new service ships and each new engagement closes.

## What this archetype is

Fixed-price, fixed-scope, fixed-deliverable services sold on a
one-page sales site with Stripe checkout. Buyer pays first,
work starts same day, deliverable lands on the contracted date.
The delivery pipeline orchestrates the five discoverability
specialists against the buyer's site. Time-to-first-dollar from
cold-start: 14 days.

## What worked

(Empty until the first engagement closes. Pattern Rollup populates.)

## What failed

(Empty until the first failure is logged. Pattern Rollup populates.)

## Phase-3 build template

The Productized-Service Builder produces five artifacts per spin-up:

1. **The one-page sales site** — headline, scope, timeline, price, "what this is not," refund policy.
2. **The Stripe Checkout product** — one product, one price, no tiers, webhook wired.
3. **The intake form** — Typeform or Notion form, single page.
4. **The delivery pipeline definition** — documented orchestration of specialists in named order.
5. **The deliverable templates** — executive summary, engagement scope, 30-day re-check.

Reference assets:

- `library/playbooks/productized-services.md` (this file).
- `spine/origins/CLAUDE.md` for voice rules.
- `archetypes/productized-services/README.md` for the catalog plan and unit economics.
- The discoverability specialists in `.claude/agents/`.

## Phase-5 distribution channels (provisional)

Until real distribution data exists, these are the assumed channels in priority order:

1. **IndieHackers** — one launch post per service. Title states the service, price, and turnaround. Body states what is in scope, what is not, and one real case study (or "no case study yet — be the first").
2. **X / Twitter** — one thread per launch, with the sales page screenshot as the lead image.
3. **r/SmallBusiness and r/SEO** — one post per launch, weighted toward whichever fits the buyer profile of the service.
4. **Direct outreach to BayShine-adjacent service businesses** — only after the first paid engagement has produced a case study. Outreach is gated on a real artifact, not cold pitches.
5. **Beehiiv Newsletter cross-mention** — within two weeks of publish, one issue of Cited Weekly mentions the service.

## Operator runbook stub

operator-productized-services monitors weekly:

- Active engagements: count, days remaining on each, blockers.
- Closed engagements: refund rate, average turnaround vs. promised, NPS or satisfaction signal if available.
- Sales pipeline: post-launch engagement velocity per channel.
- Specialist gate pass/fail rate.

Weekly engagement status table is appended to the Operator's running journal entry; monthly summary becomes a Journal entry under the operator lineage.

## Sub-business spawn opportunities

When the archetype has 3 services each clearing $5,000/mo for 60 days:

- **Higher-tier engagement.** $25,000 flat Enterprise-scale package for multi-location service chains.
- **Sibling vertical service.** A productized service for a different vertical (e.g., HVAC, dental) using the same delivery pipeline.
- **Recurring retainer tier.** The highest-converting one-time service gains a $499-999/mo retainer option.

Founding approves spawns via Journal entry.

## Quality bar (non-negotiable)

- 7-day no-questions refund window.
- Late delivery triggers automatic full refund plus Journal entry.
- Engagements $1,500+ require Auditor sign-off before delivery.
- Constantine signs the executive summary on every engagement.
- No discovery calls, no scoping calls, no proposal cycles.

## First service target

Per Journal entry 005: "GEO Setup for Local Service Businesses, $2,500 flat, 10-day turnaround." Sales page deployed to Vercel. Stripe Checkout product configured. Intake form pointing to a Typeform. The delivery pipeline runs: schema-specialist → site-architecture-specialist → geo-ai-search-specialist → internal-linking-specialist → citation-readiness-specialist → citation-probe-specialist → executive summary.

Pre-flight validation: a dry-run of the delivery pipeline against BayShine itself as the dogfood engagement. The resulting deliverable becomes the first case study and gates the public sales page launch.
