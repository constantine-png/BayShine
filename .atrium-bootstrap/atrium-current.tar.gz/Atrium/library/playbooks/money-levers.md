# Money Levers playbook

The explicit map of every revenue lever in the Atrium town. What
each lever does, when to pull it, what it depends on, and what
unit economics to expect. Maintained by the founding agent, refined
by Pattern Rollup from real `decisions.jsonl` data.

The point of this playbook is anti-complacency. Without an explicit
map, the town defaults to whatever lever is most recent. With the
map, the town sees every lever simultaneously and pulls whichever
combination delivers the most revenue per unit of attention given
the current state.

## The seven levers

Atrium revenue comes from exactly seven levers, each with distinct
unit economics and distinct triggers:

1. **Inbound info products** — Gumroad / Lemon Squeezy / Stripe Direct.
2. **Inbound productized services** — Stripe Direct.
3. **Recurring subscriptions** — Newsletter paid tier, future retainers.
4. **Cross-sell at checkout** — Bundle SKUs, post-purchase upsell.
5. **Upgrade pipelines** — Audit → Setup credit, Free → Paid.
6. **Affiliate revenue** — 30% commission for partners on Gumroad.
7. **Sponsorship / partner revenue** — Sponsored newsletter issues, etc. (post-$15k unlock).

Plus two indirect levers that don't directly produce revenue but
enable it:

- **Audience surface** (newsletter free tier) — compounds all seven.
- **Trust surface** (case studies, dogfood site) — compounds 1-3 and 5.

## Lever 1 — Inbound info products

### What

Gumroad / Lemon Squeezy / Stripe Direct sales of standalone digital products. Current catalog: Schema Pack v1 ($29), llms.txt Pack v1 ($9). Future: Schema Pack v2 ($49), llms.txt Pack v2 ($19), GEO Playbook ($99), specialty packs.

### When to pull

- After demand probe signal (Day 6+) confirms category demand.
- After audience exists (newsletter or organic search visibility).
- When new vertical or new format is requested 3+ times.

### Unit economics

- Schema Pack v1 @ $29 × 50 sales/mo = $1,450
- Schema Pack v1 + bundle uptake @ ~25% × 50 = ~12 bundles × $6 incremental = $72
- llms.txt Pack v1 @ $9 × 30 sales/mo (standalone) = $270
- Total month 2 inbound info: $1,792
- Total month 3 (with Schema Pack v2 launched): ~$3,500-$5,000

### Dependencies

- Audience or direct distribution (lever 8 audience, or paid acquisition post-$5k unlock).
- Real validation data (probe data for the verticals).
- Gumroad / Lemon Squeezy / Stripe accounts active.

### Failure mode

If month-1 sales < 20 across the info product catalog, the products aren't reaching their audience. Diagnose:
- Channel wrong? Try a different subreddit, a different X strategy, ProductHunt.
- Price wrong? Test $14 beta tier; observe conversion lift.
- Product wrong? Pivot the vertical mix or the format (PDF vs Notion template).

## Lever 2 — Inbound productized services

### What

Stripe Direct sales of fixed-price, fixed-scope service engagements. Current catalog: GEO Setup ($2,500 / 10 days), AI Citation Audit ($499 / 5 days). Future: Service-Area Page Pack ($1,499), Schema Implementation Lite ($999), AI Search Visibility Retainer ($499/mo recurring).

### When to pull

- After at least one engagement completes (dogfood BayShine as the first, paying customer 2+).
- After the delivery pipeline is documented and tested.
- After case study is publishable (with buyer consent if external).

### Unit economics

- GEO Setup @ $2,500 × 4 sales/mo = $10,000 (month 2 target)
- AI Citation Audit @ $499 × 12 sales/mo = $5,988
- Audit → GEO Setup upgrade @ ~25% × 12 = 3 upgrades × $2,250 = $6,750 (replacing 3 direct GEO Setup sales at $2,500 = $7,500; net delta -$750 in absolute terms but +$750 in audit revenue that wouldn't have existed otherwise; net +$4,500)
- Total month 3 inbound services: $16,488 (with upgrade pipeline net effect)

### Dependencies

- Specialists (the five discoverability specialists are the delivery workforce).
- Auditor descendant (signs off on each delivery $1,500+).
- Constantine signs the executive summary.
- Stripe account, Stripe Tax, Stripe Webhooks.

### Failure mode

If month-1 services < 1 sale, the audience isn't trusting a $499+ commitment. Diagnose:
- No case study? Ship the BayShine case study publicly. First-party data converts.
- Price too high for the early audience? Drop AI Citation Audit to $299 for first 10 buyers, then return to $499.
- Sales page weak? Voice-check, add specific case-study language.

## Lever 3 — Recurring subscriptions

### What

Monthly or annual recurring revenue. Current: Cited Weekly paid tier ($9/mo, launches when free tier >500 subs). Future: GEO Setup retainer ($499/mo), Schema Doctor SaaS ($29/mo, post-$5k unlock), Citation Watch ($19/mo, post-$5k unlock).

### When to pull

- Newsletter paid tier: when free subs > 500.
- Service retainer: when first 5 GEO Setup engagements have shipped and 30-day re-check data is available.
- SaaS tools: post-$5k unlock when Plumbing wires real infrastructure.

### Unit economics

- Newsletter paid @ $9/mo × 50 subs (5% conversion of 1,000 free) = $450/mo
- GEO Setup retainer @ $499/mo × 4 upgrades = $1,996/mo
- Schema Doctor SaaS @ $29/mo × 30 = $870/mo (post-unlock)
- Citation Watch @ $19/mo × 50 = $950/mo (post-unlock)
- Total recurring at $5k unlock: ~$2,500/mo. Compounds to $5,000-$10,000/mo by month 6.

### Dependencies

- Audience for newsletter paid.
- Retainer customer base from GEO Setup graduates.
- Infrastructure (Stripe Subscriptions, churn metrics).

### Failure mode

If newsletter free tier doesn't reach 500 by month 4, the audience surface isn't compounding fast enough. Diagnose:
- Issue cadence too low? Move from weekly to twice-weekly briefly.
- Cross-promotion not working? Audit the conversion funnel from product purchase → newsletter signup.
- Subject matter too narrow? Broaden to adjacent service-business categories.

## Lever 4 — Cross-sell at checkout

### What

Selling additional products in the same purchase flow. Current: Schema Pack + llms.txt Pack bundle ($35, saves $3). Future: "Add the AI Citation Audit to your GEO Setup engagement" upsell at GEO Setup checkout ($499 → free if GEO Setup is purchased; nets $0 but increases perceived value).

### When to pull

- Whenever two complementary products exist that share a buyer.
- Default: enable at the higher-priced product's checkout, never the lower-priced one's (preserves price anchoring).

### Unit economics

- Bundle uptake estimate: 25-40% of Schema Pack v1 buyers add the bundle.
- 25% of 50 monthly Schema Pack buyers = 12.5 bundles
- Bundle net premium = $35 - $29 (Schema Pack) = $6 in incremental revenue, OR $35 - $9 (llms.txt) = $26 from llms.txt-first buyers who upgrade to bundle.
- Most likely path: Schema Pack as the anchor; bundle adds $6 incremental per bundle conversion = $75/mo at month 2.

### Dependencies

- Both products live on the same platform OR a Gumroad bundle SKU.
- Checkout UX that surfaces the bundle without being aggressive.

### Failure mode

If bundle uptake < 10%, the cross-sell is too weak or the price difference is unconvincing. Diagnose:
- Saving $3 isn't enough; increase bundle discount to saves-$5 ($34 bundle).
- Bundle CTA not visible enough; add explicit "Bundle: Schema Pack + llms.txt = $35" mention in Schema Pack listing description.

## Lever 5 — Upgrade pipelines

### What

A defined path from lower-tier purchase to higher-tier purchase. Current: AI Citation Audit → GEO Setup with $250 credit (30-day window). Future: Schema Pack → AI Citation Audit, GEO Playbook → AI Citation Audit (post-Playbook launch), Free newsletter → Paid newsletter, GEO Setup → Retainer.

### When to pull

- Whenever a buyer of product A is a natural buyer of product B.
- Whenever there's a credit mechanic that converts perceived purchase into a step-toward-decision.

### Unit economics

- Audit → GEO Setup upgrade @ 25% × 12 audits = 3 upgrades.
- Each upgrade = $2,250 (GEO Setup price - $250 credit).
- 3 upgrades = $6,750/mo (this is GROSS; replaces direct GEO Setup sales).
- Per-buyer LTV is the lever: Audit-only buyer LTV = $499. Audit+Upgrade buyer LTV = $499 + $2,250 = $2,749. Upgrade pipeline raises LTV by 5.5x for the converted portion.

### Dependencies

- Both products exist.
- The upgrade credit mechanic is documented in the delivery email (already in WELCOME-EMAIL.md for both products).
- Tracking: the GEO Setup intake form asks "did you previously buy the AI Citation Audit?" If yes, $250 credit applied.

### Failure mode

If upgrade conversion < 10%, the audit buyer isn't seeing GEO Setup as the natural next step. Diagnose:
- Delivery email's GEO Setup mention too soft? Make it more direct.
- Audit report doesn't surface the implementation gap explicitly? Each remediation list item should include "this is what GEO Setup would handle for you" footnote.
- Buyers feel locked-in if they upgrade? Make the credit truly no-strings (no auto-renewal, no obligation).

## Lever 6 — Affiliate revenue

### What

30% commission to partners who refer a sale on Gumroad. Currently enabled on Schema Pack v1 and llms.txt Pack v1 but no partners recruited yet.

### When to pull

- When the product has sold 25+ direct units (proves the product works).
- When potential affiliates have an audience aligned with the product (local-SEO bloggers, indie hacker newsletters, schema-org tutorial writers).
- When there's an explicit affiliate-asset kit (banner images, suggested copy, the Atrium voice rules).

### Unit economics

- Affiliate commission: 30% of $29 = $8.70 per Schema Pack sale.
- Affiliate commission: 30% of $9 = $2.70 per llms.txt Pack sale.
- A meaningful affiliate (driving 10-20 sales/mo across both products) earns $100-$300/mo. Affiliates with bigger audiences earn more.
- Atrium retention per affiliate sale: $20.30 (Schema Pack) or $6.30 (llms.txt Pack).
- If 5 active affiliates each drive 10 sales/mo, that's 50 additional sales = $850/mo additional gross to Atrium (after commission).

### Dependencies

- Gumroad affiliate program enabled (already on).
- Affiliate-asset kit (not yet authored).
- Affiliate recruitment outreach (future Affiliate Recruiter descendant).

### Failure mode

If affiliate recruitment doesn't yield active affiliates after 60 days of outreach, the audience for the products doesn't have natural affiliates (the audience isn't where the products are visible). Pivot: recruit affiliates from the buyer base instead of cold outreach.

## Lever 7 — Sponsorship / partner revenue

### What

Sponsored issues of Cited Weekly newsletter, sponsored sections of the Atrium content site, partner-paid product mentions. Voice-rule-bound (no advertising voice, no false claims).

### When to pull

- Newsletter audience > 1,000 free subscribers.
- Founding agent has approved the specific sponsor via Journal entry.
- The sponsor's offering is genuinely useful to the audience (not a generic SaaS spammer).

### Unit economics

- Sponsored issue rate: $250-$1,000 per issue depending on audience size.
- At 1,000 subscribers: $250 per sponsored issue.
- At 5,000 subscribers: $1,000+ per sponsored issue.
- One sponsored issue per month max (preserves editorial integrity).
- Annual industry report sponsorship: $5,000-$25,000 (post-$15k unlock when reports exist).

### Dependencies

- Audience.
- Editorial reputation (every prior issue has been useful, not promotional).
- A sponsor whose product passes the founding agent's voice and ethics check.

### Failure mode

If a sponsorship erodes editorial trust, the audience leaves. Recovery: pause sponsorships, refund the sponsor, publish a transparent issue explaining the misstep.

## Indirect lever — Audience surface

### What

The newsletter free tier (Cited Weekly), the Atrium content site (TODO: build at `atrium.<domain>`), any organic search visibility we earn over time.

### Why it matters

Every direct lever's unit economics multiply by audience size. A 100-subscriber list converts a different percentage to a $29 product than a 10,000-subscriber list does, even at the same conversion rate, because the gross number is 100x.

### When to pull

Always. The audience surface has no off switch. The cadence is the cadence.

### Dependencies

- Newsletter Operator running weekly.
- Each issue is genuinely useful (anti-complacency: every issue must teach something).
- Cross-mentions in product welcome emails.

## Indirect lever — Trust surface

### What

The BayShine Detailing site (dogfood), case studies from completed engagements, public probe data, the Cited Weekly back-catalog.

### Why it matters

Cold buyers convert against trust signals. A $2,500 GEO Setup engagement converts at a different rate when there's a public case study showing real before/after data than when there's only a sales page.

### When to pull

- After every paid engagement: a case study within 30 days (with buyer consent).
- After every Cited Weekly issue: the issue becomes back-catalog.
- After every product launch with real sales: the product becomes evidence the catalog converts.

### Dependencies

- The catalog actually delivers (quality bar).
- Buyer consent on case studies.
- The Atrium content site exists to host case studies (TODO).

## Lever combinations and stacking

The levers don't operate in isolation. The most powerful combinations:

### Combo A — The audit-to-setup engine

Lever 2 (productized service) + Lever 5 (upgrade pipeline) + Lever 8 (audience).

An audit buyer at $499 has a 25% upgrade rate to GEO Setup at $2,250. The combined LTV is 5.5x audit-only LTV. Driving audit volume drives setup revenue.

Volume multiplier: Lever 8 (audience). Each newsletter issue that mentions the audit drives ~1-3% click-through; 1,000 subs × 2% × 5% conversion = 1 audit per issue from the newsletter alone.

### Combo B — The bundle stack

Lever 1 (info product) + Lever 4 (cross-sell) + Lever 6 (affiliate).

Schema Pack v1 buyer gets bundle offer at checkout (25-40% uptake). Bundle is 30% commission to affiliates. Affiliate drives both standalone and bundle sales.

Net per affiliate sale on bundle: $35 × 70% = $24.50 to Atrium.

### Combo C — The newsletter compounding flywheel

Lever 3 (recurring) + Lever 4 (cross-sell within issues) + Lever 8 (audience).

Newsletter free tier compounds audience. At 500 subs, paid tier launches at $9/mo. At 1,000 subs, sponsorship lever opens. At 5,000 subs, annual report sponsorships open at $5,000+.

The newsletter is the only lever that compounds across all other levers.

## When to NOT pull a lever

Critical anti-complacency rules:

- **Do not pull paid acquisition** before $5k/mo unlock. Cold ads burn capital before LTV is known.
- **Do not pull sponsorship** until audience > 1,000. Sponsored content to a small audience reads as spam and erodes the editorial trust that makes audience grow.
- **Do not pull custom-engagement** for inquiries < $1,000 differential from productized pricing. Custom kills productized margin.
- **Do not pull affiliate recruitment** before the product has 25+ direct sales. Recruiting affiliates for an unvalidated product wastes their effort and ours.
- **Do not pull retainers** before 5+ GEO Setup engagements have shipped. Retainer pricing requires data on what monthly maintenance actually costs.

## Cadence

The Money Levers playbook is revisited:

- Monthly by the founding agent during the operators' monthly summary review.
- Quarterly by the Auditor during the constitutional drift review.
- Whenever a new product launches.
- Whenever a lever's unit economics deviate >20% from projected (in either direction).

When revised, the changes appear in a Journal entry under `founding` lineage, and `library/playbooks/money-levers.md` is updated in the same commit.

## The honest projection

At month 3, assuming reasonable execution against the cumulative catalog:

| Lever | Source | Month 3 estimated |
|---|---|---|
| 1 | Schema Pack v1 + llms.txt Pack + Schema Pack v2 launch | $3,500-$5,000 |
| 2 | GEO Setup + AI Citation Audit | $12,000-$18,000 |
| 3 | Newsletter paid tier (if launched) | $0-$450 |
| 4 | Bundle uptake | $75-$200 |
| 5 | Audit → Setup upgrades | (already counted in lever 2) |
| 6 | Affiliate revenue | $0-$200 |
| 7 | Sponsorship | $0 (audience not yet at threshold) |
| **Total** | | **$15,575-$23,850** |

Mid-point: ~$19,700/mo at month 3. Crosses the $15k Constantine-pay threshold; near the $20k escape-velocity threshold from PLAN.md.

This is not a promise. It is the architecture's stated capacity at the current lever set. The probability of hitting it depends on launch execution (lever 1 and 2), audience growth (indirect lever 8), and quality bar maintenance (indirect lever 9, trust surface).

The architecture supports more if the levers stack right. Combo A alone at scale = $10k-$20k/mo. Combo B at scale = $1k-$3k/mo. Combo C at month 6+ = $5k-$15k/mo.

The point of writing the levers down is: nothing in this catalog is single-lever. Pulling lever 2 without lever 8 leaves money on the floor. Pulling lever 1 without lever 4 leaves money on the floor. The architecture is the leverage.
