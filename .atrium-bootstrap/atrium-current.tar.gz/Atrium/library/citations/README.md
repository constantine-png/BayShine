# Citations dataset

Every AI-engine probe result, ever. The proprietary dataset.

## Schema (target Postgres table)

```
citations
  id              uuid primary key
  date            timestamptz
  engine          text  -- claude | gpt | perplexity | gemini
  query           text  -- exact prompt sent
  vertical        text
  geo             text  -- nullable
  domain          text  -- domain we are asking about (nullable for
                  --     general probes)
  result          text  -- raw model output
  result_summary  text  -- structured: was the domain mentioned,
                  --     ranked, described as
  lineage         text  -- which descendant ran the probe
  cost_usd        numeric(10, 4)
```

## Pre-Postgres storage

Until the $500/mo unlock crosses, citations live as JSONL files
per domain/vertical/geo:

- `citations/general/<vertical>-<geo>.jsonl` for general probes
  not tied to a specific domain.
- `citations/domain/<domain-slug>.jsonl` for per-domain probes.

One JSON object per line, matching the schema above.

## Access

Read access: every descendant. The Library is the shared brain.

Write access: the Citation Probe descendant.

## Retention

Indefinite. The longitudinal value of this dataset compounds with
time. Storage cost is negligible compared to its strategic value.
