# Operator monthly summary template

Filled in on the last business day of each month by each permanent
Operator (operator-info-products, operator-productized-services,
operator-newsletter, etc.). The completed summary becomes a Journal
entry under the operator's lineage.

The summary is short by design. Long monthly reports decay into
ceremony; this one fits on one screen.

---

## Header

```yaml
operator: <operator-name>
month: <YYYY-MM>
catalog_under_management:
  - product_slug: <slug>
    archetype: <archetype>
    price_usd: <number>
```

## 1. Revenue (real numbers from Stripe / Gumroad / Beehiiv dashboards)

| Product | Units sold | Gross revenue | Refunds | Net revenue |
|---|---|---|---|---|
| | | | | |
| | | | | |
| **Total** | | | | |

Compare to prior month: ___ % change.

If revenue dropped > 20% MoM, the "what changed" section below MUST identify the cause.

## 2. Support load

| Category | Count | Average response time | Outliers |
|---|---|---|---|
| Install questions | | | |
| Refund requests inside policy | | | |
| Refund requests outside policy | | | |
| Custom-quote inquiries | | | |
| Other | | | |

Refund rate by product: ___ % (flag if > 5% on any single product).

## 3. What changed

Three bullets max. Concrete operational decisions made this month, each one a 1-line description with a `decisions.jsonl` reference.

- [decision row id] _what_
- [decision row id] _what_
- [decision row id] _what_

## 4. What I'm proposing for next month

Three proposals max. Each one a 2-line description: the proposed change, the expected effect, the trigger that authorizes it.

The founding agent reviews these and approves via reply or via a follow-up Journal entry.

- ___
- ___
- ___

## 5. Growth Clause check

Does the catalog state meet the Growth Clause threshold for child-business spawn?

- [ ] Yes — propose child-business in a separate Journal entry under this lineage.
- [ ] No — current revenue / sustainability does not meet the threshold (specify which threshold and current state).

## 6. Risks identified

- ___
- ___

## 7. Closing note

One sentence on what next month's focus is.

---

# Sample fill-in (for reference, not for copy)

```yaml
operator: operator-info-products
month: 2026-06
catalog_under_management:
  - product_slug: schema-pack-v1
    archetype: info-products
    price_usd: 29
  - product_slug: llms-txt-pack-v1
    archetype: info-products
    price_usd: 9
  - product_slug: schema-llms-txt-bundle
    archetype: info-products
    price_usd: 35
```

| Product | Units | Gross | Refunds | Net |
|---|---|---|---|---|
| Schema Pack v1 | 42 | $1,218 | 1 ($29) | $1,189 |
| llms.txt Pack v1 | 27 | $243 | 0 | $243 |
| Bundle | 11 | $385 | 0 | $385 |
| **Total** | 80 | $1,846 | $29 | $1,817 |

Compare to prior month: +47% MoM (first full sales month).

Support load:

| Category | Count | Average response | Outliers |
|---|---|---|---|
| Install questions | 12 | 3.2h | 1 buyer needed 3 follow-ups (WordPress plugin conflict) |
| Refunds inside policy | 1 | <1h | none |
| Outside policy | 0 | n/a | n/a |
| Custom quote | 4 | 6.8h | none |
| Other | 8 | 2.1h | 2 agency white-label inquiries |

Refund rate: 1.25%.

What changed:

- [DR-2026-06-08] Reduced llms.txt Pack INSTALL.md Webflow workaround from 4 steps to 2 after 3 buyers reported the original was confusing.
- [DR-2026-06-15] Bundle CTA moved to top of Schema Pack v1 listing description after observing 18% to 26% bundle uptake increase.
- [DR-2026-06-22] Auto-responder added for "is this AI-generated" question (asked 5 times this month).

What I'm proposing:

- Ship Schema Pack v2 with 18 additional verticals at $49. Trigger: bundle uptake > 25% sustained for 2 months proves the catalog converts. Expected effect: +60% catalog revenue if same conversion rate applies.
- Reduce llms.txt Pack v1 standalone price from $9 to $7 to test whether $9 is a price ceiling on the impulse-buy tier. Expected effect: net revenue flat or slightly up; bundle uptake unaffected.
- Launch first affiliate recruitment pass to 10 local-SEO bloggers. Expected effect: 30% commission × ~10 referred sales/mo = $50-$80/mo net to Atrium.

Growth Clause check: 3 products clearing $500/mo — no, only Schema Pack v1 clears ($1,189). Not at threshold yet. Re-check next month.

Risks:

- WordPress 6.X update broke one customer's plugin pipeline; verified our schema injection still works but added a smoke test for future WP updates.
- Bundle SKU pricing on Gumroad doesn't natively support "ungrade existing customer" flow; using a manual checkout link as the workaround. If volume exceeds 5/month, the workaround becomes ops-heavy.

Closing note: next month's focus is Schema Pack v2 ship plus first affiliate recruitment. Audit of Schema Pack v1 conversion rate by traffic source pending newsletter cross-promotion data.
```
