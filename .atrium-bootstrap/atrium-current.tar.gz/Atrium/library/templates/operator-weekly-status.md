# Operator weekly catalog status template

Filled in once per week by each permanent Operator and appended to
the Operator's running journal entry (not a new Journal entry per
week; one running entry per quarter that accumulates the weekly
status table).

Goal: a one-screen view of catalog state that the founding agent
can read in under 60 seconds.

---

## Week of <YYYY-MM-DD>

### Catalog status

| Product | Units this week | Trending | Issues | Action |
|---|---|---|---|---|
| | | ↑ ↓ → | | |

`Trending` is the symbol: ↑ if > 10% above 4-week average, ↓ if > 10% below, → if within ±10%.

`Issues` is one of: `clean`, `support load high`, `validation failure cluster`, `refund spike`, `price elasticity test in progress`, `awaiting decision`.

`Action` is the next operator action this week: `nothing`, `respond to backlog`, `update INSTALL.md`, `escalate to founder`, etc.

### Inbox

| Type | Open | In progress | Closed this week |
|---|---|---|---|
| Support tickets | | | |
| Refund requests | | | |
| Custom-quote inquiries | | | |
| Agency / partnership | | | |
| Press / partner | | | |

### Decisions made this week

Bulleted, each with a `decisions.jsonl` row reference.

- [DR-id] _what_
- [DR-id] _what_

### Watching for next week

- ___
- ___

---

# Filled example (for reference)

## Week of 2026-06-09

### Catalog status

| Product | Units this week | Trending | Issues | Action |
|---|---|---|---|---|
| Schema Pack v1 | 11 | ↑ | clean | nothing |
| llms.txt Pack v1 | 7 | → | clean | nothing |
| Bundle | 3 | ↑ | clean | nothing |

### Inbox

| Type | Open | In progress | Closed |
|---|---|---|---|
| Support tickets | 0 | 2 | 4 |
| Refund requests | 0 | 0 | 1 (in policy, auto-approved) |
| Custom-quote inquiries | 1 | 0 | 0 |
| Agency / partnership | 1 | 1 | 0 |
| Press / partner | 0 | 0 | 0 |

### Decisions made this week

- [DR-2026-06-12] Approved the agency white-label intake for one prospect; standard $2,500 per-engagement, custom volume tier deferred until 3 concurrent engagements.
- [DR-2026-06-13] Custom-quote inquiry (Schema Pack for a vertical not in v1): quoted at $79 for a one-off custom vertical schema build, separate from v1 license.

### Watching for next week

- Bundle conversion rate (currently 27%; want to see whether 25% sustains).
- One open custom-quote thread that may convert this week.

---

## How to use this template

Each Operator maintains a single running journal entry per quarter
at `spine/journal/quarterly/<operator>-<YYYY-Q>.md` with the weekly
status appended at the top of the file (most recent first). At
quarter end, the running entry is closed with a quarter-summary block
and the next quarter's running entry begins.

The founding agent reads the most recent weekly entry of each
operator at the start of each session that touches catalog work.
Total read time across 3 operators: under 3 minutes.

The Auditor reads all weekly statuses at quarterly review for
constitutional drift detection.
