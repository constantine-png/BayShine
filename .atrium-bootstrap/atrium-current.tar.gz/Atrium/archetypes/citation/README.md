# Citation — Audit-Tool Network

Self-serve AI-search and schema monitoring SaaS family. The flagship
business of the Town.

## Tiers (all Stripe Checkout, no human closer)

| Tier | Price | Scope |
|---|---|---|
| Scan | $0 | One-shot GEO audit, email-gated PDF. Acquisition surface. |
| Watch | $29/mo | Weekly schema + llms.txt + Lighthouse alerts. |
| Cite | $99/mo | Watch + weekly AI-citation probe across Claude/GPT/Perplexity/Gemini. |
| Cite Pro | $299/mo | Cite + 3-competitor monitoring + auto schema regeneration on drift. |
| Agency | $799/mo | Cite Pro × 10 domains, white-label reports. |

## Sibling tools (separate marketing sites, shared backend)

- **Schema Doctor** ($29/mo) — pure schema audit + auto JSON-LD diffs.
- **llms.txt Sentinel** ($19/mo) — llms.txt drift monitor.
- **Lighthouse Sentinel** ($19/mo) — Lighthouse-CI as a service.
- **AI-Cite Probe** ($39/mo) — standalone weekly AI-engine
  recommendation report.

## Stack (planned)

- Astro + Vercel for the marketing site and dashboard.
- React islands for the dashboard (customer domain list, latest
  reports, citation deltas).
- Neon Postgres (schema in `archetypes/shared/db/schema.sql`).
- Resend for transactional email.
- Stripe Checkout + customer portal.
- Vercel Cron for weekly probes.
- Underlying audit engine: the five discoverability specialists
  invoked via `archetypes/shared/audit.ts`.

## Builder

`astro-saas-builder` (see `lineage/astro-saas-builder.yml`).

## Operator (post-installation)

`operator-audit-family` (created at Phase 6 of the spin-up).

## Sub-businesses (post-maturity)

See `spine/PLAN.md` Archetype 2 — vertical-specific
positionings (Citation for Dentists, Schema Doctor for Law Firms),
API tier, Agency white-label, Enterprise tier.

## Status

Scaffolding only. Phase 3 (Build) of the spin-up begins in the
next session.
