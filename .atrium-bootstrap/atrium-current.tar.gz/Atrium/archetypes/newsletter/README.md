# Cited Weekly

Subscription newsletter on Beehiiv covering the weekly state of AI
search: what models recommend in what categories, which sites are
gaining citations, schema/llms.txt changes worth caring about.

## Tiers

- Free — most articles, ad-supported via Beehiiv boosts.
- Paid ($9-19/mo) — deep analyses, full dataset downloads from
  the citations Library, access to a paid Discord/Slack.

## Content sources

- The town's own citations dataset (`library/citations/`).
- Weekly outputs from `citation-probe-specialist`.
- Public scrape of vertical/geo categories sampled across the
  four AI engines.
- Reader-submitted domains (free Scan-style probes done weekly
  for paid subscribers).

## Why this exists

The dataset we generate as a side effect of the town's other
businesses is itself a publication. The newsletter monetizes that
dataset directly and back-funnels readers into Citation paid
subscriptions.

## Builder

`newsletter-builder`.

## Operator (post-installation)

`operator-newsletter`.

## Sub-businesses (post-maturity)

Vertical-Specific Newsletters (Cited for Detailing, Cited for
Dentists), Annual Industry Reports ($99-299 one-time), Sponsored-
Issue marketplace, Paid Discord/Slack community ($29/mo).

## Status

Scaffolding only. Phase 3 (Build) opens in Month 2 after Citation
free Scan funnel is live to seed initial subscribers.
