/**
 * Monthly ledger roll cron handler.
 *
 * Runs at 23:00 UTC on the last day of each month. Aggregates
 * the month's PurchaseEvent records across every archetype's
 * platform webhooks, updates finance/ledger.md with the new
 * monthly row, checks unlock-ladder state, and writes a Journal
 * entry under governor-specialist lineage summarizing the month
 * and noting any unlock thresholds crossed.
 *
 * The Governor descendant is invoked by this handler for the
 * unlock-state check; this file is the scheduling shell.
 */

export const config = {
  schedule: "0 23 28-31 * *",   // last 4 days of month at 23:00 UTC; handler checks if today is actually last
};

export interface LedgerRollResult {
  ok: boolean;
  month: string;                 // "2026-05"
  revenueUsdCents: number;
  costUsdCents: number;
  netUsdCents: number;
  unlocksCrossed: string[];      // list of ladder thresholds crossed this month
  errorMessage?: string;
}

// SKELETON: Plumbing wires this at Phase 4 of the first archetype
// that produces real PurchaseEvent records.
export async function handler(): Promise<LedgerRollResult> {
  throw new Error(
    "Monthly ledger roll cron not yet wired. See governor-specialist " +
      "definition and finance/ledger.md for the Phase-4 wiring brief. " +
      "Implementation outline: verify today is actually month-end; " +
      "aggregate PurchaseEvents from each platform's API for the month; " +
      "update finance/ledger.md; invoke governor-specialist to check " +
      "unlock ladder; write summary Journal entry."
  );
}

// Static helper. Returns true if today is the last day of the
// current month. Used inside handler() to gate the run since
// cron's day-of-month support cannot express "last day" directly.
export function isLastDayOfMonth(today: Date): boolean {
  const tomorrow = new Date(today);
  tomorrow.setDate(today.getDate() + 1);
  return tomorrow.getDate() === 1;
}
