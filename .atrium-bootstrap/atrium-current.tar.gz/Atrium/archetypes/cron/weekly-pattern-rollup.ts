/**
 * Weekly Pattern Rollup cron handler.
 *
 * Runs once weekly on Sunday at 22:00 UTC. Aggregates
 * library/decisions.jsonl rows from the prior 7 days, identifies
 * recurring patterns per archetype and per vertical, and updates
 * library/playbooks/<archetype>.md with new "What worked" /
 * "What failed" entries citing the underlying decision rows.
 *
 * Invoked by Vercel Cron. The pattern-rollup-specialist
 * descendant is invoked by this handler to do the actual
 * synthesis; this file is the scheduling shell.
 */

export const config = {
  schedule: "0 22 * * 0",      // Sunday 22:00 UTC
};

export interface RollupResult {
  ok: boolean;
  decisionsAggregated: number;
  playbooksUpdated: string[];      // list of file paths edited
  newPatternsFound: number;
  errorMessage?: string;
}

// SKELETON: Plumbing wires this at Phase 4 of the first
// archetype that has produced enough decisions.jsonl rows
// to make rollup meaningful (>= 30 rows over >= 14 days).
export async function handler(): Promise<RollupResult> {
  throw new Error(
    "Weekly Pattern Rollup cron not yet wired. See pattern-rollup-specialist " +
      "definition for the synthesis brief. Implementation outline: read " +
      "the last 7 days of decisions.jsonl, group by (archetype, vertical), " +
      "invoke pattern-rollup-specialist with the slice, write updated " +
      "playbooks back to library/playbooks/, write a summary Journal entry."
  );
}
