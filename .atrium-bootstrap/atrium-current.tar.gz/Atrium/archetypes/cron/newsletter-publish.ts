/**
 * Newsletter publish cron handler.
 *
 * Runs once weekly on Tuesday at 09:00 Eastern (14:00 UTC
 * during DST, 13:00 UTC outside DST). Publishes the prepared
 * issue from library/artifacts/newsletter/staged/ to the
 * Beehiiv publication and clears the staged file.
 *
 * If no issue is staged at run time, the handler writes a
 * Journal entry under operator-newsletter lineage flagging
 * the missed cadence and halts gracefully (no fallback
 * publish; quality bar before cadence).
 */

export const config = {
  schedule: "0 13 * * 2",       // Tuesday 13:00 UTC (adjust seasonally)
};

export interface PublishResult {
  ok: boolean;
  issueId: string | null;
  postUrl: string | null;
  freeSubscribersAtPublish: number;
  paidSubscribersAtPublish: number;
  errorMessage?: string;
}

// SKELETON: Plumbing wires this at Phase 4 of the Newsletter
// spin-up.
export async function handler(): Promise<PublishResult> {
  throw new Error(
    "Newsletter publish cron not yet wired. See library/playbooks/newsletter.md " +
      "for the Phase-4 wiring brief. Implementation outline: read the " +
      "next-staged issue from library/artifacts/newsletter/staged/, " +
      "validate against checkVoice() in shared/resend.ts (newsletter " +
      "issues inherit the same voice gate), call beehiivClient.createPost " +
      "with tier='free', then again with tier='paid' for the paid-tier " +
      "issue, then archive the staged file to library/artifacts/newsletter/published/."
  );
}
