/**
 * Daily AI-engine probe cron handler.
 *
 * Runs once daily at 06:00 UTC. Probes the four monitored
 * engines (Claude, GPT, Perplexity, Gemini) against the active
 * watchlist of (vertical, geo, query) triples and writes results
 * to library/citations/YYYY-MM-DD.jsonl.
 *
 * Invoked by Vercel Cron. Cost-capped at $1.00 per run; a run
 * exceeding the cap halts and writes an entry to
 * library/decisions.jsonl tagged with citation-probe-specialist
 * lineage and outcome="failed".
 *
 * Watchlist source: library/citations/watchlist.yml (authored
 * by citation-probe-specialist; reviewed quarterly).
 */

import type { CitationRecord, ProbeInput } from "../shared/types";
// SKELETON: import { createProbeClient } from "../shared/probe";

export const config = {
  schedule: "0 6 * * *",       // 06:00 UTC daily
  costCeilingUsdCents: 100,
  outputPath: "library/citations/{date}.jsonl",
};

export interface CronHandlerResult {
  ok: boolean;
  probesRun: number;
  citationsWritten: number;
  totalCostUsdCents: number;
  errorMessage?: string;
}

// SKELETON: Plumbing wires the real implementation at Phase 4
// of the Newsletter spin-up or the citation-probe-specialist's
// first scheduled run.
export async function handler(): Promise<CronHandlerResult> {
  throw new Error(
    "Daily probe cron not yet wired. See citation-probe-specialist " +
      "definition and library/playbooks/newsletter.md for the Phase-4 " +
      "wiring brief. Implementation outline: load watchlist, build " +
      "ProbeInput list, call probeClient.probeBatch, write results to " +
      "the dated citations file, log totals to decisions.jsonl."
  );
}

// Static helper used by the wired handler. Builds the probe
// input list from the watchlist file. Available for unit
// testing without making real API calls.
export function buildProbeInputs(
  _watchlistYaml: string,
  _today: string
): ProbeInput[] {
  throw new Error("buildProbeInputs not yet implemented");
}

// Static helper. Serializes a citation record to the JSONL
// format expected by the citations dataset.
export function serializeCitation(c: CitationRecord): string {
  return JSON.stringify(c);
}
