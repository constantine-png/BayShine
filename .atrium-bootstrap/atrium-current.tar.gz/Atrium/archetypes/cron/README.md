# Cron handlers

Vercel Cron entrypoints that run the town's recurring jobs.
Authored by the Plumbing descendant; orchestrated by the
Governor.

## Planned jobs

### Per-business (Citation customers)

- Nightly: Lighthouse mobile + desktop, schema validity,
  llms.txt drift, sitemap reachability, robots.txt sanity.
- Weekly: AI-citation probe (citation-probe-specialist),
  competitor delta (Cite Pro tier only), internal link graph
  diff.

### Per-network page (Directory)

- Nightly: indexing status, Lighthouse, structured-data
  validation, broken-link detection. Auto-fix routine for
  detectable regressions.
- Weekly: AI-engine probe to confirm pages are being cited.
  Pages not earning after 90 days flagged for the Operator.

### Town-wide

- Sunday: Pattern Rollup runs.
- Sunday: Public weekly report generation for Cited Weekly.
- First of month: per-business cost governor report.
- First day of quarter: Auditor runs the quarterly review.

## Cost governor

Every cron run logs token + tool spend per business. Overruns
trigger throttling or rerouting to higher-yield work, never
unbounded spend.

## Status

Empty scaffold. Plumbing populates as each archetype's Phase 4
completes.
