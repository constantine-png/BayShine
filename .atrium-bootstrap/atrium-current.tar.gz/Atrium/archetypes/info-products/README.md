# Information Products (Gumroad / Lemon Squeezy / Stripe Direct)

Standalone digital products sold on instant-checkout platforms with
zero sales motion. The most-demonstrated model for solo builders
with writing capability.

## Evidence base

- Sahil Lavingia (Gumroad founder, also operator on his own
  platform): $11M+ lifetime creator earnings on his own products.
- Pieter Levels' books "Make" and "MAKE" book: ~$1M+ lifetime,
  one person.
- Marc Lou's ShipFast boilerplate: $1.5M+ lifetime, single
  Stripe checkout, single template.
- Hundreds of Notion templates at $19-$99 generating $5k-$50k/mo
  passive for solo creators.

Evidence rating: **Very strong.** The model has been demonstrated
hundreds of times by solo creators with writing capability and a
specific audience, on a 1-7 day time-to-first-dollar.

## Strategy

Ship a single, narrowly-scoped digital product. Sell it on
Gumroad or Lemon Squeezy with one-click Stripe checkout. No
account creation, no demo, no sales call. Buyer downloads
immediately on purchase.

The product is the writing — playbooks, templates, prompts,
schema packs, audits — formatted as PDF + accompanying assets
(spreadsheets, MDX, JSON-LD files, etc.).

## First-generation product catalog

Ordered by build priority. Each leverages the discoverability
specialists or BayShine work directly.

### Tier 1 — first 30 days

1. **"The GEO Playbook for Local Service Businesses"** — 60-80
  page PDF. Schema templates for 12 verticals. llms.txt
  template. Citation-readiness checklist. AI-search audit
  template. $99 one-time on Gumroad. Target: 50 sales month one
  = $4,950 gross. Audience: local agency operators, freelance
  SEO consultants, owner-operators in service businesses.
  Distribution: r/SEO, r/LocalSEO, r/marketing, IndieHackers,
  Hacker News (Show HN: I built a 60-page GEO playbook for
  local service businesses), X.
2. **"The Schema Pack: 24 Service Business Verticals"** —
  validated JSON-LD blocks for 24 vertical types (dental, legal,
  HVAC, plumbing, etc.) plus integration instructions. $49 one-
  time on Gumroad. Target: 100 sales month one = $4,900 gross.
3. **"Local Service Business AI-Search Audit Template"** —
  Notion / Google Doc template that walks a buyer through
  auditing their own GEO. $29 one-time. Volume play. Target:
  300 sales month one = $8,700 gross.

### Tier 2 — days 30-90 if Tier 1 lands

4. **"The Service-Area Page Playbook"** — 40-page PDF on
  designing the service-area sub-architecture site
  -architecture-specialist recommends. $79 one-time.
5. **"The Mobile Detailing Operations Manual"** — productized
  version of the BayShine operational documents (anonymized,
  generalized). $149 one-time. Target audience: aspiring
  mobile detailers.
6. **"The Tiny Local Business AI-Citation Probe Spreadsheet"** —
  Google Sheet that runs structured prompts against Perplexity /
  ChatGPT search / Gemini and scores citation. $39 one-time.
7. **"60 Local Service Business Email Templates"** — buyer-
  triggered email sequences for 12 verticals. $39 one-time.

### Tier 3 — bundles

When Tier 1 has shipped, bundle. "The Local Service Business
Discoverability Mega Pack" — all Tier 1 products bundled at
$199 (versus $177 unbundled). The bundle is a classic
information-product lift; conversion rate on bundles in this
range is consistently 2-3x individual products.

## Monetization

- **Gumroad** for products $30+. Lower platform fee at scale
  than Lemon Squeezy, simpler creator dashboard.
- **Lemon Squeezy** for products under $30 (MoR handles VAT in
  EU, important at low price points).
- **Stripe direct** for products $200+ where checkout-page
  design matters and the brand can absorb the technical cost.

Affiliate revenue share at 30% for any partner who refers a
sale. Direct integration with Gumroad's affiliate program.

## Quality bar

- Every product is real writing. No padding. No filler. If a
  PDF needs to be shorter to be honest, it is shorter.
- Voice from `spine/origins/CLAUDE.md`: direct, no soft
  marketing, no exclamation marks, no em-dashes.
- Schema packs are validated against schema.org spec by the
  schema-specialist before publish.
- Audit templates are tested against three real local service
  businesses before publish.

## Builder

`info-product-builder` (new descendant, to be authored once a
first product clears $1k revenue and a Builder specialization
pattern is observable). Until then, the founding agent ships
the first 1-3 products directly.

## Operator

`operator-info-products` once an authored Builder exists. Until
then, the founding agent operates the catalog directly.

## Growth Clause

> You are the operator of the Information Products catalog. Your
> primary measure is sustainable net revenue across all products.
> When 3 products each clear $500/mo for 60 consecutive days,
> propose in a Journal entry: (a) 3 sibling products targeting
> adjacent buyer pain, (b) a recurring-revenue conversion path
> (turn the highest seller into a subscription-template service),
> OR (c) a paid Discord community for paying buyers. State the
> token cost of each proposal explicitly. The founding agent
> approves spawns.

## Time-to-first-dollar

7 days. The first product (The GEO Playbook) requires writing,
which I can do in 2-3 days of authoring. Gumroad listing setup
is 30 minutes. Distribution post and initial Reddit/HN response
shapes the first sales within hours of launch.

## Status

**Promoted to flagship priority alongside Productized Services.**
The first product (The GEO Playbook for Local Service Businesses)
opens active development immediately upon push.
