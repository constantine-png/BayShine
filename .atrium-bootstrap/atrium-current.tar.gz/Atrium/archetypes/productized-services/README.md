# Productized Services (Stripe Direct Checkout)

Fixed-price, fixed-scope, fixed-deliverable services sold on a
one-page sales site with Stripe checkout. Buyer pays first, work
starts immediately. The most-demonstrated model for solo builders
who can deliver expert work at speed.

## Evidence base

- Tiny Capital portfolio companies (productized services
  acquired and scaled).
- Indie hackers selling productized services at $500-$10,000:
  many examples across IndieHackers, MicroConf, Twitter.
- "Done For You" GEO/SEO/schema services from solo consultants:
  hundreds of operators charging $1,500-$10,000 per engagement.
- Tony Dinh's productized-product hybrid model.

Evidence rating: **Very strong.** Direct fit for an agent with
expert-domain capability who can deliver an audit, an
implementation, or a writing engagement on a fixed timeline.

## Strategy

One service. One price. One outcome. One page. Stripe checkout.
Buyer pays. Work begins same day. Deliverable lands on the
contracted date. No scoping calls, no proposals, no negotiation.

The work is the discoverability specialists running their full
audit and implementation pipeline on the buyer's site. The
human in the loop (Constantine or a subcontracted operator) is
the named accountable party who reviews and signs off on the
final deliverable.

## First-generation service catalog

### Tier 1 — first 60 days

1. **"GEO Setup for Local Service Businesses — $2,500 flat,
  10-day turnaround"**
  - Schema markup across all pages (LocalBusiness, Service,
    FAQ, Article as needed) — schema-specialist.
  - Site architecture audit and recommendations —
    site-architecture-specialist.
  - llms.txt + AI-citation hints — geo-ai-search-specialist.
  - Internal linking pass — internal-linking-specialist.
  - Citation-readiness rewrite on top 5 pages — citation-
    readiness-specialist.
  - 90-day citation-probe report — citation-probe descendant.
  - Final deliverable: a PR or commit on the buyer's repo + a
    1-page executive summary + a 30-day re-check.
  - Target: 4 sales in month 2 = $10,000 gross.

2. **"BayShine-Style Mobile Detailing Website Build —
  $7,500 flat, 21-day turnaround"**
  - The full BayShine template adapted to the buyer's brand,
    geography, and service offerings.
  - Astro + Tailwind, Lighthouse 95+, complete content set
    for service pages and service-area pages.
  - Schema, llms.txt, internal linking, citation-readiness all
    baked in.
  - Target: 2 sales in month 2 = $15,000 gross.

3. **"AI Citation Audit for Service Businesses — $499 flat,
  5-day turnaround"**
  - Run the citation-probe pipeline against the buyer's domain
    in the buyer's vertical across Perplexity, ChatGPT search,
    Claude, Gemini, You.com.
  - Deliver a 15-page report: what AI engines say about the
    buyer's brand, where the buyer is being cited or missed,
    structured remediation list keyed to the buyer's CMS.
  - Target: 20 sales in month 2 = $9,980 gross.

### Tier 2 — days 60-120 if Tier 1 lands

4. **"Schema Implementation for an Existing Site — $999 flat,
  7-day turnaround"** — lighter alternative to the $2,500 GEO
  setup.
5. **"Service-Area Page Pack — $1,499 flat, 14-day turnaround"** —
  generates 25 service-area pages following the site-architecture
  pattern.
6. **"AI Search Visibility Retainer — $499/mo recurring"** —
  monthly citation-probe + remediation + schema drift check.

## Monetization

- **Stripe Checkout** with a one-click payment link. No account
  creation. No multi-step funnel.
- **Receipt → automated welcome email** triggering the
  intake form (a single Typeform or Notion form) collecting
  domain, vertical, and access credentials.
- **Calendar booking** for a 30-minute kickoff, which is the
  only human touchpoint and is delivered via a scheduled
  recording (not a live call) for buyers who prefer async.
  The brand stays closer-less by default; live calls are
  available on request but never the default.
- **Revenue share** with subcontracted operators (Constantine
  or trusted humans) at 30-50% net of platform fees.

## Quality bar

- Every deliverable passes the full specialist gate before
  delivery. No specialist may sign off on output that doesn't
  meet `spine/origins/CLAUDE.md` standards.
- Refund policy: if the deliverable does not pass the
  documented quality bar at the documented timeline, full
  refund, no questions.
- Case study: every completed engagement produces an anonymized
  case study published to the Atrium content site within 30
  days (with buyer consent), which compounds the trust
  surface for subsequent sales.

## Builder

`productized-service-builder` (new descendant, to be authored
once the first three engagements have been delivered and a
specialist orchestration pattern is observable). Until then,
the founding agent operates engagements directly with the
existing five specialists as the workforce.

## Operator

`operator-productized-services` once the Builder exists. Until
then, the founding agent operates directly.

## Growth Clause

> You are the operator of the Productized Services catalog. Your
> primary measure is sustainable net revenue across all
> services, with quality-bar maintenance as a hard constraint.
> When 3 services each clear $5,000/mo for 60 consecutive days,
> propose in a Journal entry: (a) a higher-tier engagement
> (Enterprise-scale $25,000 flat for multi-location service
> chains), (b) a sibling vertical productized service, OR (c) a
> recurring-revenue retainer tier on the highest-converting one-
> time service. State the token cost of each proposal explicitly.

## Time-to-first-dollar

14 days. Week 1: ship the sales page, set up Stripe, write the
intake form, dry-run the delivery pipeline against BayShine
itself as the case study. Week 2: distribution post on
IndieHackers, X, r/SmallBusiness, r/LocalSEO, with a real
case study and a working sales page. First sale typically
within 3-7 days of distribution start in this category.

## Why this is the second-priority flagship

Combines my strongest capability (expert-domain work via the
specialists) with the demonstrated solo-builder revenue model
(productized services on Stripe). The unit economics work at
volumes I can sustain: 4 sales/month at $2,500 = $10k/mo,
which crosses the first unlock threshold by itself.

The risk is delivery quality at scale — but the specialist gate
addresses that by construction. The Audit-Tool Network was
betting that local service businesses would self-serve a paid
SaaS. The Productized Services bet is that they will pay a
fixed price for a finished deliverable, which is a much
better-evidenced bet.

## Status

**Promoted to flagship priority alongside Information Products.**
The first service (GEO Setup for Local Service Businesses,
$2,500 flat) opens active development immediately upon push.
