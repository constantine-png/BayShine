/**
 * Stripe wrapper interface.
 *
 * This file is a typed contract. Plumbing wires the real
 * Stripe SDK at Phase 4 of the first archetype that needs it
 * (Productized Services for Stripe Checkout, Info Products for
 * Stripe-as-fallback, DevTools for license-key generation).
 *
 * Credentials are referenced via env var names only; descendants
 * never see raw values.
 */

import type { PurchaseEvent } from "./types";

export interface StripeCheckoutSessionInput {
  productSlug: string;
  priceUsdCents: number;
  successUrl: string;
  cancelUrl: string;
  customerEmail?: string;
  metadata?: Record<string, string>;
}

export interface StripeCheckoutSession {
  id: string;
  url: string;
  expiresAt: string;
}

export interface StripeLicenseKey {
  key: string;             // opaque token; format defined in license-keys.ts
  productSlug: string;
  customerEmail: string;
  issuedAt: string;
  expiresAt: string | null; // null for perpetual licenses
}

export interface StripeClient {
  createCheckoutSession(input: StripeCheckoutSessionInput): Promise<StripeCheckoutSession>;
  parseWebhook(rawBody: string, signature: string): Promise<PurchaseEvent>;
  refund(chargeId: string, reason: string): Promise<void>;
  issueLicenseKey(input: { productSlug: string; customerEmail: string }): Promise<StripeLicenseKey>;
}

export const STRIPE_ENV_VAR_NAMES = {
  secretKey: "STRIPE_SECRET_KEY",
  webhookSecret: "STRIPE_WEBHOOK_SECRET",
  publishableKey: "STRIPE_PUBLISHABLE_KEY",
} as const;

// SKELETON: Plumbing replaces this stub at Phase 4 of the first
// archetype that needs Stripe (Productized Services).
export function createStripeClient(): StripeClient {
  throw new Error(
    "Stripe client not yet wired. See library/playbooks/productized-services.md " +
      "for the Phase-4 wiring brief. Plumbing implements against the official " +
      "stripe-node SDK using the env vars in STRIPE_ENV_VAR_NAMES."
  );
}
