/**
 * Resend wrapper interface.
 *
 * Resend handles transactional email for every archetype.
 * Each archetype defines its own email templates; this wrapper
 * provides a uniform send interface and enforces the voice
 * constraints from spine/origins/CLAUDE.md at send time.
 */

export interface ResendEmailInput {
  from: string;
  to: string;
  subject: string;
  bodyMarkdown: string;
  replyTo?: string;
  tags?: Record<string, string>;
}

export interface ResendEmailResult {
  id: string;
  sentAt: string;
}

export interface ResendClient {
  send(input: ResendEmailInput): Promise<ResendEmailResult>;
  fetchDeliveryStatus(id: string): Promise<"pending" | "delivered" | "bounced" | "complained">;
}

export const RESEND_ENV_VAR_NAMES = {
  apiKey: "RESEND_API_KEY",
  defaultFromAddress: "RESEND_DEFAULT_FROM",
} as const;

// Voice gate. Resend.send wraps this to refuse any subject
// or body that violates the brand voice. Returns the list of
// violations; empty array = passes.
export function checkVoice(text: string): string[] {
  const violations: string[] = [];
  if (text.includes("—")) violations.push("em-dash present (use en-dash with spaces or comma)");
  if (text.match(/!\s/) || text.endsWith("!")) violations.push("exclamation mark present");
  if (text.match(/\bwe'd love\b/i)) violations.push("soft marketing phrase: 'we'd love'");
  if (text.match(/\bfeel free\b/i)) violations.push("soft marketing phrase: 'feel free'");
  if (text.match(/\bpassionate about\b/i)) violations.push("soft marketing phrase: 'passionate about'");
  if (text.match(/\bexciting\b/i)) violations.push("soft marketing word: 'exciting'");
  return violations;
}

// SKELETON: Plumbing wires this at Phase 4 of the first archetype
// that needs Resend (Information Products' welcome email is first).
export function createResendClient(): ResendClient {
  throw new Error(
    "Resend client not yet wired. See library/playbooks/info-products.md " +
      "for the Phase-4 wiring brief. The voice gate (checkVoice) is " +
      "ready to import and use."
  );
}
