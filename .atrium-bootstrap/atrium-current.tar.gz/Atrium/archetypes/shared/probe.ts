/**
 * AI-engine probe wrapper.
 *
 * Queries the four monitored engines (Claude, GPT, Perplexity,
 * Gemini) against a query and a domain, returning whether the
 * domain was cited and at what position. Results land in
 * library/citations/.
 *
 * This is the data engine for the citation-probe-specialist
 * descendant and for the Newsletter's weekly issue. Cost
 * accounting is mandatory per call.
 */

import type { AIEngine, CitationRecord, Vertical } from "./types";

export interface ProbeInput {
  engine: AIEngine;
  query: string;
  domainToFind: string;
  vertical: Vertical;
  geo: string;
}

export interface ProbeResult extends CitationRecord {
  costUsdCents: number;
  rawResponse: string; // archived for re-analysis
}

export interface ProbeClient {
  probe(input: ProbeInput): Promise<ProbeResult>;
  probeBatch(inputs: ProbeInput[]): Promise<ProbeResult[]>;
}

export const PROBE_ENV_VAR_NAMES = {
  anthropic: "ANTHROPIC_API_KEY",
  openai: "OPENAI_API_KEY",
  perplexity: "PERPLEXITY_API_KEY",
  google: "GOOGLE_AI_API_KEY",
} as const;

// Per-engine cost ceiling per single probe. Probes exceeding
// these are refused by the client. Reviewed quarterly.
export const PROBE_COST_CEILING_CENTS: Record<AIEngine, number> = {
  claude: 5,       // Haiku for cheap passes; Opus only on synthesis
  gpt: 10,
  perplexity: 8,
  gemini: 5,
};

// SKELETON: Plumbing wires this at Phase 4 of the first
// archetype that uses the probe (Newsletter for issue
// content, citation-probe-specialist for ongoing monitoring).
export function createProbeClient(): ProbeClient {
  throw new Error(
    "Probe client not yet wired. See library/playbooks/newsletter.md " +
      "and the citation-probe-specialist definition for the Phase-4 " +
      "wiring brief."
  );
}
