/**
 * Gumroad wrapper interface.
 *
 * Gumroad is the primary platform for Information Products
 * priced $30+. The Info-Product Builder produces the listing
 * copy and assets; Plumbing wires the API for product creation
 * and webhook ingestion.
 */

import type { PurchaseEvent } from "./types";

export interface GumroadProductInput {
  name: string;
  description: string;          // markdown
  priceUsdCents: number;
  fileAssetPath: string;        // absolute path to the downloadable file
  slug: string;
  affiliateProgramEnabled: boolean;
  affiliateCommissionPercent: number; // default 30
}

export interface GumroadProduct {
  id: string;
  slug: string;
  productUrl: string;
  shortUrl: string;
  createdAt: string;
}

export interface GumroadClient {
  createProduct(input: GumroadProductInput): Promise<GumroadProduct>;
  updateProduct(slug: string, input: Partial<GumroadProductInput>): Promise<GumroadProduct>;
  parseWebhook(rawBody: string, signature: string): Promise<PurchaseEvent>;
  fetchSalesSince(timestampIso: string): Promise<PurchaseEvent[]>;
}

export const GUMROAD_ENV_VAR_NAMES = {
  accessToken: "GUMROAD_ACCESS_TOKEN",
  webhookSecret: "GUMROAD_WEBHOOK_SECRET",
} as const;

// SKELETON: Plumbing wires this at Phase 4 of the first
// Information Products spin-up.
export function createGumroadClient(): GumroadClient {
  throw new Error(
    "Gumroad client not yet wired. See library/playbooks/info-products.md " +
      "for the Phase-4 wiring brief."
  );
}
