/**
 * License-key generation and validation.
 *
 * Used by DevTools paid tiers (npm packages, GitHub Actions,
 * VSCode/JetBrains extensions, WordPress plugin) to gate paid
 * features behind a Stripe-purchased license key.
 *
 * Keys are opaque to the buyer and verifiable offline via a
 * signed payload (asymmetric crypto, public key shipped with
 * the tool, private key held by Atrium's license server).
 */

export interface LicenseKeyPayload {
  productSlug: string;
  customerEmail: string;
  tier: "free" | "starter" | "pro" | "enterprise";
  issuedAt: string;
  expiresAt: string | null; // null for perpetual
  metadata?: Record<string, string>;
}

export interface LicenseValidationResult {
  valid: boolean;
  payload: LicenseKeyPayload | null;
  reason: "ok" | "expired" | "invalid-signature" | "malformed" | "revoked";
}

export interface LicenseServer {
  generateKey(payload: LicenseKeyPayload): Promise<string>;
  validateKey(key: string): Promise<LicenseValidationResult>;
  revokeKey(key: string, reason: string): Promise<void>;
}

export const LICENSE_ENV_VAR_NAMES = {
  signingPrivateKey: "LICENSE_SIGNING_PRIVATE_KEY",   // RS256 PEM
  signingPublicKey: "LICENSE_SIGNING_PUBLIC_KEY",     // RS256 PEM, shipped with tools
  revocationListUrl: "LICENSE_REVOCATION_LIST_URL",   // optional revocation endpoint
} as const;

// SKELETON: Plumbing wires this at Phase 4 of the first DevTools
// spin-up. Suggested implementation: JOSE library with RS256.
export function createLicenseServer(): LicenseServer {
  throw new Error(
    "License server not yet wired. See archetypes/devtools/README.md " +
      "for the Phase-4 wiring brief. Use jose's SignJWT and jwtVerify with " +
      "RS256, with the keys from LICENSE_ENV_VAR_NAMES."
  );
}

// Offline validation utility. Tools embed the public key at
// build time and call this function with no network access.
// SKELETON. Plumbing implements at Phase 4.
export function validateKeyOffline(_key: string, _publicKeyPem: string): LicenseValidationResult {
  throw new Error(
    "Offline license validation not yet wired. See license-keys.ts header."
  );
}
