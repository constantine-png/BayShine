/**
 * Lemon Squeezy wrapper interface.
 *
 * Lemon Squeezy is the primary platform for Information Products
 * priced under $30 (Merchant of Record handling for EU VAT
 * matters at low price points) and the fallback platform for
 * any product where Gumroad's product structure does not fit.
 */

import type { PurchaseEvent } from "./types";

export interface LemonSqueezyProductInput {
  storeId: string;
  name: string;
  description: string;
  priceUsdCents: number;
  fileAssetPath: string;
  slug: string;
}

export interface LemonSqueezyProduct {
  id: string;
  slug: string;
  buyNowUrl: string;
  createdAt: string;
}

export interface LemonSqueezyClient {
  createProduct(input: LemonSqueezyProductInput): Promise<LemonSqueezyProduct>;
  updateProduct(slug: string, input: Partial<LemonSqueezyProductInput>): Promise<LemonSqueezyProduct>;
  parseWebhook(rawBody: string, signature: string): Promise<PurchaseEvent>;
}

export const LEMON_SQUEEZY_ENV_VAR_NAMES = {
  apiKey: "LEMON_SQUEEZY_API_KEY",
  webhookSecret: "LEMON_SQUEEZY_WEBHOOK_SECRET",
  storeId: "LEMON_SQUEEZY_STORE_ID",
} as const;

// SKELETON: Plumbing wires this at Phase 4 of the first
// Information Products spin-up if a product is priced under $30.
export function createLemonSqueezyClient(): LemonSqueezyClient {
  throw new Error(
    "Lemon Squeezy client not yet wired. See library/playbooks/info-products.md " +
      "for the Phase-4 wiring brief."
  );
}
