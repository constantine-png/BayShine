# Shared modules

TypeScript modules used by every archetype. Authored by the
Plumbing descendant during Phase 4 of each spin-up; persisted
here as a common library.

## Modules (planned)

- `db.ts` — Neon Postgres client wrapper.
- `stripe.ts` — Stripe Checkout, customer portal, license-key
  generation, refund-policy enforcement.
- `resend.ts` — Resend transactional email wrapper with
  templates per archetype.
- `twilio.ts` — Twilio SMS for Directory lead routing.
- `gumroad.ts` — Gumroad/Polar product listing + sales webhook.
- `beehiiv.ts` — Beehiiv subscriber + post management.
- `chrome-store.ts` — Chrome Web Store + Edge Add-ons
  submission and update management.
- `audit.ts` — orchestrator that invokes the five
  discoverability specialists against a target domain.
- `probe.ts` — AI-engine query wrapper (Claude, GPT,
  Perplexity, Gemini) with cost accounting per call.
- `lineage.ts` — descendant invocation helper that injects
  the Constitution and the relevant playbook into the child
  agent's system prompt.
- `db/schema.sql` — Neon schema definitions for `customers`,
  `domains`, `scans`, `citations`, `events`, `leads`,
  `listings`, plus per-Directory and per-Vault schemas.

## Credential handling

The Plumbing descendant never sees raw credentials. Constantine
provisions accounts and stores credentials as encrypted
environment variables on Vercel. Descendants reference them by
name, never by value.

## Status

Empty scaffold. Plumbing populates as each archetype's spin-up
reaches Phase 4.
