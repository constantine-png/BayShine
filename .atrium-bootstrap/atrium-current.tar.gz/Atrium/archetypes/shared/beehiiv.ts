/**
 * Beehiiv wrapper interface.
 *
 * Beehiiv hosts every newsletter in the town. The primary
 * publication is Cited Weekly; vertical-specific spin-offs
 * follow once audience thresholds clear.
 */

export interface BeehiivPublication {
  id: string;
  name: string;
  url: string;
  freeSubscriberCount: number;
  paidSubscriberCount: number;
}

export interface BeehiivPostInput {
  publicationId: string;
  title: string;
  subtitle: string;
  bodyMarkdown: string;
  tier: "free" | "paid";
  scheduledFor: string; // ISO-8601 timestamp
  tags?: string[];
}

export interface BeehiivPost {
  id: string;
  url: string;
  status: "draft" | "scheduled" | "published";
  scheduledFor: string;
  publishedAt: string | null;
}

export interface BeehiivClient {
  getPublication(publicationId: string): Promise<BeehiivPublication>;
  createPost(input: BeehiivPostInput): Promise<BeehiivPost>;
  fetchSubscribersSince(publicationId: string, sinceIso: string): Promise<number>;
  fetchPostMetrics(postId: string): Promise<{ opens: number; clicks: number; unsubscribes: number }>;
}

export const BEEHIIV_ENV_VAR_NAMES = {
  apiKey: "BEEHIIV_API_KEY",
  publicationId: "BEEHIIV_PUBLICATION_ID",
} as const;

// SKELETON: Plumbing wires this at Phase 4 of the Newsletter
// spin-up.
export function createBeehiivClient(): BeehiivClient {
  throw new Error(
    "Beehiiv client not yet wired. See library/playbooks/newsletter.md " +
      "for the Phase-4 wiring brief."
  );
}
