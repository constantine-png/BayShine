/**
 * Lineage helper.
 *
 * Injects the constitution, the relevant playbook, and the
 * required voice rules into a descendant agent's system prompt
 * at invocation time. Every Builder and every Operator goes
 * through this wrapper so the Constitution is inherited
 * verbatim, not paraphrased.
 */

import type { LineageDescendant, Archetype } from "./types";

export interface InvocationContext {
  descendant: LineageDescendant;
  archetype: Archetype | null;
  taskBrief: string;
  additionalContext?: string[];
}

export interface InjectedPrompt {
  systemPrompt: string;
  userPrompt: string;
  embeddedFiles: Array<{ path: string; content: string }>;
}

// SKELETON: Plumbing wires this at Phase 4 of the first
// archetype that actually invokes a descendant programmatically
// (rather than through the Claude Code subagent system).
//
// Until then, descendants are invoked via the Claude Code
// subagent runtime, which reads the .claude/agents/<name>.md
// frontmatter directly and bypasses this wrapper.
export function injectConstitution(_ctx: InvocationContext): Promise<InjectedPrompt> {
  throw new Error(
    "Programmatic lineage injection not yet wired. Descendants are " +
      "currently invoked via Claude Code's subagent runtime which reads " +
      ".claude/agents/<name>.md directly. This wrapper is for the API " +
      "tier when an archetype needs to invoke a descendant from a server " +
      "endpoint."
  );
}

// Static helper that returns the list of files that any
// descendant of the given archetype must inherit. Used by
// Plumbing to verify a descendant's system prompt actually
// contains all required inheritance before invocation.
export function requiredInheritance(descendant: LineageDescendant): string[] {
  const always = ["spine/constitution.md", "spine/origins/CLAUDE.md"];

  if (descendant.startsWith("operator-")) {
    const archetype = descendant.replace("operator-", "");
    return [
      ...always,
      `library/playbooks/${archetype}.md`,
      `archetypes/${archetype}/README.md`,
    ];
  }

  if (descendant.endsWith("-builder")) {
    const archetype = builderToArchetype(descendant);
    if (archetype) {
      return [
        ...always,
        `library/playbooks/${archetype}.md`,
      ];
    }
  }

  return always;
}

function builderToArchetype(builder: LineageDescendant): Archetype | null {
  const map: Partial<Record<LineageDescendant, Archetype>> = {
    "static-site-builder": "network",
    "astro-saas-builder": "citation",
    "chrome-extension-builder": "extensions",
    "newsletter-builder": "newsletter",
    "devtools-builder": "devtools",
    "info-product-builder": "info-products",
    "productized-service-builder": "productized-services",
  };
  return map[builder] ?? null;
}
