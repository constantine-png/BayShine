/**
 * Shared types used by every archetype in the town.
 *
 * This file is a typed contract. Plumbing wires real
 * implementations at Phase 4 of each spin-up; the types
 * here are stable across archetypes.
 */

export type LineageDescendant =
  | "founding"
  | "scribe-specialist"
  | "governor-specialist"
  | "pattern-rollup-specialist"
  | "scout-specialist"
  | "probe-specialist"
  | "plumbing-specialist"
  | "citation-probe-specialist"
  | "auditor-specialist"
  | "schema-specialist"
  | "site-architecture-specialist"
  | "geo-ai-search-specialist"
  | "internal-linking-specialist"
  | "citation-readiness-specialist"
  | "static-site-builder"
  | "astro-saas-builder"
  | "chrome-extension-builder"
  | "newsletter-builder"
  | "api-builder"
  | "async-deliverable-builder"
  | "devtools-builder"
  | "info-product-builder"
  | "productized-service-builder"
  | "operator-info-products"
  | "operator-productized-services"
  | "operator-newsletter";

export type Archetype =
  | "citation"
  | "network"
  | "vault"
  | "extensions"
  | "newsletter"
  | "web-tools"
  | "devtools"
  | "info-products"
  | "productized-services";

export type AIEngine = "claude" | "gpt" | "perplexity" | "gemini";

export type Vertical =
  | "mobile-detailing"
  | "pressure-washing"
  | "mobile-mechanic"
  | "mobile-pet-grooming"
  | "mobile-car-wash"
  | "dental"
  | "legal"
  | "hvac"
  | "plumbing"
  | "roofing"
  | "general";

export interface DecisionLogRow {
  date: string;            // ISO-8601 YYYY-MM-DD
  lineage: LineageDescendant;
  decision: string;
  vertical: Vertical | "meta";
  geo: string;             // e.g. "pasco-fl", "global"
  outcome: "pending" | "executed" | "deferred" | "reverted" | "failed";
  journal_ref: string;     // filename of the authorizing Journal entry
}

export interface CitationRecord {
  date: string;
  engine: AIEngine;
  query: string;
  domain: string;
  cited: boolean;
  position: number | null; // rank if cited, null otherwise
  snippet: string | null;
  vertical: Vertical;
  geo: string;
}

export interface PurchaseEvent {
  platform: "stripe" | "gumroad" | "lemon-squeezy" | "beehiiv";
  productSlug: string;
  archetype: Archetype;
  amountUsdCents: number;
  buyerEmail: string;
  buyerCountry: string;
  affiliateSlug: string | null;
  purchasedAt: string;     // ISO-8601 timestamp
  refunded: boolean;
}

export interface EngagementRecord {
  service: string;
  buyerDomain: string;
  vertical: Vertical;
  purchasedAt: string;
  promisedDeliveryAt: string;
  deliveredAt: string | null;
  refunded: boolean;
  auditorSignoff: boolean;
  constantineSignoff: boolean;
  thirtyDayRecheckAt: string | null;
}
