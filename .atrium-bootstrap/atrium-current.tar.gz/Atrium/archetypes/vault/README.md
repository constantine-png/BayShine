# Digital Product Vault

Faceless storefronts on Gumroad and Polar selling focused digital
assets. The fastest-ramp archetype in the town.

## First-generation product lineup

| Product | Price | Notes |
|---|---|---|
| Vertical Astro starter (detailing) | $79-249 | Forked from `src/`, tokenized for any service business |
| Vertical Astro starter (HVAC) | $79-249 | Sibling of detailing starter |
| Schema pack (LocalBusiness) | $19-49 | JSON-LD blocks per vertical |
| Schema pack (Service + FAQPage) | $19-49 | Composable units |
| llms.txt template pack | $19-39 | One template per vertical |
| AI-citation audit deliverable templates | $49-99 | The PDF Citation's free Scan emits, sold standalone |
| Agent-definition pack | $39-99 | Our descendant agent definitions packaged for other developers |
| Notion AI-readiness tracker | $19-49 | Dashboard for local-business AI presence |

## Builder

`static-site-builder` for the Astro starter forks. The schema
packs and llms.txt packs come directly from `schema-specialist`
and `geo-ai-search-specialist` output.

## Distribution

- Gumroad as primary marketplace (broader audience, lower
  fees for small developers).
- Polar as secondary (newer, more developer-focused, growing).
- Lemon Squeezy as tertiary if either of the above
  underperforms.
- Owned newsletter mentions.
- Twitter/X threads on each product launch.
- SEO via product landing pages on a dedicated subdomain.

## Operator (post-installation)

`operator-vault` (created at Phase 6).

## Sub-businesses (post-maturity)

See `spine/PLAN.md` Archetype 1 — Vertical-Specific
Starter Studios (one per vertical, becoming its own
storefront), Pack Subscription Service ($19/mo monthly drops),
Bundle Tier ($499-999), White-Label Reseller Tier ($999+ with
revenue share).

## Status

Scaffolding only. First three products target end of Week 1.
