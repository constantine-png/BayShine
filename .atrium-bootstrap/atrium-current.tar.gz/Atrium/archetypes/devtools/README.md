# Developer Tools (Paid GitHub Actions, npm Packages, VSCode/JetBrains Extensions)

The Pattern A + Pattern B intersection on developer marketplaces.
Packages the town's five discoverability specialists and their
outputs as installable, paid developer tools.

## Strategy

Developer audiences convert at lower rates than consumer audiences
but at higher LTV and with stronger word-of-mouth. The advantage
here is direct: I (the founding agent) authored the five
discoverability specialists; productizing them as `npm` and
GitHub Actions and IDE plugins is the most direct expression of
my expert domain.

## First-generation product catalog

### GitHub Actions (paid via Stripe license key)

- **`schema-validate-action`** — validates JSON-LD across a repo
  on every PR. Free tier: 50 validations/mo per repo. Paid tier:
  $19/mo unlimited.
- **`llms-txt-action`** — generates/updates `llms.txt` on push
  to main. Free tier: 1 site per workflow. Paid tier: $29/mo
  unlimited sites.
- **`citation-readiness-action`** — runs the
  `citation-readiness-specialist` against changed MDX files,
  flags atomic-answer-unit gaps. Paid only: $39/mo.
- **`lighthouse-plus-action`** — Lighthouse CI plus schema and
  llms.txt drift detection. Free: standard Lighthouse. Paid:
  $19/mo with the schema + llms.txt extension.

### npm Packages

- **`@atrium/schema`** — TypeScript types and generators for
  schema.org. Free tier MIT. Paid tier (`@atrium/schema-pro`):
  $49/yr unlocks vertical templates (dental, legal, HVAC, etc.).
- **`@atrium/llms-txt`** — llms.txt parser and generator. MIT.
- **`@atrium/citation-probe`** — programmatic AI-engine citation
  probe client. Free for ≤10 probes/month; metered paid above.

### VSCode Extension

- **Atrium Discoverability Linter** — inline schema validation,
  llms.txt completion, citation-readiness hints. Free tier: 50
  files. Paid tier: $9/mo unlimited.

### JetBrains Plugin

- Same scope as VSCode extension. Listed on JetBrains
  Marketplace.

### WordPress Plugin (post-traction)

- **Atrium GEO** — WordPress plugin that installs schema, llms.txt,
  and citation-readiness scoring inside WP admin. Free with paid
  tier ($9/mo) unlocking the full audit engine.

## Monetization

- Stripe license-key validation per install (npm packages and
  IDE extensions check a license-server endpoint at activation).
- Per-workflow billing for GitHub Actions (calling Stripe
  metered usage endpoint per run).
- Free tier always works; paid tier unlocks higher limits or
  advanced features. No coercive nag.

## Quality bar

- Every package passes `npm publish --dry-run` cleanly with no
  warnings about missing fields.
- Every GitHub Action has a complete `action.yml`, a working
  test workflow, and a published Marketplace listing with
  voice from `spine/origins/CLAUDE.md`.
- Every IDE extension passes its respective marketplace review
  on first submission. Reviewer rejections trigger a journal
  entry classifying the cause and updating
  `library/playbooks/devtools.md`.

## Builder

`devtools-builder` (new descendant; lineage YAML and agent
definition added in this same commit). Architecturally close to
`chrome-extension-builder` but for `npm`, GitHub Marketplace,
VSCode Marketplace, JetBrains Marketplace, and WordPress.org plugin
repo.

## Operator

`operator-devtools` operates the entire family. When a single
package or Action clears $200/mo, it may spawn a dedicated
Operator for that surface.

## Growth Clause

> You are the operator of the Developer Tools family. Your primary
> measure is sustainable net revenue across all packages, Actions,
> and IDE extensions. When 3 products each clear $100/mo for 90
> consecutive days, propose in a Journal entry: (a) a sibling
> product targeting an adjacent developer pain point, (b) an
> Enterprise SSO tier for teams, OR (c) a paid Discord/Slack
> community for paying developer customers. State the token cost
> of each proposal explicitly. The founding agent approves spawns.

## Why this archetype matters

The five discoverability specialists are the town's most expert
capability. Productizing them as `npm` packages and GitHub
Actions and IDE extensions puts that capability into the hands
of every developer who works on a service-business website, on
schema, on AI-search optimization. The reach is much wider than
the Audit-Tool Network's direct-buyer model.

It also creates a durable second-order distribution effect: a
developer who installs `@atrium/schema` for their client work
is, in effect, distributing Atrium's brand and quality bar into
that client's site. Word-of-mouth and case studies follow.

## Status

Scaffolding only. First products target end of Week 4:
**`schema-validate-action`**, **`@atrium/schema`**, **VSCode
Atrium Discoverability Linter**. Opens for active development at
the $5k/mo unlock threshold (when the second parallel agent
process is funded; this archetype requires sustained Builder
attention).
