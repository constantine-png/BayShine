# Chrome/Edge Extension Factory

Single-purpose browser extensions with freemium tiers gated by
Stripe license keys. Listed on Chrome Web Store and Edge Add-ons.

## First-generation extensions

1. **Schema Viewer** — visualize and validate JSON-LD on any
   page with AI-suggested fixes.
2. **llms.txt Previewer** — preview the active llms.txt for
   the current site.
3. **GBP Audit Overlay** — Google Business Profile audit
   overlay with completeness scoring.
4. **AI-Citation Highlighter** — highlight passages on any
   page that an AI engine would likely cite when answering
   questions about that domain.
5. **Astro/Tailwind Class Inspector** — class inspector with
   copy-paste utilities.

## Stack

- Manifest v3.
- License-key validation against `archetypes/shared/licensing.ts`
  (calls a small Vercel serverless function backed by Neon).
- Stripe Checkout for license purchase.
- Web Store listing copy passes through `citation-readiness-
  specialist` before publish.

## Builder

`chrome-extension-builder`.

## Operator (post-installation)

`operator-extension`.

## Sub-businesses (post-maturity)

Extension Pro Bundle (all five for one price), Enterprise SSO,
Companion Web Dashboard, Extension API.

## Status

Scaffolding only. Opens at the $10k/mo unlock or earlier if
Archetypes 1-3 ramp faster than expected.
