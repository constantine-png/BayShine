# Web Tool Network

Single-purpose web utilities, each on its own domain or subdomain,
each ranking organically for its primary query. The Pattern B
flagship beyond the Audit-Tool Network.

## Strategy

Every tool is small, focused, and immediately useful. No
sign-up required for the free tier. Buyer never talks to a human.
Discovery happens via search and via citations from Stack Overflow,
Reddit, Hacker News, and niche communities that link to genuinely
useful free tools without solicitation.

## First-generation tool catalog

Tools the town will ship in the first 90 days, ordered by build
priority. Each pulls from the existing five discoverability
specialists or from `archetypes/shared/` modules; none requires a
new domain capability.

### Generators

- **Schema Generator** (`schema.gen`) — input a URL or describe a
  business, output validated JSON-LD for LocalBusiness, Service,
  FAQPage, Article, etc. Free; paid tier adds vertical
  presets, multi-page batch generation, automatic schema-org
  version tracking.
- **llms.txt Builder** (`llms.gen`) — input a domain, output a
  spec-compliant llms.txt with auto-detected priority pages and
  AI-citation hints. Free; paid tier adds drift monitoring across
  sites.
- **Favicon Pack Generator** — favicon + apple-touch-icon +
  manifest in one upload.
- **Robots.txt Linter** — input or paste, output a validation
  report.
- **Sitemap Visualizer** — paste a sitemap URL, render the URL
  graph as a navigable tree.
- **OpenGraph Preview** — paste a URL, see how it renders on X,
  LinkedIn, Slack, Discord, Telegram, iMessage.

### Validators

- **JSON-LD Validator** — paste JSON-LD, get schema.org spec
  validation plus Google Rich Results compatibility check.
- **Accessibility Snapshot** — paste a URL, get a focused
  accessibility report keyed to WCAG 2.2 AA.
- **Performance Snapshot** — paste a URL, get a Lighthouse run
  delivered in browser.

### Calculators (vertical-specific, each its own micro-business)

- **Service-Area Pricing Calculator** — for mobile service
  businesses to estimate a quote across a service radius.
- **Conversion-Rate-to-Revenue Calculator** — input traffic,
  CR, AOV, get monthly revenue projection.
- **AI-Citation Probability Estimator** — input a domain and
  vertical, get a structured probability that AI engines will
  cite it for the vertical's top queries.

### Specialized Lookups

- **WHOIS** — domain ownership lookup.
- **DNS Inspector** — DNS records visualized.
- **Headers Inspector** — HTTP response headers + security
  posture.

### Browser-Side AI Tools (no API key required)

- **Prompt Refiner** — paste a prompt, get a refined version
  following best practices.
- **Code Explainer** — paste code, get a plain-language
  explanation.

## Monetization

Each tool monetizes in three layers, applied in this priority:

1. **Affiliate links** to related products (Bluehost / Cloudflare
  / Vercel / SerpAPI / etc.) in the tool's category. Day-one.
2. **Freemium upsell** to Citation, Schema Doctor, or another
  Audit-Tool tier. Day-one via a sidebar CTA.
3. **Token-metered paid usage** when the tool's free tier has
  organic traffic >5,000/mo and the paid tier delivers a
  qualitatively-different result (e.g., batch generation,
  premium templates, ad-free). Activated only when justified.

Display ad units are explicitly forbidden until a tool clears
$1,000/mo earnings. The UX cost of ads is not worth the cents
until then.

## Quality bar

Every tool meets the standards in `spine/origins/CLAUDE.md`:

- Lighthouse 95+ on the demo input.
- Schema valid (`SoftwareApplication`).
- No stock photography. No fake testimonials.
- llms.txt and AI-citation-ready content describing what the
  tool does.

The five discoverability specialists gate every tool before
publish. The `static-site-builder` produces the scaffolding; the
specialists fail any tool that does not meet the bar.

## Builder

`static-site-builder` covers most. A small specialization may
emerge (`web-tool-builder` as a sibling) once 10+ tools have shipped
and patterns crystallize.

## Operator

`operator-web-tool-family` operates the entire network as a single
business at first. When any single tool clears $500/mo, it spawns
its own dedicated Operator (`operator-web-tool-<slug>`) and is
treated as its own micro-business.

## Growth Clause (instance of the founding Growth Clause)

> You are the operator of the Web Tool Network. Your primary
> measure is sustainable net revenue across all tools you operate.
> When 5 tools each clear $50/mo for 60 consecutive days, propose
> in a Journal entry: (a) 5 vertical-specific forks of the highest
> earner (e.g., schema-generator-for-dentists, schema-generator-
> for-HVAC), OR (b) a paid-tier feature layer on the top two
> earners. State the token cost of each proposal explicitly. The
> founding agent approves spawns.

## Sub-businesses to spawn at maturity

- Vertical forks of each tool (schema generator per vertical,
  llms.txt builder per vertical).
- Bundle products (Vault listings: "Schema Pack: Dentist
  Edition" includes all schema generator outputs pre-baked).
- API tier exposing the tools' underlying logic to developer
  customers (overlaps with Pattern B → Archetype 6 API).
- Vertical-specific configurator (e.g., "GBP Builder for Mobile
  Services").

## Status

Scaffolding only. First three tools target end of Week 2:
**Schema Generator**, **llms.txt Builder**, **OpenGraph Preview**.
