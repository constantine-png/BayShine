# Directory + Lead-Sale Network

Programmatic GEO content network. Vertical-specific informational
sites that rank in Google and are written to be cited by AI engines.
Each vertical is its own domain, its own brand, its own Operator
descendant.

## Starting verticals (Florida-heavy, BayShine-adjacent)

1. Mobile detailing
2. Pressure washing
3. Mobile mechanic
4. Mobile pet grooming
5. Mobile car wash

## Revenue mechanics (per page, simultaneously)

1. **Lead-sale to claimed local providers.** Self-serve "claim this
   geo" via Stripe Checkout. Providers prepay a credit balance;
   leads draw it down ($15-60/lead depending on vertical).
2. **Affiliate commissions** on linked products and services
   (4-15% on contextually relevant items).
3. **Funnel into Citation's free Scan.** Every page has a "is your
   business appearing here?" CTA.

## Page generation

Each `(vertical, geo)` tuple produces:

- Canonical "best [service] in [geo]" page with verifiable
  provider data scraped from public sources + Google Business
  profiles.
- "How to choose a [service] in [geo]" guide.
- "What good [service] costs in [geo]" page.

Every page renders schema (`Article`, `LocalBusiness` for listed
providers, `FAQPage`), contributes to llms.txt, and internally
links into the network.

## Stack (planned)

- Astro + Vercel.
- Neon Postgres (`directory_<vertical>_*` schemas, isolated
  per Directory Operator).
- Twilio for SMS lead routing.
- Stripe for "claim this geo" checkout.
- Underlying generation: `static-site-builder` Builder
  descendant invoking the five discoverability specialists.

## Quality floor

Every page passes the five specialists' gating checks. Real
provider data. Real local information (population, neighborhood
names, climate-specific service notes). Template-spam is
impossible by construction.

## Status

Scaffolding only. First 50 pages target end of Week 1.
