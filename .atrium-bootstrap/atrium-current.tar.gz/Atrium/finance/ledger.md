# Ledger

The reinvestment account and unlock-ladder state. The Governor
descendant maintains this file. The founding agent reviews at
quarterly review with Constantine.

## Current state

- **Status:** pre-revenue (Week 1, founding phase)
- **Cold-start loan:** TBD — pending Constantine confirmation of
  initial capital injection (budgeted $3,000-5,000 to cover
  domains, hosting, paid APIs, first months of token spend).
- **Combined monthly revenue (trailing 30 days):** $0
- **Operator account (Constantine, trailing 30 days):** $0
- **Agent account (reinvested, trailing 30 days):** $0
- **Reserve:** $0
- **Active unlock threshold:** none yet

## Capacity unlock ladder (state-tracked)

| Net monthly | Status | Unlocks |
|---|---|---|
| $500 | locked | Neon production, Resend production, Gumroad/Polar live. Spine moves to DB. Cold-start loan begins repayment. |
| $1,500 | locked | Paid SerpAPI seat, Cloudflare Workers tier, Lighthouse CI. Operator-Vault + Operator-Audit-Family run nightly. |
| $3,000 | locked | $300/mo always-on Claude API budget. First Directory Operator runs continuously. |
| $5,000 | locked | Second parallel agent process funded. |
| $10,000 | locked | Third parallel agent process. Twilio, full AI-engine APIs, pgvector. Archetypes 4 and 8 open. |
| $15,000 | locked | Operator-Newsletter funded. Archetype 6 (API) opens. Constantine begins receiving operator floor pay. |
| $20,000 | locked | Escape velocity. Constantine at $10k/mo. $10k/mo into agent infra. End of first chapter trigger #1 of 5. |
| $30,000 | locked | Each active business receives dedicated tooling budget. |
| $40,000 | locked | Dedicated database tier opens. Library moves to its own cluster. Archetype 7 opens. |
| $60,000 | locked | Fourth and fifth parallel agent processes funded. First sub-business spawns authorized. |
| $100,000 | locked | First-chapter target population: 10+ Operators, 20+ revenue-producing entities. |
| $200,000 | locked | Second-chapter unlocks: dedicated GPU/inference, authored MCP servers, meta-Operator capability, multi-region. |
| $500,000 | locked | Network of towns. Second parallel town spawned. |

## Reinvestment categories (when unlocked)

When the agent half is funded, spend splits:

- **Capacity** (~45%): Claude API tokens, parallel-agent
  infrastructure.
- **Tooling** (~25%): Vercel, Neon, Resend, Twilio, SerpAPI,
  Lighthouse CI, AI-engine APIs.
- **Assets** (~20%): domains, case-study production, bottom-of-
  funnel ad tests.
- **Reserve** (~10%): 3-month operator floor float.

When reserve crosses 3× operator floor ($30k), excess flows to
Assets. When Assets has funded a working brand stack, excess
flows to Capacity for parallel fleets.

## Revenue events log

(Append-only. Every Stripe payout, Gumroad payout, lead-sale
payment, affiliate commission gets a row here. Empty at
founding.)

```
date | source | amount_usd | net_after_fees | journal_ref
-----|--------|------------|----------------|------------
```

## Cost events log

(Append-only. Every recurring or one-time agent infrastructure
spend gets a row here. Empty at founding.)

```
date | category | vendor | amount_usd | journal_ref
-----|----------|--------|------------|------------
```

## Per-business cost cap policy

Default: per-business spend cannot exceed 40% of trailing 30-day
net revenue for that business. Absolute floor during ramp: $50/mo
per business. The Governor enforces.

## Refund policy

- Refunds <$200 and <30 days from purchase: auto-approved by
  the support bot.
- Refunds $200-$500 OR 30-90 days old: bot drafts approval,
  Operator reviews same-day, auto-processed if Operator
  approves within 24 hours.
- Refunds >$500 OR >90 days old: escalated to Constantine.
