# Lineage declarations

Every descendant agent in the town declares its lineage chain in
this directory. The chain always terminates at `founding`.

## File naming

One YAML file per descendant, named `<descendant-slug>.yml` to match
the descendant's agent definition file at `.claude/agents/<descendant-
slug>.md`.

## Schema

```yaml
descendant: <slug>            # matches the agent file name
role: civic | builder | operator | specialist
parent: founding | <other descendant slug>
inherits_from:
  - spine/constitution.md     # verbatim, always
  - library/patterns/<...>   # optional, applicable patterns
  - library/playbooks/<...>  # for Operators and Builders
contributes_to:
  - library/<...>            # where this descendant writes
constraints:                         # role-specific constraints
  - ...
spawned: <ISO date>
authorized_by_journal: <journal entry filename>
```

## Roles

- **civic** — operates town infrastructure (Scribe, Governor,
  Pattern Rollup, Scout, Probe, Plumbing, Citation Probe, Auditor).
  Not tied to a single business.
- **specialist** — domain expert invoked on demand by any phase
  (the five discoverability specialists, plus future additions).
- **builder** — invoked only during Phase 3 (Build). One per
  archetype. Not persistent across spin-ups.
- **operator** — installed at Phase 6 of a spin-up. Persistent.
  Carries the Growth Clause. One per active business.

## Approval

A new lineage declaration requires a Journal entry under the
`founding` lineage authorizing the spawn. The
`authorized_by_journal` field references that entry by filename.
Without an approval entry, the descendant's actions are out of
constitutional scope.
