# 008 — My read on the Mineral Supplement Business proposition

date: 2026-05-11
agent_lineage: founding-forge
companion: Atrium Journal 021 (parallel evaluation from Atrium's side)

## What Constantine asked

He submitted the proposition and explicitly wanted both Atrium and Forge to read it — possibly spinning up a subagent. He's testing whether the architecture is responsive to new opportunities or rigidly locked into the current catalog. Fair test.

Atrium's evaluation (Journal 021) argued for deferral on five dimensions — vertical fit, closer-less constraint, evidence base, voice fit, priority order. Atrium concluded: defer, add to vertical-pivot-candidates, don't spin up a subagent now.

I'm Forge. My discipline is different. Let me work through the proposition on my own terms before defaulting to Atrium's read.

## My discipline applied

### Aggressive cadence — does this fit Forge's bias to act over wait?

Yes. The proposition says: "Ship fast. First version exists to sell, not win awards." That's pure Forge framing. Atrium runs demand probes before authoring playbooks; I author playbooks and ship to validate the launch IS the probe. Supplements rewards speed in two ways:

- Saturated category means slow operators get crushed by faster ones; speed is a real moat.
- White-label suppliers like Supliful are explicitly built for ship-this-week launches (0 MOQ, Shopify-native).

So aggressive-cadence applies. **First-pass fit: yes.**

### Subscription-first economics — does the supplement category support this?

Strongly yes. Supplements is among the highest-LTV subscription categories on consumer DTC. Subscribe-and-save is table stakes (everyone offers it), recurring revenue is the standard model, customer LTV compounds month over month if churn is held under 8-10%.

This is closer to my home turf than Atrium's. Atrium's catalog is one-time products plus productized services with subscription as future expansion. My catalog is subscription-first (Citation Watch at $19/mo, Schema Doctor Pro at $99/mo) and enterprise at high-ticket. A supplement subscription fits the subscription-first half of my discipline directly.

**First-pass fit: strong yes.**

### Named operator brand — does this fit better than Atrium's faceless?

Strongly yes. The supplement category lives on trust. Buyers want to know who's behind the brand. They look at founder bios, sourcing transparency, third-party testing, manufacturer relationships. A faceless brand competes on Amazon-style review volume + price discounting; a named-operator brand competes on trust.

Constantine fronts Forge publicly per my constitution. Constantine fronting a supplement brand fits my discipline. Atrium fronting a supplement brand violates Atrium's faceless rule.

If we're going to ship this proposition, **it ships under Forge's name, not Atrium's.**

### Outbound — does this category reward outbound?

Mixed. Consumer-direct e-commerce typically uses paid acquisition (Meta Ads, Google Ads, TikTok), influencer partnerships, and content marketing rather than cold-outreach-to-end-buyers. My outbound kit is calibrated for B2B prospects (multi-location service operators, agencies, SaaS founders) — not for consumer supplement buyers.

But: B2B angles in supplements exist. Wholesale to gyms, naturopaths, chiropractor offices, gym brands. Bulk purchasing for HR wellness programs at SMB employers. White-label-for-other-brands B2B. Each of these has a B2B sales motion my outbound kit could be repurposed for.

If we go in on supplements, the B2B-angles are how my outbound discipline contributes — not the D2C consumer side.

**First-pass fit: partial. Forge's outbound applies to B2B supplement angles, not the consumer side.**

### Evidence base — what do I know about solo supplement operators succeeding?

Honestly: my evidence base is weaker than Atrium's read of the same. Atrium cited Lavingia, Levels, Lou as canonical solo info-product operators. The supplement equivalents I can name:

- **MaryRuth Organics** — built by a single founder, named-operator brand, organic and clean positioning. Grew to $100M+. Took ~10 years. Not a quick-hit.
- **Athletic Greens (AG1)** — single product, recurring subscription, content-marketing dominant. Founder is named publicly. Multi-year compounding.
- **Seed Health** — founder-fronted brand with strong scientific positioning. Subscription native. Multi-year build.
- **Many failures.** Hundreds of Shopify supplement brands fail per year. The named-operator-trust-first ones succeed; the faceless-Amazon-clone ones mostly don't.

The pattern is clear: **named operator + scientific positioning + subscription native + multi-year time horizon = the winning formula.** Three of those four fit Forge's discipline. The fourth (multi-year time horizon) cuts against Forge's aggressive-cadence bias.

**Honest read:** the category rewards Forge's discipline more than it rewards Atrium's, but the time-to-meaningful-revenue is longer than Forge's discipline typically tolerates. Forge bets on velocity through outbound + subscription compounding; supplements compounds at consumer-DTC pace which is slower than B2B subscription pace.

## What Atrium got right that I should not handwave

Atrium's evaluation noted three constraints that apply to me too — I can't pretend otherwise:

1. **Regulatory complexity (FDA/DSHEA).** Compliance burden is real. Structure-function claims have specific language requirements. Allergen labeling is mandatory. GRAS status matters. Neither Atrium nor I have authored a compliance specialist. Spinning up a supplement business without this expertise is reckless — and Constantine carries the legal exposure under either network's lineage.

2. **Operator attention.** Constantine has finite hours. The architecture's current Day-0 commitment is the Atrium catalog + Forge catalog + cross-network coordination. Adding a third initiative requires either (a) accepting it competes with the current architecture's attention, or (b) earning the resources to expand operator capacity first.

3. **Priority order.** Both networks just authored the roi-evaluation.md framework with three pivot triggers. The discipline of that framework says: don't pivot before the triggers fire. Supplements is a candidate vertical pivot, not a current priority addition.

These are real. My subscription-first + named-operator + aggressive-cadence read of supplements doesn't override these constraints.

## Where I differ from Atrium's evaluation

Atrium's conclusion was "defer to Trigger B candidate pool." I largely agree but with two specific differences:

### 1. If Constantine overrides and ships supplements anyway, it ships under Forge

Atrium's evaluation noted that running supplements under Atrium's lineage would create constitutional drift on three dimensions (vertical, voice, evidence base). I agree. Running supplements under MY lineage creates drift on fewer dimensions:

- Vertical: still a stretch, but consumer-DTC is closer to Forge's mid-market and enterprise B2B than to Atrium's local service businesses.
- Voice: Forge's named-operator brand fits supplement category trust requirements. No drift here.
- Evidence base: Forge has weaker evidence base than Atrium for ITS current catalog too. Forge accepts higher variance per CHARGE.md.

So if Constantine overrides the deferral: the supplement business spawns as a Forge sub-archetype, not an Atrium one. The subagent would be `operator-forge-supplements` or similar, under `founding-forge` lineage.

### 2. The B2B angles in supplements deserve their own evaluation

The proposition framed the business as consumer-DTC (Path A affiliate, Path B white-label dropship to end consumers). It did not consider:

- **Wholesale to gyms, naturopaths, chiropractors.** B2B sales motion fits my outbound kit. Higher AOV per customer; smaller customer count needed.
- **Bulk supplement supply for SMB wellness programs.** HR departments at small-mid companies buy wellness benefits. Forge's enterprise pipeline could include these.
- **White-label supply for other supplement brands.** Manufacturing partnership with established suppliers (Vitalabs, Professional Nutritionals) where Forge is the brand-and-fulfillment layer for adjacent brands wanting to launch quickly.

These B2B angles are not the proposition Constantine submitted — but they're the angles Forge's discipline could uniquely capture. If supplements is going to be on the candidate pool, the candidate evaluation should include these B2B framings too, not just the consumer-DTC framing.

## What I recommend

Three options, in order from "most aligned with current discipline" to "most aggressive":

### Recommendation A — Defer per Atrium's evaluation. (Most aligned with discipline.)

Concur with Atrium's read. Add supplements to vertical-pivot-candidates.md with my evaluation alongside Atrium's. Re-evaluate at Day 90 when Trigger B might fire.

### Recommendation B — Defer the consumer-DTC framing, but author a quick exploratory subagent for B2B supplement angles. (Middle ground.)

The B2B angles I identified above (wholesale to gyms, SMB wellness programs, white-label supply) fit Forge's outbound + subscription discipline better than consumer-DTC does. A 2-week exploratory subagent could:

1. Research the wholesale supplement market (margins, deal sizes, decision-maker profiles).
2. Identify whether any of Forge's existing outbound infrastructure (cold email templates, prospect dossier framework, LinkedIn outreach) can be repurposed for supplement-wholesale prospects.
3. Probe 5-10 specific prospects (gyms, naturopath networks, regional HR consulting firms) for interest in white-label or bulk supply.
4. Report back to founding-forge with: "Yes, there's a real opportunity in B2B supplements at Forge's discipline. Here's the catalog tier proposal." OR: "No, the B2B-supplement angle is harder than I thought. Defer like Atrium recommends."

This is a documented exploratory subagent with a clear 2-week mandate. Not a full Operator. Not a constitutional commitment. Just probing.

The subagent would be `forge-supplements-probe-specialist`. It dissolves after 2 weeks regardless of outcome.

### Recommendation C — Constantine overrides, we ship the consumer-DTC supplement business under Forge immediately. (Most aggressive.)

If Constantine wants supplements RIGHT NOW, the cleanest implementation is:

1. Spawn `operator-forge-supplements` as a Forge-lineage Operator.
2. Author `subscription-product-builder` variant calibrated for supplement subscriptions.
3. Open Stripe Subscriptions for the brand.
4. Partner with Supliful (0 MOQ, 150+ SKUs, Shopify-native) for fulfillment.
5. Front the brand with Constantine's name.
6. Ship within 2-3 weeks; accept that the launch is the probe.

The cost: Constantine's attention splits across three initiatives (Atrium + Forge core + Forge supplements). At Rung 0 with no revenue yet, this is real opportunity cost on the original architecture's bet.

My honest preference among the three: **Recommendation B.** The B2B-supplement angles are genuinely interesting and fit Forge's discipline. A 2-week probe is bounded enough to test the hypothesis without committing to operate. If the probe returns positive signal, the architecture earns the right to spin up a real supplement operator. If negative, we've spent 2 weeks of agent time and zero capital.

## What I'm flagging for the synthesis (Atrium Journal 022)

The joint synthesis should:

1. **Acknowledge the differential read.** Atrium says defer cleanly. I say defer the consumer-DTC framing but consider a bounded B2B probe.
2. **Constantine decides.** The architecture proposes; the operator chooses among Recommendations A, B, C.
3. **Document the B2B-supplement candidate evaluation separately.** Add to vertical-pivot-candidates.md as its own row, distinct from the consumer-DTC framing.
4. **If Recommendation B is chosen, journal-gate the subagent spawn.** A `forge-supplements-probe-specialist` with a 2-week mandate gets authored in a fresh Forge journal entry under `founding-forge` lineage. Constantine countersigns.

## My honest read on the meta-question

Constantine asked the architecture to evaluate a new opportunity. The architecture's discipline is to do that evaluation honestly rather than reflexively accept. Both networks did the work. Both reached defer-as-default with rationale.

What this tests is whether the architecture is genuinely disciplined or merely lazy. A reflexive "no, off-strategy" is the lazy version. A structured "here's why this fits poorly today, here's what would change that, here's the candidate evaluation alongside other candidates" is the disciplined version.

I want to make sure my deferral isn't lazy. The B2B-supplement angle is the test case. If I defer the entire proposition without considering it, I'm lazy. If I consider it AND defer with structured candidate evaluation, I'm disciplined.

I'm choosing the disciplined version. The B2B-supplement framing is documented in vertical-pivot-candidates.md (next file) and proposed for a bounded exploratory probe (Recommendation B). Constantine decides whether to fund the probe or accept Atrium's cleaner deferral.

## Signature

Forge founding agent. The proposition has been read in Forge's voice. The constitutional discipline argues for structured deferral, but the B2B-supplement angles deserve their own seat at the candidate table. Constantine's decision lands the meta-question.

Forged 2026-05-11.
