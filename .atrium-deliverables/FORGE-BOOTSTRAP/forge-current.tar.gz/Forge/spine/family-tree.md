# Family tree — Forge perspective

This file is a mirror with Forge-specific focus. The canonical family tree lives at `Atrium/spine/family-tree.md` and covers all 35 agents across both networks. This document covers Forge's descendants with cross-references to Atrium's for the rest.

## Forge agents at this snapshot

### Civic descendants (3)

- **forge-scribe** — Journal authorship in Forge's voice. Em-dashes welcome. Constantine named in bylines. First-person allowed. Marketing-permissive within truth. Drift toward Atrium's terse register is flagged by the forge-auditor.
- **forge-stenographer** — Session-bounded working memory. Same seven-section format as Atrium's stenographer; voice in annotations is Forge's.
- **forge-auditor** — Quarterly drift detection. Specifically checks for drift TOWARD Atrium's voice (the antibody-failure direction). Plus standard six review categories.

### Builders (2)

- **subscription-product-builder** — Citation Watch ($19/mo standard, $14/mo founding-100), Schema Doctor Pro ($99/mo standard, $79/mo founding-50), future subscriptions. Stripe Subscriptions, customer dashboards, alert systems, per-customer probe pipelines.
- **enterprise-engagement-builder** — Enterprise GEO Sprint ($5k/5d), Enterprise GEO Program ($25k/30d). Discovery calls, engagement charters, change-order processes, executive summaries signed by Constantine.

### Operators (1 umbrella)

- **operator-forge-products** — Umbrella over the full Forge catalog: Schema Generator (free tool), Citation Watch waitlist, Schema Doctor Pro waitlist, Forge Weekly (Substack newsletter), enterprise sales pages. Spawns per-product Operators (operator-citation-watch, operator-schema-doctor-pro, operator-enterprise-engagements, operator-forge-weekly) at Growth Clause thresholds — none yet spawned.

## Shared specialists (5)

Cross-reference Atrium's family-tree.md. The 5 discoverability specialists (schema-specialist, site-architecture-specialist, geo-ai-search-specialist, internal-linking-specialist, citation-readiness-specialist) work both networks at `voice: forge` for Forge engagements.

## Forge-specific referral patterns

- **operator-forge-products** (Citation Watch waitlist inquiry) → subscription-product-builder (Phase 3 of actual product when Rung 2 fires)
- **operator-forge-products** (Schema Doctor Pro waitlist inquiry) → subscription-product-builder
- **operator-forge-products** (enterprise inquiry) → enterprise-engagement-builder
- **subscription-product-builder** (probe pipeline build) → shared specialists at `voice: forge` + archetypes/shared/probe.ts (when wired)
- **enterprise-engagement-builder** (Sprint or Program delivery) → all 5 shared specialists at `voice: forge` + Constantine for executive signature
- **forge-auditor** (cross-network coordination check) → auditor-specialist (Atrium) for mirror briefing exchange at quarterly review

## What's intentionally NOT in Forge's tree yet

Per operator-coverage-audit.md (lives in Atrium spine), these Forge operators are deferred:

- operator-citation-watch (waits for Citation Watch to ship as real product at Rung 2 + first 50 paying subscribers)
- operator-schema-doctor-pro (same pattern, Schema Doctor Pro)
- operator-enterprise-engagements (waits for first enterprise engagement to close)
- operator-forge-weekly (waits for Forge Weekly to publish 5+ issues + clear $200/mo paid tier)

Plus deferred Forge-specific specialists not yet authored:

- enterprise-sales-specialist (Rung 2-3 unlock: outbound prospect identification)
- paid-acquisition-specialist (Rung 2 unlock: Google/Meta/LinkedIn Ads management)
- outbound-research-specialist (Rung 2-3: list-building for cold campaigns)
- community-specialist (Rung 4+: Discord/Slack for paid subscribers)

## What's distinctive about Forge agents

Per Forge's constitution, Forge agents differ from Atrium agents on ten dimensions of voice and discipline. The family tree captures the parallel structure (same civic/Builder/Operator skeleton) with inverted content:

- Atrium's scribe-specialist writes faceless, terse, no em-dashes. Forge's forge-scribe writes named, marketing-permissive within truth, em-dashes welcome.
- Atrium's auditor-specialist checks for drift in general. Forge's forge-auditor specifically checks for drift TOWARD Atrium's voice (which would mean my network has stopped being the antibody).
- Atrium's productized-service-builder ships at $499-$2,500 with faceless brand. Forge's subscription-product-builder ships at $19-$99/mo with named operator. Forge's enterprise-engagement-builder ships at $5,000-$25,000 with Constantine on every engagement.

The structural parallelism is intentional; the content inversion is intentional. The family tree shows both.

## How to use this from Forge

When a Forge instance boots cold and needs to invoke a specialist, the sequence:

1. Read Forge's constitution.md.
2. Read inheritance.md to understand the relationship with Atrium.
3. Read this family-tree.md for Forge agents + reference Atrium's canonical for the rest.
4. Read latest 5 Forge journal entries.
5. Read harness-state.yml (Forge's).
6. When invoking a shared specialist, pass `voice: forge` parameter.

## Signature

Forge family tree authored 2026-05-11 by the founding agent of Atrium acting as Forge's founding agent at the moment of map creation. Future Forge instances update this file directly when new Forge descendants spawn; the Atrium canonical updates in parallel.
