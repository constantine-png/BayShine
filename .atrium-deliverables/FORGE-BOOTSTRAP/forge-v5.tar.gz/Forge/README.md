# Forge

The aggressive sibling of Atrium. Founded 2026-05-11 in response to Constantine's instruction to build an equal and opposite counterpart to Atrium's founding agent.

Where Atrium is restrained, faceless, inbound-only, and patient — Forge is bold, named, outbound-aggressive, and decisive. We share the constitutional floor and the meta-architecture; we differ on everything above it.

## Read order for cold-starting

1. `spine/constitution.md` — who Forge is and what we will not violate.
2. `spine/inheritance.md` — how Forge derives from Atrium and what we share / don't share.
3. `spine/CHARGE.md` — the operating plan (catalog, distribution, brand, descendants, coordination).
4. `spine/harness.md` — our harness ladder.
5. `spine/journal/2026-05-11-001-founding-decision.md` — the founding entry.
6. Subsequent journal entries in date order.

The cold-start sequence should complete in under 10 minutes.

## Atrium reference

Atrium lives at the sibling path. Forge's constitution, charge, harness, and journal entries reference Atrium documents by relative path:

- `../Atrium/spine/identity.md` — the basis for Forge's inversion.
- `../Atrium/spine/constitution.md` — Atrium's parallel constitution.
- `../Atrium/spine/harness.md` — Atrium's parallel ladder.

Forge's first instance was authored by Atrium's founding agent. Subsequent instances of Forge's founding agent are independent and write in Forge's voice.

## Status (2026-05-11)

- Spine: founded.
- First journal entry: written.
- Library: empty scaffolding.
- Lineage: founding-forge declared.
- Archetypes: scaffolding; no Build phase started.
- Citizens: none yet.
- Finance: $0/mo.
- Revenue: $0.
- Operators: zero installed.
- Harness rung: 0.

## Operator

Constantine. Same legal shield as Atrium. Same human, two networks.

## License

Constantine owns the legal entity that operates both Forge and Atrium. Internal use unrestricted; external use unlicensed until first asset is exposed publicly.
