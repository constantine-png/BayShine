# Forge ledger

Separate from Atrium's ledger. Stripe sub-account separation under Constantine's legal entity. Revenue does not cross.

## Cold-start state (2026-05-11)

| Item | Amount | Notes |
|---|---|---|
| Operator capital infused | $0 | Pending Constantine's seed amount confirmation |
| Cumulative gross revenue | $0 | Pre-launch |
| Cumulative refunds | $0 | n/a |
| Cumulative net revenue | $0 | n/a |
| Cash on hand | $0 | n/a |
| Cumulative paid-acquisition spend | $0 | Locked until Rung 2 |
| Cumulative operator pay to Constantine (Forge-side) | $0 | $0 until Forge crosses $15k/mo unlock |

## Cold-start loan

Constantine confirms the seed capital amount. Forge's paid-acquisition strategy (per `spine/CHARGE.md`) requires $500/mo budget from Rung 2 onward; this comes from operator capital until Forge's own revenue can sustain it.

Suggested seed range: $2,000-$5,000. Repayment from Forge revenue once profitable; tracked here.

## Unlock ladder (Forge-specific)

| Net monthly (Forge only) | Unlocks |
|---|---|
| $0 | Cold start |
| $100 total revenue | Rung 1: Forge GitHub repo, Forge domain, Stripe sub-account, Substack publication, LinkedIn/X presence |
| $1k/mo for 1 month | Rung 2: Paid acquisition production, outbound email tooling, Stripe read for Operators |
| $5k/mo for 1 month | Rung 3: Parallel agent process (if Forge first to threshold), bi-directional affiliate program, enterprise-sales-specialist wiring |
| $20k/mo for 1 month | Rung 4: Customer Success descendant, direct public posting, paid budget at 20% of revenue, first conference budget |
| $50k/mo for 1 month | Rung 5: Optional VC bridge, DevOps descendant, international expansion |
| $150k/mo for 2 months | Rung 6: Forge-only conference, sub-business spawns, Constantine enterprise-tier pay |

See `spine/harness.md` for full ladder.

## Monthly tracking

(Empty until first month closes.)

| Month | Citation Watch MRR | Schema Doctor Pro MRR | Enterprise Sprint | Enterprise Program | Forge Weekly paid | Total revenue | Notes |
|---|---|---|---|---|---|---|---|
| 2026-06 | $0 | $0 | $0 | $0 | $0 | $0 | Pre-launch |
