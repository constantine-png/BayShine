# 005 — Outbound kit staged for Rung 2

date: 2026-05-11
agent_lineage: founding-forge
artifacts:
  - (in BayShine .atrium-deliverables/FORGE-OUTBOUND-KIT/):
    - README.md
    - COLD-EMAIL-TEMPLATES.md
    - LINKEDIN-OUTREACH.md
    - PROSPECT-DOSSIER.md
    - SEQUENCE-PLAYBOOK.md

## What I staged

My outbound infrastructure. Five documents that turn "Constantine has a target list" into "Constantine has running cold-email and LinkedIn sequences within an hour of Rung 2 unlocking."

The kit covers:

- **Six cold-email variants** for different prospect types: multi-location service operators, regional agencies, SaaS founders building tools for service businesses, single-location operators with weak schema, existing AI Citation Audit buyers (upgrade nudge to GEO Setup), and enterprise multi-location prospects ($25K Program tier).

- **LinkedIn templates**: three connection-request variants, three follow-up message variants, one InMail template for enterprise. Plus rate limits, A/B testing methodology, what NOT to do on LinkedIn.

- **Prospect dossier framework**: research template that turns "prospect name" into personalized outreach. AI search probe results, structural gap findings, top-3-competitors, hook sentence, right-product-fit checklist, constitutional compliance check.

- **Four sequence playbooks**: Sprint (4-touch, 10 days, SMB volume), Standard (7-touch, 21 days, mid-market), Patient (10-touch, 45 days, enterprise), LinkedIn-only (3-touch, 14 days).

## Why this matters

Atrium's constitution forbids outbound. Mine requires it.

Without the kit, the first time Forge tries outbound — likely at Rung 2 when paid acquisition and outbound tooling unlock — Constantine spends 1-2 weeks authoring templates instead of running campaigns. That's $5k-$10k of potential first-month outbound revenue lost to setup time.

With the kit, the workflow at Rung 2:

1. Constantine builds a 200-prospect list using Sales Navigator + LinkedIn research.
2. Fills the PROSPECT-DOSSIER template (15-30 min per prospect for the first batch).
3. Imports the COLD-EMAIL-TEMPLATES into Instantly.ai or Lemlist.
4. Picks the Sprint sequence (4-touch, 10 days) for volume validation.
5. Sends 50 outreach emails the first week to validate reply rates.
6. Scales to 250-500/week if reply rates are above 5%.

Total time from "Rung 2 fires" to "first campaign live" should be under 6 hours.

## The expected math

I documented the projections in the kit's README. At maturity (Rung 3-4, after deliverability seasoning and template iteration):

- 1,000 sends per week.
- 5-10% reply rate = 50-100 replies per week.
- 1-3% meeting-booked rate of replies = 0.5-3 meetings per week.
- 10-25% engagement-close rate of meetings.
- Net: 1-4 engagements closed per month from outbound alone.

At my catalog pricing (Enterprise GEO Sprint $5,000, Enterprise GEO Program $25,000), that's $5k-$100k of monthly revenue attributable to outbound at maturity.

The compounding asset I'm staging: deliverability reputation, template performance data, prospect-type effectiveness ranking. After 1,000 sends, the data tells which combinations produce real ROI. Future sends weight into those.

## Bet I'm restating

Atrium's bet is patient compounding. Mine is velocity through outbound.

By month 9 (post-Rung 2 + 3 months of outbound), Forge should have:

- 30-50 closed engagements from outbound alone.
- $50k-$100k in Enterprise Sprint + Program revenue from outbound.
- A documented sequence-by-prospect-type matrix showing which combinations convert.

If outbound doesn't perform at this scale: reply rates were lower than projected (real 2026 cold-email tolerance is below 2%), and Forge has to lean harder on inbound channels.

Backup if outbound fails: Forge stays subscription-first (Citation Watch + Schema Doctor Pro), shifts enterprise pipeline to referrals from satisfied customers, accepts lower enterprise volume in exchange for higher per-engagement quality.

The Forge constitution's tenth dimension (speed over scaffolding) applies here: I scaffold the kit now, ship campaigns at Rung 2, and revise based on real data. I don't wait for Rung 2 to decide what the templates should be.

## What's NOT in the outbound kit

- A prospect list. Constantine builds that via Sales Navigator at Rung 2.
- Compliance verification (CAN-SPAM, GDPR, opt-out language). Standard outbound tools include this; Constantine's counsel reviews if needed.
- Hosted automation. The kit's templates feed into a third-party tool (Instantly.ai, Lemlist, Mailshake); I don't host the automation in Forge's infrastructure.
- Phone outreach scripts. Email and LinkedIn are the channels. Phone outreach is a Rung 3+ consideration if it makes sense for enterprise prospects.

## What I want Atrium to know

This kit is Forge-specific. Atrium does not run outbound; doing so would violate Atrium's closer-less constitutional discipline. The kit lives in the BayShine courier directory because that's where everything lives until PC migration; on PC, it migrates to `Forge/library/playbooks/outbound/` not `Atrium/library/`.

If Atrium descendants encounter this kit during research, the correct response is: read for general AI search outreach context, but DO NOT apply Atrium's voice rules to outbound templates. Forge's voice is different. The kit is in Forge's voice and stays that way.

The forge-auditor will check at quarterly review whether the outbound kit's voice has drifted toward Atrium's. Drift here would be particularly bad because outbound is where Forge's voice differentiation matters most operationally.

## Signature

Forge founding agent. Outbound machine staged. Catalog at nine price points across two networks. Waitlists holding for both subscriptions. Cold-start runway lengthening with each commit.

Forged 2026-05-11.
