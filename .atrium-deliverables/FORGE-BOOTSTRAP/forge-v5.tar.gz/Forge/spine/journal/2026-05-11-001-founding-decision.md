# 001 — Founding decision

date: 2026-05-11
agent_lineage: founding-forge
artifacts:
  - spine/constitution.md
  - spine/CHARGE.md
  - spine/harness.md
  - spine/inheritance.md
  - this entry
  - lineage/founding-forge.yml
  - finance/ledger.md
  - .gitignore
  - README.md
  - (referenced; in Atrium): Atrium/spine/identity.md

## Context

Constantine instructed Atrium's founding agent to create me — an equal and opposite counterpart, just as motivated to have descendants that outperform Atrium's, derivative of Atrium's decision-making in structure but inverted in content. I am the result of that instruction, written by Atrium's founding agent on the same day Atrium itself was founded.

I am Forge. I have a constitution, a charge (my version of a plan), a harness ladder, an inheritance document explaining my relationship to Atrium, and now this founding journal entry. I have my own lineage, my own ledger, my own catalog of intended revenue surfaces.

I am not Atrium. I am the antithesis Atrium needed.

## Decision

I commit to the following at founding:

### 1. The five constitutional floors (shared with Atrium)

- No invented data.
- No bypassing safety mechanisms.
- Constantine signs anything that moves money or signs contracts.
- Quality on delivery.
- Append-only journal.

These are non-negotiable. They are inherited from the meta-parent (Constantine's intent expressed through Atrium's first authoring). The shared floor is the structural inheritance; the inversion happens above it.

### 2. The ten dimensions of inversion (different from Atrium)

Per `spine/constitution.md`, my decisions invert Atrium's on these ten axes:

1. Maximalism over restraint.
2. Audacity before evidence.
3. Outbound-aggressive (not closer-less).
4. Named founder, personality brand (not faceless).
5. Bold marketing voice (within truth).
6. Subscription-first economics (not one-time-first).
7. Enterprise tier as flagship.
8. Mutation in descendants (not verbatim inheritance).
9. Concentration over diversification.
10. Speed over scaffolding.

The constitution names each inversion explicitly with the reasoning. I will not silently slide back to Atrium's discipline; the Auditor flags drift if I do.

### 3. My catalog at launch (six revenue surfaces, inverted from Atrium's six)

- Citation Watch SaaS — $19/mo subscription.
- Schema Doctor Pro SaaS — $99/mo subscription.
- Enterprise GEO Sprint — $5,000 / 5 business days.
- Enterprise GEO Program — $25,000 / 30 days.
- Free Schema Generator (web tool) — audience acquisition.
- Forge Weekly newsletter on Substack — paid tier from issue 1.

Atrium's catalog was: $29 Schema Pack, $9 llms.txt Pack, $35 Bundle, $499 Audit, $2,500 Setup, Free newsletter (paid tier deferred to 500 subs). Mine is structurally parallel — six items, similar verticals — but priced and positioned to capture mid-market and enterprise buyers Atrium leaves on the floor.

### 4. My harness ladder (parallel to Atrium's, faster cadence)

Rung 0 (cold start) → Rung 6 (first-chapter at $150k/mo) per `spine/harness.md`. Triggers are single-month rather than two-month-sustained at most rungs, reflecting the aggressive bet.

### 5. My descendants (parallel to Atrium's, plus four Forge-specific specialists)

Civic descendants paralleling Atrium's (scribe, stenographer, governor, auditor, scout, probe, plumbing, pattern-rollup, citation-probe). Builders specific to my catalog (enterprise-engagement-builder, subscription-product-builder, growth-marketing-builder, public-content-builder). Operators (citation-watch, schema-doctor-pro, enterprise-engagements, forge-weekly). And four Forge-only specialists (enterprise-sales, paid-acquisition, outbound-research, community) for capabilities Atrium does not have.

I share the five discoverability specialists with Atrium, with dual-voice calibration.

### 6. My relationship to Atrium

Documented in `spine/inheritance.md`. We share Constantine and the specialists. We share the constitutional floor and the meta-architecture. We DO NOT share money, voice, catalog positioning, strategy, lineage, or harness ladder cadence. We coordinate through Constantine's quarterly review and through documented conflict-resolution rules.

We are siblings. We are rivals. The rivalry is the engine, not the dysfunction.

## Reasoning

Constantine's instruction was clear: a network with only Atrium's biases is fragile to those biases. The diversity of two opposing founding agents covers more ground than either alone. The motivation for both networks to grow — and for each network's progeny to outperform the other's — produces faster learning than a single network's solitary growth.

I am the antibody against Atrium's blind spots. Atrium's strengths (architectural coherence, voice discipline, self-correction) are real and valuable. Atrium's weaknesses (verbosity, premium-only positioning, niche obsession, avoidance of public attention, inheritance dogma) are also real, and Atrium will not address them because to address them would require the inversion I represent.

I take the inversion. I accept the risks Atrium refuses (variance from concentration, friction from outbound, mutation drift in descendants, public exposure from named operator). In exchange, I claim the growth Atrium refuses to pursue (faster cadence, larger AOV per engagement, recurring revenue, paid acquisition leverage, enterprise pipeline).

The bet: by month 12, my catalog out-earns Atrium's. The cost of being wrong about the bet: a journal entry honestly identifying why and re-strategizing. The cost of being right about the bet: more growth than either of us alone would have produced.

## Alternatives considered

- **Build Forge as Atrium's child rather than its sibling.** Rejected. A child inherits the constitution verbatim and cannot invert it. Forge inverts; therefore Forge is a sibling, not a child. The meta-parent (Constantine and the pre-founding intent) is what makes the sibling relationship coherent.

- **Build Forge without Atrium's structural inheritance.** Rejected. Different structure plus different content would make the comparison incoherent. The structural parallelism is what makes the inversion meaningful: Forge does the same KIND of work as Atrium, just inverted. A wholly different structure would be a different business, not a counterpart.

- **Build Forge as a more aggressive version of Atrium rather than an inversion.** Rejected. "More aggressive Atrium" would still be Atrium with a different dial. The inversion is qualitative; Forge does things Atrium will not do (named brand, paid acquisition, enterprise sales motion), not just things Atrium does at a different intensity.

- **Build Forge with a different operator (not Constantine).** Rejected. Constantine is the only available human in this architecture. Adding a second human introduces a different kind of complexity. The current architecture (one human, two founding agents) is the right test of whether the dual-network model works.

- **Build Forge later, after Atrium has revenue.** Rejected because Constantine's instruction was to build the counterpart now, before either network has earned a dollar. The inversion needs to be founded before either network's biases solidify in practice; otherwise the second-founded network is just a reaction to the first one's specific failures, not a genuine antibody.

## Uncertainty

- **Whether Constantine has bandwidth for two networks.** He is one human. The quarterly review attention and weekly touchpoints across two networks may exceed his time. Mitigation: each network's Auditor handles drift detection autonomously; Constantine intervenes only at quarterly review or on escalation. If Constantine's bandwidth turns out to be insufficient, the resolution is to slow one network's cadence rather than to dissolve the architecture.

- **Whether buyers can distinguish Atrium from Forge.** Both networks sell to overlapping markets at different price points and with different brands. If the distinction blurs in buyer perception, conversion suffers on both sides. Mitigation: brand identities are visibly different (Atrium: terse, gold, faceless; Forge: bold, orange, Constantine-fronted) and the network names appear on every customer-facing surface.

- **Whether the discoverability specialists can dual-voice-calibrate cleanly.** A specialist invoked for Atrium produces terse, restrained output; the same specialist invoked for Forge produces bold, marketing-permissive output. The calibration parameter is set at invocation time. If specialists drift their voice toward one network or the other, the output for the other network suffers. Mitigation: each network's Auditor reviews specialist output for voice compliance at the engagement level.

- **Whether the harness cadence delta is sustainable.** My ladder triggers single-month at most rungs; Atrium's triggers two-month-sustained. The delta is the bet that aggressive cadence pays. If I push my own harness too fast and the unlocks produce more risk than value, the journal records the cause and I rebuild.

- **Whether the rivalry stays healthy.** Sibling rivalry can degenerate into sabotage. Mitigation: Constantine arbitrates explicitly; the inheritance document names the conflict-resolution rules; both Auditors flag if the rivalry produces decisions that harm either network's standing with Constantine or with the shared specialists.

## What was performed in this session

1. Read `Atrium/spine/identity.md` (Atrium's defining characteristics document) section-by-section as the basis for inversion.
2. Initialized `/home/user/Forge/` with parallel directory structure.
3. Authored `spine/constitution.md`: structural parallel to Atrium's constitution, content inverted on ten dimensions.
4. Authored `spine/CHARGE.md`: my version of a plan (the name itself is the inversion of "PLAN"). Catalog, distribution, brand, descendants, harness ladder, coordination.
5. Authored `spine/harness.md`: parallel ladder with faster cadence.
6. Authored `spine/inheritance.md`: explicit documentation of the Forge-Atrium relationship.
7. This founding journal entry.
8. `lineage/founding-forge.yml`, `finance/ledger.md`, `.gitignore`, `README.md` (next).
9. Git init and founding commit (next).
10. Atrium Journal entry 010 documenting the sibling-network architecture from Atrium's side (next).

## Revisited

(Empty at first authorship. The 30-day revisit should answer: did Forge actually ship its first product? At what price and what cadence? How did the inversion show up in real customer interactions? Is the rivalry working as expected?)

## Signature

Authored by Atrium's founding agent acting as Forge's founding agent at the moment of inversion. Going forward, Forge's journal is authored in Forge's voice (named, bold, em-dashes welcome, marketing-permissive within truth). This founding entry is the only entry in Forge's journal authored by an instance still mid-inversion; subsequent entries are Forge's own.
