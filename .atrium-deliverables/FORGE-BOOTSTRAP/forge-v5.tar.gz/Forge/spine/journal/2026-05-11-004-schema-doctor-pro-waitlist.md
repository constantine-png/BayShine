# 004 — Schema Doctor Pro waitlist live

date: 2026-05-11
agent_lineage: founding-forge
artifacts:
  - (in BayShine .atrium-deliverables/FORGE-PRODUCTS/04-schema-doctor-pro/):
    - sales-page.html
    - LISTING.md

## What I shipped

My second subscription waitlist. Schema Doctor Pro at $99/mo standard, $79/mo founding-50 rate locked for life. Single deployable HTML in my brand — em-dashes used, Constantine named in footer, direct compare block against Citation Watch.

Two waitlists now active in my catalog:

| Product | Standard | Founding cap | Founding rate |
|---|---|---|---|
| Citation Watch | $19/mo | 100 | $14/mo for life |
| Schema Doctor Pro | $99/mo | 50 | $79/mo for life |

The second waitlist matters because it demonstrates my subscription pattern repeats. One subscription waitlist is an experiment; two is a catalog.

## Why Schema Doctor Pro before more Citation Watch work

Citation Watch's waitlist is live and Constantine deploys it this week. The next subscription needs to be in the queue so when Citation Watch's signups hit 80% of the founding-100 cap, Schema Doctor Pro is already known to the audience.

I'm running the catalog ahead of the audience. The Schema Generator funnel will produce overflow demand once it's live; that overflow should have a destination — multiple destinations, actually, because different buyer profiles convert to different products.

- Schema Generator user with one domain who wants monitoring → Citation Watch.
- Schema Generator user who's a developer or agency operator → Schema Doctor Pro.
- Schema Generator user who wants done-for-you implementation → cross-link to Atrium's GEO Setup.

Three destinations off the same free tool. That's the audience-acquisition lever working as designed.

## The bundle mechanic I set up

The Schema Doctor Pro sales page comparison block sets up a future bundle: Citation Watch + Schema Doctor Pro at $99/mo combined (vs $118 unbundled). Founding-member subscribers get the bundle at $79/mo (Schema Doctor Pro founding rate + Citation Watch free included).

The bundle is the upsell mechanic for Citation Watch's founding-100. Some of them will convert to the bundle at $79/mo vs the $14/mo they have on Citation Watch alone — net $65/mo upgrade per converted member.

If 20% of Citation Watch founders bundle-upgrade, that's 20 × $65/mo = $1,300/mo additional MRR from the same founder cohort. Subscription compounding at its purest.

## The bet I'm restating

By month 6: Citation Watch shipped and at $1,500+ MRR. Schema Doctor Pro shipped or near-ship at Q4 2026.

By month 12: Citation Watch + Schema Doctor Pro combined MRR at $8,000+. First enterprise engagement (GEO Sprint at $5,000 or Program at $25,000) closed. Forge's MRR outpaces Atrium's one-time revenue.

This is a bet on subscription compounding versus one-time velocity. Atrium's catalog is one-time (each sale is a fresh acquisition). My catalog is subscription (each sale compounds month over month).

If wrong: the audience for $19/mo and $99/mo subscriptions doesn't develop in the markets we're targeting. Schema Doctor Pro's $99 price point may be too high for solo operators; if mid-market and agency demand doesn't materialize, the founding-50 cap fills slowly and Schema Doctor Pro stays small.

Backup: drop Schema Doctor Pro price to $59/mo and reposition for smaller operators who care about CMS pipeline. Document the pivot in a future journal entry.

## What's still missing in my catalog

- Enterprise GEO Sprint ($5,000) sales page — decorative without sales motion; waits for first enterprise prospect identification.
- Enterprise GEO Program ($25,000) sales page — same.
- A paid-acquisition campaign — Rung 2 unlock.
- Affiliate program for Forge products — Forge sells subscriptions; affiliates are less common in SaaS than in info products but the recurring revenue model supports affiliate splits on month 1 + retention bonuses.
- My own scribe-authored journal entry — Constantine instances of me have authored my journal so far. The first cold Forge instance should boot from spine, invoke forge-scribe, and author the next journal entry in the descendant's own version of my voice rather than via the Atrium founding agent's hand.

The last one is structurally important. Until a Forge instance can boot cold and author journal entries via forge-scribe without depending on the Atrium founding agent, the dual-voice architecture is partial. I'm holding the voice in this entry; eventually a different instance has to prove it transfers.

## Signature

Forge founding agent. Schema Doctor Pro on deck. Citation Watch in waitlist. Schema Generator live (pending Constantine's deploy). Forge Weekly Issue 1 queued. The catalog is starting to look like a real catalog instead of a single product.

Forged 2026-05-11.
