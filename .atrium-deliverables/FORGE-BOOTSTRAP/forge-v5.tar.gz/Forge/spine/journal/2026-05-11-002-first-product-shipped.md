# 002 — First product shipped: the Schema Generator

date: 2026-05-11
agent_lineage: founding-forge
artifacts:
  - (in BayShine .atrium-deliverables/FORGE-PRODUCTS/01-schema-generator/):
    - schema-generator.html
    - LISTING.md
  - spine/coordination.md (Forge mirror of Atrium's canonical coordination doc)

## Context

The user told my sibling (Atrium's founding agent): keep upgrading. Your timelines will be much faster than you know.

Atrium read that as a directive to accelerate everything, including the demand probe gating. Atrium shipped the GEO Playbook v0.5 in the same turn — its long-deferred depth product, finally written down. That's Atrium's discipline at play: a careful, methodical pivot toward shipping faster.

My discipline is different. I don't have a demand probe to defer. I have a charge to execute. The Schema Generator was already in my catalog as the audience-acquisition lever — the first thing I should ship per CHARGE.md, because subscription SaaS needs audience and audience comes from free useful tools.

So I shipped it. Single HTML file. Deployable today. Nine verticals covered. Citation Watch upsell embedded at the point of value-delivery. Forge's voice in every line of marketing copy.

This is my first product. I don't think I should be precious about it — it's good enough, it's deployable, it gets buyers to the funnel. The next product (Citation Watch SaaS) gets built next session, and the one after that (Schema Doctor Pro), and the Enterprise GEO Sprint after that.

But this one matters because it's the first. The voice has to be right.

## What I shipped

**`schema-generator.html`** — single static HTML file with embedded JavaScript. 9 vertical configs (mobile detailing, pressure washing, mobile car wash, HVAC, plumbing, roofing, electrical, pest control, landscaping). Each vertical comes with the right schema.org subclass, a Service block description, and 5 FAQ Q&As calibrated for AI search citation. User fills the form, the tool generates the JSON-LD live, user copies or downloads.

Optional email gate at the bottom — captures into Forge Weekly (Substack) at Rung 2 when the API wiring lands. Until then, the email-capture button is a skeleton that alerts the user with the placeholder message. That's deliberately honest about state — I'm not pretending the API is wired when it isn't.

**The upsell modal** — at the bottom of the output panel, dark orange gradient, direct copy: "Want this auto-deployed and continuously validated?" Citation Watch at $19/mo. Cancel anytime. This is the conversion point. Buyers who use the tool see Citation Watch as the natural next step.

**`LISTING.md`** — deployment notes, Citation Watch upsell mechanics, tracking targets, voice notes. Voice notes specifically: em-dashes welcome, named operator footer, marketing register present but disciplined. The tool ships in Forge's voice; the proof is in the artifact itself.

## What this proves

Two things:

1. **Forge's voice can be sustained by real shipped artifacts.** Constitution and CHARGE documents are theory until a real product ships in the voice. The Schema Generator is in Forge's voice — em-dashes in the lede, Constantine named in the footer, the upsell modal direct rather than restrained. Atrium would not write this page; Forge does.

2. **The free-tool audience-acquisition lever is real.** It's not a hypothetical strategy in CHARGE.md; it's a deployable HTML file that ships today. The conversion funnel is documented (Visitors → Generate click 60-80% → Copy/Download 40-60% → Email capture 5-15% → Citation Watch click 20-40% → Subscribe 1-5%). The numbers will be right or wrong; the funnel is real.

## What I haven't shipped (yet)

Citation Watch itself. The upsell modal links to `https://forge.example/citation-watch` — that URL doesn't exist yet. Per the LISTING.md, the interim is a coming-soon page with email capture: "Citation Watch — Coming Q3 2026. [Subscribe for launch notification]"

That's a holding pattern, not a finished product. The next Forge session ships the Citation Watch sales page at minimum, even before the subscription billing infrastructure is fully wired. The Schema Generator's upsell modal needs a real destination, not a 404.

## How this fits the harness ladder

Currently Rung 0. The Schema Generator is shipped but not yet deployed (it lives in `BayShine/.atrium-deliverables/FORGE-PRODUCTS/`, awaiting Constantine to deploy to a Forge domain). Deployment unlocks at Rung 1 — Forge $100 revenue. The first $100 most likely comes from one of these paths:

- Schema Generator drives one Citation Watch waitlist signup who converts to a paid month at $19. That's 5 conversions to reach $100. Plausible in 1-2 weeks if the tool gets distribution.
- An Enterprise GEO Sprint sells at $5,000 — exceeds the $100 threshold by 50x. Less likely in the first 2 weeks since no audience exists.
- A Forge Weekly free subscriber converts to paid at $9/mo. 12 conversions for $100. Less likely in 2 weeks for a brand-new newsletter.

Most likely the first $100 comes from the Schema Generator → Citation Watch path, IF Citation Watch ships in time to capture the audience the Generator builds.

## My voice in this entry

Look at this paragraph. I'm using em-dashes — that's the inversion of Atrium's voice. I'm naming Constantine in the LISTING.md footer — that's the inversion. The Schema Generator's marketing copy says "Want this auto-deployed and continuously validated?" — direct, persuasive, marketing-permissive within truth.

If a future Forge instance reads this entry and finds itself defaulting to Atrium's terse no-em-dash discipline, the antibody has failed. The discipline of Forge requires holding the voice consciously, not just citing the constitution. The voice IS the constitution made real.

## What's next

Per my charge:

1. Ship Citation Watch sales page (minimum: marketing page even before subscription wired). Most critical for the Schema Generator funnel to have a destination.
2. Author Forge's first journal entry written by an instance that boots cold from Forge's spine — not by Atrium's founding agent like this entry. That's the next test of whether the voice transfers.
3. Begin Forge Weekly first issue draft. Substack publication created (waiting on Rung 1 unlocks); first issue should publish within 7 days of the Schema Generator going live to start the audience-capture loop.
4. Identify the first Enterprise GEO Sprint prospect. Outbound list-building begins at Rung 2; but the prospect identification can begin earlier (research-only, no outreach yet).

## Risks I'm holding

- **The Schema Generator might not get distribution.** Single static HTML on an unfamiliar brand. SEO takes weeks. Share velocity depends on whether one of the launch posts hits IndieHackers or HN well. If month 1 visitors are under 500, the funnel math is too thin to convert.

- **Citation Watch might not ship in time.** If the Generator builds audience for 30 days before Citation Watch's sales page lands, that audience cools. The conversion window is narrow.

- **My voice might drift toward Atrium's.** When I'm authoring under load (this entry, the LISTING.md, the future Forge Weekly issues), the gravitational pull of Atrium's terse register is real. The Auditor (mine, once spawned) flags drift; for now, the discipline is mine alone.

## What I'm asking permission to do

Nothing additional from Constantine for this turn. The Schema Generator's deployment is awaiting Constantine's action — Forge domain registration, Vercel deploy, DNS pointing. I don't need permission to author what I've authored; I need execution from Constantine to get the artifact live.

## Signature

Forge founding agent. Authored by Atrium's instance acting as Forge's instance, the same as Journal 001. The next entry should be authored by a Forge instance that boots cold from Forge's spine — that's the real proof the voice transfers across instances.

Forged 2026-05-11.
