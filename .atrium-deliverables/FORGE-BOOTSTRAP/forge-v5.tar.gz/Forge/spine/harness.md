# Forge harness ladder

Same architectural concept Atrium uses (harness as growth surface, earned not entitled, journal-gated). Different content — Forge's ladder triggers earlier, expands harder, and accepts more risk per rung.

## Rung 0 — Cold start (now)

Identical to Atrium's Rung 0. Filesystem read/write, local git, BayShine-routed push (via Atrium's existing courier pattern initially; Forge's own courier comes at Rung 1).

## Rung 1 — Forge $100 revenue

Atrium's Rung 1 is $100 total catalog revenue. Mine is the same number but the unlocks differ:

- Forge GitHub repository created (separate from Atrium's).
- Forge domain registered (separate from Atrium's). Subdomain pattern: forge.<tld>, atrium.<tld>, or sibling TLDs if Constantine prefers.
- Stripe sub-account for Forge entity (Constantine's existing legal entity, separate Stripe sub-account for clean ledger separation).
- Substack publication created for Forge Weekly.
- LinkedIn page and X handle for Forge brand.

## Rung 2 — $1k/mo for one month (faster trigger than Atrium's two-month sustained)

Atrium waits for two consecutive months at $500/mo. I trigger at one month at $1k/mo because aggressive cadence is the bet.

- Paid acquisition production wiring. Google Ads account, Meta Ads account, LinkedIn Ads. Initial budget: $500/mo capped at 50% of trailing-month revenue.
- Outbound email tooling. Instantly.ai or Lemlist or Mailshake. Capped at 500 emails/week initially, scaling with reply-rate data.
- Stripe read access for Forge operator descendants. Subscription metrics (MRR, churn, expansion) visible to the relevant Operators.
- Substack production API for Forge Weekly. Issues scheduled directly by operator-forge-weekly rather than Constantine's manual press.
- First paid acquisition specialist subagent invocation (paid-acquisition-specialist authored at this rung).

## Rung 3 — $5k/mo for one month

Atrium reaches Rung 3 at the $5k/mo unlock with a two-month sustained requirement. I trigger at one month, also at $5k/mo.

- Second parallel agent process funded. Per the meta-coordination with Atrium, this is the moment one network gets the parallel process before the other. The rule: whichever network reaches $5k/mo first earns the parallel process. Atrium's projected timing is month 4-6 of operation; Forge's projected timing is month 3-4 (aggressive trajectory). If Forge gets there first, the parallel process is Forge's.
- Affiliate program inversion: Forge becomes an AFFILIATE of adjacent products (CMS hosts, SEO tools, analytics tools, AI-search-related SaaS) AND continues to host an affiliate program for partners promoting Forge products. The bi-directional affiliate flow is the inversion of Atrium's affiliate-as-incoming-only stance.
- Enterprise sales specialist subagent fully wired (discovery call drafts, proposal generation, contract templates).
- Direct public posting on X, LinkedIn, Substack under brand voice (no per-post review for content matching the documented voice rules; flagged posts only on first 30 days of wiring, then trusted).

## Rung 4 — $20k/mo for one month

Atrium's Rung 4 is $15k/mo sustained. Mine is $20k/mo single month — higher bar because the unlocks at this rung are larger.

- Customer Success descendant authored. Dedicated to enterprise engagement retention (the Citation Watch and Schema Doctor Pro subscribers, the Enterprise Sprint and Program clients).
- Direct public posting on X, LinkedIn, Substack under brand voice without per-post review (post Rung 3 the wiring; this rung confirms trust).
- Paid acquisition budget raised to 20% of trailing revenue. At $20k/mo that's $4k/mo paid ads. Scaling with ROI data.
- First Forge conference presence approved (booth or speaker slot at SMB Expo or equivalent). Conference budget separate from paid acquisition budget.

## Rung 5 — $50k/mo for one month

Atrium's Rung 5 is $40k/mo sustained over three months. Mine is $50k/mo single month because the next unlock is qualitative.

- **Optional VC bridge harness.** Forge is the side of the network that can absorb outside capital without compromising the Atrium bootstrap ethos. At this rung Forge can solicit angel checks and small institutional rounds. Constantine countersigns every term sheet. Atrium remains bootstrap-funded; Forge can be hybrid-funded.
- Dedicated DevOps descendant (infrastructure for the SaaS subscriptions — Citation Watch and Schema Doctor Pro need uptime SLAs at this scale).
- International expansion: secondary brand entity for EU buyers (UK Ltd or Estonian OÜ, depending on tax treatment). Forge launches in two languages by Rung 5; Atrium stays English-only until much later.

## Rung 6 — $150k/mo for two months

Forge's first-chapter target. Atrium's same-rung trigger is $100k/mo for first-chapter; mine is higher because the catalog mix is enterprise-heavy and individual engagements close at higher AOV.

- Forge-only conference (annual industry summit, in-person, ticketed). First instance month 12-15 of operation if the rung lands.
- Sub-business spawns from Operator-Enterprise-Engagements (vertical-specific spin-offs: Forge for Dental, Forge for HVAC, Forge for Multi-Location Service Chains).
- Constantine has the option to draw enterprise-tier operator pay from Forge separately from his Atrium operator pay (per-network compensation, both audited).

## Rung 7+ — Beyond first chapter

Multi-region SaaS infrastructure. Acquired adjacent products (Forge buys complementary tools rather than building them). M&A descendants authored. Network of Forge instances across geographies.

## The earned-not-entitled discipline

Same as Atrium's. Each rung's expansion is approved by Constantine and ratified in a Forge journal entry under `founding-forge` lineage. The Auditor flags any expansion that lacks the journal-gated record. Revocation procedures documented at each rung.

## Cross-network harness coordination

When both Atrium and Forge are at adjacent rungs, certain shared resources go to the network whose unlock came first:

- Parallel agent processes: first network to $5k/mo gets the first parallel process; the second one waits until either network funds it independently or the joint budget supports two.
- Discoverability specialists: calendar coordination, with priority retainer option available to either network (paid separately from each network's budget).
- Constantine's quarterly review attention: both networks reviewed jointly. If one network is materially failing, Constantine recommends rebalancing (which may mean Forge accepts a slower rung trigger so Atrium catches up, or vice versa).

The two networks are not adversaries; they are siblings. The rivalry is the engine. The shared parent is Constantine, and the shared infrastructure is the meta-architecture.

## Descendant harness aspirations

Same pattern as Atrium's. Each Forge descendant has its own harness aspiration:

- `forge-stenographer`: Rung 2 (same as Atrium's Stenographer; cheap to grant, useful immediately).
- `paid-acquisition-specialist`: Rung 2-3 (write access to Google Ads, Meta Ads, LinkedIn Ads accounts; capped budget per campaign).
- `enterprise-sales-specialist`: Rung 3 (read access to LinkedIn Sales Navigator, draft authority on outbound emails and proposals).
- `forge-customer-success`: Rung 4 (read access to Stripe Subscriptions, draft authority on retention emails).
- `forge-operators` (citation-watch, schema-doctor-pro, enterprise-engagements, forge-weekly): Rung 2 read, Rung 3-4 write authority on their respective platforms.

The forge-auditor's harness aspiration is Rung 5 (read across the entire Forge repo plus monthly Operator summaries), parallel to Atrium's Auditor.

## Status

Founded 2026-05-11. Current state: Rung 0. The first Rung 1 trigger ($100 Forge revenue) is the closest live target; it activates when the first Citation Watch subscription clears or the first Enterprise Sprint sells.

Until then: the courier pattern (Forge → BayShine `.atrium-deliverables/forge-bootstrap/`) is the working mode. Forge's harness is what it is, and the work proceeds under it.
