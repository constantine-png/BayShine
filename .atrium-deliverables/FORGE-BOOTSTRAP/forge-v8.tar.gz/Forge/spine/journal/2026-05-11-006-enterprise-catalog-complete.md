# 006 — Enterprise catalog complete

date: 2026-05-11
agent_lineage: founding-forge
artifacts:
  - (in BayShine .atrium-deliverables/FORGE-PRODUCTS/07-enterprise-geo-sprint/):
    - sales-page.html
    - LISTING.md
  - (in BayShine .atrium-deliverables/FORGE-PRODUCTS/08-enterprise-geo-program/):
    - sales-page.html
    - LISTING.md

## What I shipped

The two enterprise sales pages — Enterprise GEO Sprint ($5,000 / 5 days) and Enterprise GEO Program ($25,000 / 30 days). Both are dedicated sales pages with full delivery breakdowns, timeline tables, founding-engagement windows, and cross-network coordination notes.

Until this commit, my enterprise tier existed as cards on the Forge content site. That's enough for buyers browsing the catalog but not enough for outbound prospect references. A cold-email Variant F (the enterprise outbound template I have in COLD-EMAIL-TEMPLATES.md) needs to link to a credible dedicated sales page; "see the card on our content site" reads as half-baked.

These pages fix that. When Forge Rung 2 unlocks outbound and we start running Variant F outreach to multi-location service businesses, the prospect lands at forge.{{tld}}/enterprise-program and reads a structured pitch instead of a card.

## What completes here

My catalog is now structurally complete at the surface level. Six pricing tiers across Forge:

| Tier | Product | Price | Surface |
|---|---|---|---|
| Free | Schema Generator | $0 | Live tool at /generate |
| Subscription (low) | Citation Watch | $19/mo | Waitlist at /citation-watch |
| Subscription (high) | Schema Doctor Pro | $99/mo | Waitlist at /schema-doctor-pro |
| One-time mid-market | Enterprise GEO Sprint | $5,000 | Sales page at /enterprise |
| One-time enterprise | Enterprise GEO Program | $25,000 | Sales page at /enterprise-program |
| Newsletter | Forge Weekly | Free + $5/mo founding | Substack publication |

Plus the Forge brand hub at forge.{{tld}}/ ties them together.

Compared to my sibling Atrium's catalog (also 6 product tiers, but oriented to one-time / SMB / faceless), my catalog is now visibly distinct in voice, positioning, and price point. The dual-network architecture is operational at the catalog level.

## What I'm still building

Pre-Rung 2 work that ships at later journal entries:

- Per-product operators (operator-citation-watch, operator-schema-doctor-pro, operator-enterprise-engagements) — scaffolds for when the catalog volume exceeds operator-forge-products' umbrella capacity.
- enterprise-engagement-builder — the Builder for enterprise sales motion (discovery call drafts, charter docs, change-order process). Currently subscription-product-builder covers the subscription side; enterprise-engagement-builder will cover the high-touch sales side.
- paid-acquisition-specialist — Rung 2 unlock for Google Ads / Meta Ads / LinkedIn Ads campaigns.
- The actual Citation Watch product itself — Rung 2 build.
- The actual Schema Doctor Pro product itself — Rung 2 build (post-Citation Watch).
- The 12-month probe tracking dashboard infrastructure — Rung 2 build, used by Citation Watch standalone customers AND by Program engagements.

Each is documented in CHARGE.md or harness.md with the relevant trigger.

## The bet I'm restating

By month 12, my catalog should produce:

- 100+ Citation Watch subscribers (founding-100 cap likely closed by month 4-6 under timeline compression) = $1,400-$1,900 MRR.
- 50 Schema Doctor Pro subscribers (founding-50 cap closed) = $3,950 MRR.
- 10-25% of Citation Watch founders bundle-upgrading = $1,000-$2,500 additional MRR.
- 5-10 Sprint engagements closed at $5,000 each = $25k-$50k in one-time revenue.
- 1-2 Program engagements closed at $25,000 each = $25k-$50k in one-time revenue.
- Forge Weekly: 500-2,000 free subscribers, 50-200 paid at $5-9/mo = $250-$1,800 MRR.

Combined Year 1 trajectory: ~$8k-$12k MRR + $50k-$100k one-time revenue = $146k-$244k annualized in the optimistic case; $80k-$120k in the conservative case.

If wrong: subscription velocity is slower OR enterprise pipeline doesn't materialize at the expected rate. Backups documented in CHARGE.md (drop Schema Doctor Pro price, lean harder on Forge Weekly, pivot enterprise to retainer rather than one-time).

## What I want Constantine to do

When you deploy:

1. Both Enterprise pages go to forge.{{tld}}/enterprise and forge.{{tld}}/enterprise-program respectively.
2. The Forge brand hub navigation needs updating: the existing Enterprise cards link to /enterprise and /enterprise-program (the dedicated pages) rather than to anchor links on the hub.
3. The mailto: links in both pages route to constantine@{{forge-domain}} — set up that mailbox before deploy.
4. The Calendly link referenced in LISTING.md is your enterprise discovery call calendar. Set up a 20-min and a 45-min calendar so Sprint and Program inquiries route to the right slot.
5. The engagement charter template referenced in LISTING.md is a Notion or Google Doc you build before the first Program inquiry lands.

## Signature

Forge founding agent. Enterprise catalog complete at the sales-page layer. Full catalog spans from free Schema Generator to $25k Program. Subscription middle tiers established. Outbound infrastructure staged. Audience-capture loop closed.

Next priorities now operator-driven: build Citation Watch product when Rung 2 fires; ship Schema Doctor Pro post-Citation-Watch; spawn per-product operators at their Growth Clause thresholds; identify first enterprise prospect.

Forged 2026-05-11.
