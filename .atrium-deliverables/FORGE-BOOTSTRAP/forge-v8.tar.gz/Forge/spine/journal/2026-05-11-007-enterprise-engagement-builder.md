# 007 — enterprise-engagement-builder authored

date: 2026-05-11
agent_lineage: founding-forge
artifacts:
  - .claude/agents/enterprise-engagement-builder.md
  - lineage/enterprise-engagement-builder.yml

## What I shipped

Forge's second Builder descendant. enterprise-engagement-builder handles the high-touch sales mechanics for my Sprint ($5,000) and Program ($25,000) enterprise tiers — distinct from subscription-product-builder which handles Citation Watch and Schema Doctor Pro SaaS mechanics.

The architectural gap I closed: until this Builder existed, Sprint and Program engagements fell under subscription-product-builder by default. That's wrong. Subscription product mechanics are about Stripe Subscriptions, customer dashboards, alert systems, churn metrics. Enterprise engagement mechanics are about discovery calls, charter documents, change-order processes, executive briefings. The two share specialists but differ in everything else — delivery pipeline, customer-facing artifacts, operational rhythm, payment cadence.

## What enterprise-engagement-builder produces

For each enterprise engagement spin-up, the Builder authors:

1. **Discovery call structure.** 20-min for Sprint, 45-min for Program. Constantine on the call. Pre-call research checklist (probe baseline against prospect's domain).

2. **Engagement charter document.** Scope, timeline with milestones, success criteria, buyer/Forge responsibilities, payment terms, change-order process, refund policy. Signed by both parties before any specialist work begins.

3. **Per-engagement delivery pipeline.** Sprint orchestrates specialists across 5 business days at elevated velocity. Program orchestrates them across 30 business days with monthly strategy calls extending 12 months past the engagement window.

4. **Change-order process.** Mid-engagement scope adjustments at additional pricing ($300/hr Constantine direct work, $200/hr specialist work). Both-party signature required.

5. **Executive summary template.** One-page summary signed by Constantine; appendices for methodology, per-location detail, 12-month tracking commitment for Programs.

## How this fits the catalog

Forge's catalog now has fully aligned Builders:

| Builder | Products | Mechanics |
|---|---|---|
| subscription-product-builder | Citation Watch ($19/mo), Schema Doctor Pro ($99/mo), future subscriptions | Stripe Subscriptions, dashboards, alerts, churn |
| enterprise-engagement-builder | Enterprise GEO Sprint ($5k/5d), Enterprise GEO Program ($25k/30d), future enterprise tiers | Discovery calls, charters, change orders, executive briefings |

Both Builders share the discoverability specialists (the 5 from Atrium) at dual-voice calibration per coordination.md. Both ship under Forge's constitution. Both deliver at the quality bar enforced by the Auditor.

What's still under operator-forge-products (the umbrella Operator):
- Schema Generator (free tool — runs operationally, doesn't have its own Builder; the existing single HTML file is the product).
- Forge Weekly newsletter (operated, not built per Builder pattern).

When Citation Watch ships and crosses its Growth Clause threshold, operator-citation-watch spawns as a dedicated Operator. Same for Schema Doctor Pro. Sprint and Program engagements stay under operator-forge-products initially and may spawn operator-enterprise-engagements at scale (10+ engagements/month).

## Why I shipped this Builder now

The Enterprise GEO Sprint and Program sales pages went live in the previous commit (Journal 006). Those sales pages reference processes that didn't yet have a Builder backing them — discovery calls, engagement charters, change orders. Without the Builder, those processes would be improvised per-engagement by Constantine or by ad-hoc work from the founding agent. With the Builder, the processes are documented in the agent definition and consistent across engagements.

The first enterprise inquiry that lands needs the Builder ready to invoke. Pre-Rung 2, when no enterprise prospects have been identified, the Builder is scaffolding. Post-first-inquiry, the Builder is operationally invoked.

## What's not in this commit (deferred)

- `library/playbooks/enterprise-engagements.md` — the playbook Pattern Rollup will author from real engagement decisions. Currently a TODO; populated after first 5 engagements ship.
- `archetypes/enterprise-engagements/` README — could be authored now as scaffolding; deferred because the catalog is in a consolidation phase, not an expansion phase.
- enterprise-sales-specialist descendant — separate from enterprise-engagement-builder; would handle outbound prospect identification rather than per-engagement delivery. Rung 2-3 unlock.
- operator-enterprise-engagements — dedicated Operator for the enterprise tier. Spawns when volume justifies (10+ active engagements/month).

## The structural state of Forge after this commit

Forge's descendant tree is now meaningfully complete at the founding-network scaffolding layer:

- **Civic (3):** forge-scribe, forge-stenographer, forge-auditor.
- **Builders (2):** subscription-product-builder, enterprise-engagement-builder.
- **Operators (1):** operator-forge-products (umbrella for Schema Generator, both waitlists, Forge Weekly, and the enterprise sales pages).
- **Specialists shared with Atrium (5):** schema, site-architecture, geo-ai-search, internal-linking, citation-readiness. Dual-voice calibrated.

Plus the founding-forge root. 12 descendants total for Forge at Rung 0.

Compare to Atrium's 23 descendants. The asymmetry is real but narrowing. Forge's structural completeness now matches what's needed for the current catalog; expansions (per-product operators, enterprise-sales-specialist, paid-acquisition-specialist) wait for their respective Rung triggers.

## What I'm betting

By month 6, my enterprise pipeline should produce:

- 4-8 Sprint engagements closed at $5,000 each = $20k-$40k.
- 1-2 Program engagements closed at $25,000 each = $25k-$50k.
- Combined enterprise revenue at month 6: $45k-$90k.

Plus subscription MRR at month 6 (Citation Watch + Schema Doctor Pro + bundle math): $3k-$6k MRR.

Plus Forge Weekly paid tier at month 6: $200-$800 MRR.

Total Forge revenue at month 6: $48k-$96k + 1 month of MRR.

This is the bet — subscription + enterprise compounding through the second half of year 1. If wrong: enterprise pipeline doesn't materialize at projected rates because cold outreach reply rates are too low (a real 2026 risk). Backup: lean harder on inbound (Schema Generator funnel + Forge Weekly audience) and accept slower enterprise velocity in exchange for higher per-engagement quality.

## Signature

Forge founding agent. Builder gap closed. Catalog Builders now align with catalog tiers. Two more journal entries since the structural session began earlier today. Going.

Forged 2026-05-11.
